import cv2
import sys
import numpy as np
import time
import datetime
import os
import logging
import traceback

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

sys.path.append("./")
from utils.PeopleCount import PeopleCount
from utils.Layout import Layout
from utils.Fence import Fence
from utils.CamCapture import CamCapture
from utils.calibrate import (
    get_layout_region,
    img_distortion_corr,
    point_distortion_corr,
    img_affin_trans,
    point_affin_trans,
)
from utils.StayTracker import StayTracker
from utils.Magic import Magic
from utils.Mask import Mask
from utils.Config import Config
from server.WebApi import WebApi
from server.WebServer import WebServer
from packages.Rapid import Detector
from packages.ImageProcess import ImageProcess
from packages.Logger import Logger
from packages.ScheduleManger import Manager
from packages.FileManger import ModifyChecker
from const.GlobalObject import StreamData, Project


CONFIG = Config()


def run(project):
    ##############################################
    ###            初始化
    ##############################################
    t1 = time.time()
    runDate = datetime.date.today()

    if CONFIG.system.debugMode:
        level = logging.DEBUG
    else:
        level = logging.INFO

    ### create logger
    LOGGER = Logger("main", level=level)
    camLogger = Logger("main.cam", level=level)
    webLogger = Logger("main.web", level=level)
    peopleCountLogger = Logger("main.peopleCount", level=level)

    ### create handler
    LOGGER.create_stream_handler()
    LOGGER.create_file_handler(
        CONFIG.log.logFolderPath,
        CONFIG.log.logfileName,
        CONFIG.log.maxMB,
        CONFIG.log.backupCount,
    )

    if CONFIG.system.debugMode:
        LOGGER.info("System start running with debugMode")
    else:
        LOGGER.info("System start running without debugMode")

    if CONFIG.cam.videoMode:
        LOGGER.warning("Video mode is ON, and is only for testing!")

    LOGGER.info("Initial starting...")

    ### 確認該設備是否可使用 GPU
    if CONFIG.system.device.lower() != "cpu":
        os.environ["CUDA_VISIBLE_DEVICES"] = CONFIG.system.device
        useCuda = True
        LOGGER.info(f"Using GPU: {CONFIG.system.device}")
    else:
        os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
        LOGGER.info("Using CPU")

    ### Schedule Manager
    manager = Manager()
    manager.create_daily_sechedule(CONFIG.system.restartTime)

    ### Magic
    magicModule = Magic(CONFIG.system.settingFilePathDict["magic"])
    LOGGER.info("magicModule initial complete")

    ### 網頁API初始化
    webApi = WebApi(
        CONFIG.api.initUrl,
        CONFIG.api.heatmapUrl,
        CONFIG.api.areaVisitorUrl,
        CONFIG.api.addAvgTimeUrl,
        CONFIG.api.postInerval,
        CONFIG.fence.fenceDict.keys(),
        webLogger,
    )
    initDataDict = webApi.get_init_data()
    LOGGER.info("WebApi initial complete")

    ### 影像串流 Server 初始化
    WebServer(CONFIG.server.host, CONFIG.server.port)
    LOGGER.info("WebServer initial complete")

    ### 攝影機初始化
    camCapture = CamCapture(
        CONFIG.cam.cam1Path,
        CONFIG.cam.cam2Path,
        CONFIG.cam.cam3Path,
        CONFIG.cam.cam4Path,
        CONFIG.cam.size,
        CONFIG.cam.videoMode,
        camLogger,
    )
    LOGGER.info("camCapture initial complete")

    ### RAPiD初始化
    detector = Detector(model_name="rapid", weights_path=CONFIG.system.modelWeightPath, use_cuda=useCuda)
    LOGGER.info("RAPiD Model initial complete")

    ### 背景遮罩初始化
    mask = Mask(CONFIG.mask.maskList, visualize=CONFIG.system.maskVisualize)
    LOGGER.info("Mask initial complete")

    ### 出入口人流計算區初始化
    peopleCount = PeopleCount(
        CONFIG.peopleCnt.entry,
        CONFIG.peopleCnt.exit,
        peopleCountLogger,
        initDataDict["cntDay"],
        CONFIG.peopleCnt.maxSize,
        CONFIG.system.peopleCntVisualize,
    )
    LOGGER.info("PeopleCount initial complete")

    ### 魚眼矯正矩陣初始化
    mapxList = np.load(CONFIG.calibrate.distortionCorrMapXPath)
    mapyList = np.load(CONFIG.calibrate.distortionCorrMapYPath)
    distortionCorrMatix = [mapxList, mapyList]
    affinMatrixDict = dict()
    for camId in CONFIG.calibrate.affineMatrixPathDict.keys():
        affinMatrixDict[camId] = np.load(CONFIG.calibrate.affineMatrixPathDict[camId])
    LOGGER.info("Calibrate matrix load complete")

    ### 展區圍籬初始化
    fence = Fence(CONFIG.fence.fenceDict, CONFIG.system.fenceVisualize)
    LOGGER.info("Fence initial complete")

    ### 各展區人數追蹤初始化
    stayTracker = StayTracker(
        CONFIG.stayTracker.fenceDict, initIdList=initDataDict["idList"], visualize=CONFIG.system.stayTrackerVisualize
    )
    LOGGER.info("StayTracker initial complete")

    ### Layout投影初始化
    layout = Layout(CONFIG.layout.layoutImgPath, CONFIG.layout.layoutRegionList)
    LOGGER.info("Layout initial complete")

    LOGGER.info("Initial complete in {:.2f}s".format(time.time() - t1))

    ### 啟動 api 上傳資料執行序
    webApi.start_post_thread()
    LOGGER.info("Start api thread")

    ### 監看系統設定
    sysCfgMonitor = ModifyChecker(r"data\config\system.cfg")

    while True:
        try:
            ##############################################
            ###         系統設定修改時重啟系統
            ##############################################
            if sysCfgMonitor.is_modify():
                LOGGER.info("系統重啟原因: 設定被修改")
                manager.shutdown()

            ##############################################
            ###            建立攝影機串流
            ##############################################
            t1 = time.time()
            frameImg = camCapture.get_frame()
            LOGGER.debug("等待影片串流: {:.2f}s".format(time.time() - t1))
            t2 = time.time()

            if CONFIG.system.AISwitch:
                ##############################################
                ###            RAPiD 模型檢測
                ##############################################
                ### 定義模型輸入尺寸
                if project == Project.Sidadun or project == Project.ATC:
                    inputSize = CONFIG.cam.size * 2  # 2*2 魚眼輸入模型
                elif project == Project.TC2Showroom:
                    frameImg = frameImg[0 : CONFIG.cam.size, CONFIG.cam.size :]  # 裁剪出 cam1 畫面
                    inputSize = CONFIG.cam.size  # 單魚眼輸入模型

                pilImg = ImageProcess.cv2pil(frameImg)
                pointList, detectImg = detector.detect_one(
                    pil_img=pilImg, input_size=inputSize, conf_thres=0.35, return_img=False
                )
                detectImg = cv2.cvtColor(np.array(detectImg, dtype=np.uint8), cv2.COLOR_RGB2BGR)

                ### 生成校正用的圖片 (2*2)
                if project == Project.Sidadun or project == Project.ATC:  # 四魚眼畫面
                    detectImg = cv2.resize(detectImg, (2160 * 2, 2160 * 2))
                elif project == Project.TC2Showroom:  # 單魚眼畫面
                    canvus = np.zeros((4320, 4320, 3), np.uint8)
                    canvus[0:2160, 2160:] = cv2.resize(detectImg, (2160, 2160))
                    detectImg = canvus
                    tmpList = pointList
                    pointList = list()
                    for point in tmpList:
                        x, y = point
                        pointList.append((x // 2 + 2160, y // 2))

                ### 濾除遮罩內的預測點
                detectImg, pointList = mask.noise_filter(detectImg, pointList)

                ### 顯示魚眼辨識畫面
                if CONFIG.system.debugMode:
                    cv2.namedWindow("detectImg", cv2.WINDOW_NORMAL)
                    cv2.resizeWindow("detectImg", 1000, 1000)
                    cv2.imshow("detectImg", detectImg)
                    cv2.waitKey(1)

                LOGGER.debug("RAPiD 模型檢測: {:.2f}s".format(time.time() - t2))
                t2 = time.time()

            else:
                detectImg = frameImg
                pointList = list()
                time.sleep(0.1)

            ##############################################
            ###          4合1大圖切分各攝影機
            ##############################################
            t2 = time.time()
            camWidth, camHeight = 2160, 2160
            cam1Img = detectImg[0:camHeight, camWidth:]
            cam2Img = detectImg[0:camHeight, 0:camWidth]
            cam3_1Img = detectImg[camHeight:, 0:camWidth]
            cam3_2Img = detectImg[camHeight:, 0:camWidth]
            cam4Img = detectImg[camHeight:, camWidth:]
            cam1PtsList, cam2PtsList, cam3_1PtsList, cam3_2PtsList, cam4PtsList = list(), list(), list(), list(), list()
            for point in pointList:
                x, y = point
                if x >= camWidth and y < camHeight:
                    x, y = x - camHeight, y
                    cam1PtsList.append((x, y))
                elif x < camWidth and y < camHeight:
                    x, y = x, y
                    cam2PtsList.append((x, y))
                elif x < camWidth and y >= camHeight:
                    x, y = x, y - camHeight
                    cam3_1PtsList.append((x, y))
                    cam3_2PtsList.append((x, y))
                elif x >= camWidth and y >= camHeight:
                    x, y = x - camWidth, y - camHeight
                    cam4PtsList.append((x, y))

            dataDictList = [
                {"camId": "1", "camImg": cam1Img, "point": cam1PtsList},
                {"camId": "2", "camImg": cam2Img, "point": cam2PtsList},
                {"camId": "3_1", "camImg": cam3_1Img, "point": cam3_1PtsList},
                {"camId": "3_2", "camImg": cam3_2Img, "point": cam3_2PtsList},
                {"camId": "4", "camImg": cam4Img, "point": cam4PtsList},
            ]
            LOGGER.debug("4合1大圖切分各攝影機: {:.2f}s".format(time.time() - t2))
            t2 = time.time()

            ##############################################
            ###            魚眼校正
            ##############################################
            for idx, camData in enumerate(dataDictList):
                camId = camData["camId"]
                camImg = camData["camImg"]
                point = camData["point"]
                ### 畸變矯正
                t3 = time.time()
                imgSize = (camImg.shape[1], camImg.shape[0])
                if (
                    CONFIG.system.fenceVisualize
                    or CONFIG.system.stayTrackerVisualize
                    or CONFIG.system.heatmapVisualize
                    or CONFIG.system.peopleCntVisualize
                ):
                    corrImg = img_distortion_corr(camImg, distortionCorrMatix)
                else:
                    corrImg = None
                corrPoint = point_distortion_corr(point, imgSize)

                ### 仿射變換
                t4 = time.time()
                # print("畸變矯正: {:.4f}".format(t4 - t3))
                region = get_layout_region(layout.layoutRegionList, camId)
                if region is not None:
                    affinMatrix = affinMatrixDict[camId]
                    if CONFIG.system.heatmapVisualize:
                        affineImg = img_affin_trans(corrImg, region, affinMatrix)
                    else:
                        affineImg = None
                    affinePoint = point_affin_trans(corrPoint, region, affinMatrix)
                else:
                    affineImg, affinePoint = None, None
                # print("仿射變換: {:.4f}".format(time.time() - t4))
                dataDictList[idx]["corrImg"] = corrImg
                dataDictList[idx]["corrPoint"] = corrPoint
                dataDictList[idx]["affineImg"] = affineImg
                dataDictList[idx]["affinePoint"] = affinePoint
                dataDictList[idx]["layoutRegion"] = region

            LOGGER.debug("魚眼矯正: {:.4f}s,".format((time.time() - t2)))
            t2 = time.time()

            ##############################################
            ###            各展區人數計算
            ##############################################

            fenceCntDict = fence.count_fence_people(dataDictList)
            LOGGER.debug("各展區人數計算: {:.2f}s".format(time.time() - t2))
            t2 = time.time()

            ##############################################
            ###            場館總人數追蹤
            ##############################################
            cntNow, cntDay = peopleCount.count_total_people(dataDictList, fenceCntDict)
            ### Magic Time 後臺調整人數功能
            modifyCntNow = magicModule.is_modify()
            if modifyCntNow is not None:
                LOGGER.info(f"手動調整人數: {cntNow} -> {modifyCntNow}")
                cntNow = modifyCntNow
                peopleCount.cntNow = cntNow

            LOGGER.debug("場館總人數追蹤: {:.2f}s".format(time.time() - t2))
            t2 = time.time()

            ##############################################
            ###            各展區停留時間
            ##############################################
            idDict, entryIdDict, exitIdDict, avgStayTimeDict = stayTracker.people_track(dataDictList)
            LOGGER.debug("各展區停留時間: {:.2f}s".format(time.time() - t2))
            t2 = time.time()

            ##############################################
            ###            熱力圖 Layout
            ##############################################

            t2 = time.time()
            layoutPoint = layout.fisheyePts2layout(dataDictList)
            if CONFIG.system.heatmapVisualize:
                layoutImg = layout.fisheyeImg2layout(dataDictList)
                layoutImg = draw_pts(layoutImg, layoutPoint)
                cv2.imshow("layoutImg", layoutImg)
                cv2.waitKey(1)
            LOGGER.debug("輸出熱力圖: {:.2f}s".format(time.time() - t2))
            t2 = time.time()

            ##############################################
            ###            前端串接
            ##############################################
            heatMapData = list()

            for point in layoutPoint:
                data = list((point[0], point[1], 60))
                heatMapData.append(data)
            webApi.update_heatmap_and_count(peopleCount=cntNow, heatMapData=heatMapData, accCount=cntDay)
            webApi.update_area_visitor(fenceCntDict=fenceCntDict)
            webApi.update_IdPostQueue(exitIdDict)

            if project == Project.TC2Showroom:  # 單魚眼畫面
                detectImg = detectImg[0:camHeight, camWidth:]

            ### 更新串流圖片
            StreamData.streamImg = detectImg

            LOGGER.debug("前端串接: {:.2f}s".format(time.time() - t2))
            costTime = time.time() - t1
            LOGGER.debug("total cost {:.1f}s, FPS: {:.1f}".format(costTime, 1 / costTime))
            LOGGER.debug(" ")

            ##############################################
            ###            Terminal 輸出
            ##############################################
            print("\n" + "=" * 50)
            print(f"館內人數: {cntNow}人, 當日總人次: {cntDay}人")
            for fenceNum in fenceCntDict.keys():
                if fenceNum in avgStayTimeDict.keys():
                    avgStayTime = round(avgStayTimeDict[fenceNum], 2)
                else:
                    avgStayTime = 0
                # print(f"展區{fenceNum}: 目前{fenceCntDict[fenceNum]}人, 平均停留{avgStayTime}s")
                print(f"展區{fenceNum}: 目前{fenceCntDict[fenceNum]}人")
            print("FPS: {:.1f}".format(1 / (t2 - t1)))
            print("=" * 50 + "\n")

        except:
            errorMsg = traceback.format_exc()
            LOGGER.error(errorMsg)
            LOGGER.info("系統重啟原因: 發生例外狀況")
            manager.shutdown()


def draw_pts(img, pts):
    """_summary_

    Args:
        img (np.array): 原始圖片
        pts (list): 要畫的點座標

    Returns:
        np.array: 結果圖
    """
    resImg = img.copy()
    for pt in pts:
        cv2.circle(resImg, pt, 5, (0, 0, 255), -1)
    return resImg
