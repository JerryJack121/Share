from PIL import Image
import cv2
import os
import numpy as np


class ImageProcess:
    @staticmethod
    def cv2pil(imgCV):
        imgCV_RGB = cv2.cvtColor(imgCV, cv2.COLOR_BGR2RGB)
        imgPIL = Image.fromarray(imgCV_RGB)
        return imgPIL

    @staticmethod
    def get_fisheye(img):
        width, height = img.shape[1], img.shape[0]
        shortLen = min(width, height)  # 取短邊
        radius = shortLen // 2
        resImg = img[height // 2 - radius : height // 2 + radius, width // 2 - radius : width // 2 + radius]  # 根據短邊裁切圖片
        return resImg


class Plot:
    @staticmethod
    def plot_disconnected_img(imgSize, fontSize=120):
        font = "No Signal!"
        w, h = imgSize
        text_location = ((w - len(font) * fontSize) // 2, (h - fontSize) // 2)
        not_connected_img = np.zeros((h, w, 3), dtype="uint8")
        not_connected_img = cv2.putText(
            not_connected_img, font, text_location, cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 1
        )
        return not_connected_img


if __name__ == "__main__":
    inputFolder = r"\\yjchou\Share\WYLee\input\0707_ATC_data"
    outputFolder = r"\\yjchou\Share\WYLee\output"

    imgFilenameList = os.listdir(inputFolder)
    for imgFilename in imgFilenameList:
        imgFilePath = os.path.join(inputFolder, imgFilename)
        img = cv2.imread(imgFilePath)
        resImg = ImageProcess.get_fisheye(img)
        cv2.imwrite(os.path.join(outputFolder, imgFilename), resImg)
