import os
import schedule
import threading
import time


class Manager:
    def __init__(self):
        self.pid = os.getpid()

    def create_daily_sechedule(self, restartTimeFormat):
        """建立每日排程

        Args:
            restartTimeFormat (_type_): _description_
        """
        schedule.every().day.at(restartTimeFormat).do(self.shutdown)
        checkThread = threading.Thread(target=self.__check_sechedule)
        checkThread.start()

    def __check_sechedule(self):
        while True:
            schedule.run_pending()
            time.sleep(1)

    def shutdown(self):
        """強制終止程式"""
        ### Windows 系統
        if os.name == "nt":
            cmd = f"taskkill /pid {self.pid} /f"
        ### Linux 系統
        elif os.name == "posix":
            cmd = f"kill {self.pid}"

        try:
            os.system(cmd)
        except Exception as e:
            print(f"Cann't kill process {self.pid}: e")
