import numpy as np
import os
import cv2
import sys
import cv2
import json

sys.path.append("./")


class Layout:
    def __init__(self, layoutImgPath, layoutRegionList):
        self.layoutImg = cv2.imread(layoutImgPath)
        self.layoutRegionList = layoutRegionList

    ### 魚眼鏡頭投射至 Layout
    def fisheyeImg2layout(self, dataDictList):
        layoutPoint = list()
        camIdList = list()
        resLayoutImg = self.layoutImg.copy()
        for layoutRegion in self.layoutRegionList:
            camIdList.append(layoutRegion["camId"])

        for dataDict in dataDictList:
            camId = dataDict["camId"]
            ### Layout沒有使用到這台攝影機
            if camId not in camIdList:
                continue
            camImg = dataDict["camImg"]
            affineImg = dataDict["affineImg"]
            region = dataDict["layoutRegion"]
            resLayoutImg[int(region[0][1]) : int(region[1][1]), int(region[0][0]) : int(region[1][0])] = affineImg

        return resLayoutImg

    ### 魚眼鏡頭座標投射至 Layout
    def fisheyePts2layout(self, dataDictList):
        layoutPoint = list()
        camIdList = list()

        for layoutRegion in self.layoutRegionList:
            camIdList.append(layoutRegion["camId"])

        for dataDict in dataDictList:
            camId = dataDict["camId"]
            ### Layout沒有使用到這台攝影機
            if camId not in camIdList:
                continue
            camImg = dataDict["camImg"]
            affinePoint = dataDict["affinePoint"]

            for point in affinePoint:
                layoutPoint.append(point)

        return layoutPoint
