import os
import cv2
import sys
import datetime
import json

sys.path.append("./")
from packages.CentroidTracker import CentroidTracker


class StayTracker:
    def __init__(self, fenceDict, initIdList, visualize=False):
        """各展區 ID 追蹤

        Args:
            fenceDict (_type_): _description_
            initIdList (_type_): _description_
            visualize (bool, optional): _description_. Defaults to True.
        """
        self.fenceDict = fenceDict
        self.initIdList = initIdList
        self.visualize = visualize
        self.trackerDict = dict()
        self.visualizeImgDict = dict()
        self.stayTimeCal = StayTimeCal(stayTimeThres=10, maxLen=99)
        for fenceNum, fenceData in self.fenceDict.items():
            self.trackerDict[fenceNum] = CentroidTracker(maxDisappeared=10)

    def reset(self):
        """系統重置"""
        self.trackerDict = dict()
        for fenceNum, fenceData in self.fenceDict.items():
            self.trackerDict[fenceNum] = CentroidTracker(maxDisappeared=10)
        self.stayTimeCal = StayTimeCal(stayTimeThres=10, maxLen=99)

    def people_track(self, dataDictList):
        idDict = dict()
        for fenceNum, fenceData in self.fenceDict.items():
            # ### debug
            # if fenceNum != "1":
            #     continue
            pointInFence = list()
            idDict[fenceNum] = list()
            camId, fenceCord = fenceData["camID"], fenceData["data"]
            ### 畸變校正後座標
            for dataDict in dataDictList:
                if dataDict["camId"] == camId:
                    corrImg = dataDict["corrImg"]
                    PtsList = dataDict["corrPoint"]
                    if camId not in self.visualizeImgDict.keys():
                        self.visualizeImgDict[camId] = corrImg
                    break

            ### 過濾不在圍籬區內的座標
            for point in PtsList:
                x, y = point[0], point[1]
                if x < fenceCord[0][0] or x > fenceCord[1][0] or y < fenceCord[0][1] or y > fenceCord[1][1]:
                    continue
                pointInFence.append(point)

            ### 更新追蹤器
            objects = self.trackerDict[fenceNum].update(pointInFence)

            for objectID, centroid in objects.items():
                ### FIXME: yjchou 2023/03/14 避免使用list順序
                objectID += self.initIdList[int(fenceNum) - 1]  # 加上 ID 初始值, 避免 ID 重複
                idDict[fenceNum].append(objectID)
                ### visualize
                if self.visualize:
                    ### Visualize
                    cv2.putText(
                        self.visualizeImgDict[camId],
                        str(objectID),
                        tuple((centroid[0], centroid[1])),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        1,
                        (0, 0, 255),
                        1,
                        cv2.LINE_AA,
                    )

        ### 計算各 ID 停留時間
        entryIdDict, exitIdDict, avgStayTimeDict = self.stayTimeCal.update(idDict)

        ### visualize
        if self.visualize:
            for camId, visualizeImg in self.visualizeImgDict.items():
                visualizeImg = cv2.resize(visualizeImg, (visualizeImg.shape[1] // 2, visualizeImg.shape[0] // 2))
                cv2.imshow(camId, visualizeImg)
                cv2.waitKey(1)
            self.visualizeImgDict = dict()

        return idDict, entryIdDict, exitIdDict, avgStayTimeDict


class StayTimeCal:
    def __init__(self, stayTimeThres=30, maxLen=99, outputFolder=r"data\txt\id_track") -> None:
        """計算各 ID 進出時間與各展區平均停留時間

        Args:
            stayTimeThres (int, optional): 停留時間秒數閾值, 低於閾值則不發送到前端. Defaults to 30.
            maxLen (int, optional): 各圍籬記錄ID的最大長度. Defaults to 99.
            outputFolder (str, optional): 輸出資料夾. Defaults to "data\txt".
        """
        self.maxLen = maxLen
        self.outputFolder = outputFolder
        self.stayTimeThres = stayTimeThres
        os.makedirs(self.outputFolder, exist_ok=True)
        ### 初始化8個展區
        self.existIdDict, self.resultDict = dict(), dict()
        for fenceNum in list((str(i) for i in range(1, 9))):
            self.existIdDict[fenceNum] = dict()  # 紀錄各展區當前存在ID進入時間
            self.resultDict[fenceNum] = dict()  # 紀錄各展區所有ID進出時間

    def update(self, idDict):
        ### 初始化8個展區
        entryIdDict, exitIdDict, avgStayTimeDict = dict(), dict(), dict()
        for fenceNum in list((str(i) for i in range(1, 9))):
            entryIdDict[fenceNum] = dict()  # 紀錄各展區進入的ID
            exitIdDict[fenceNum] = dict()  # 紀錄各展區離開的ID
            avgStayTimeDict[fenceNum] = 0  # maxLen時間區間內的平均停留時間

        for fenceNum, idList in idDict.items():
            ### 沒有記錄過的ID, 記錄進入時間
            for id in idList:
                if id not in self.resultDict[fenceNum].keys():
                    # startTime = time.time()
                    startTime = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    self.existIdDict[fenceNum][id] = dict({"startTime": startTime})
                    entryIdDict[fenceNum][id] = dict({"startTime": startTime, "endTime": None, "stayTime": None})
                    self.resultDict[fenceNum][id] = dict({"startTime": startTime, "endTime": None, "stayTime": None})

            ### 消失的ID, 記錄離開時間
            leftIdList = list()
            for id in self.existIdDict[fenceNum].keys():
                if id not in idList:
                    startTime = self.resultDict[fenceNum][id]["startTime"]
                    # endTime = time.time()
                    endTime = datetime.datetime.now()
                    stayTime = (
                        endTime - datetime.datetime.strptime(startTime, "%Y-%m-%d %H:%M:%S")
                    ).total_seconds()  # 轉換成秒數
                    endTime = endTime.strftime("%Y-%m-%d %H:%M:%S")
                    leftIdList.append(id)
                    self.resultDict[fenceNum][id] = dict(
                        {"startTime": startTime, "endTime": endTime, "stayTime": stayTime}
                    )

                    ### 高於閾值的才列入
                    if stayTime >= self.stayTimeThres:
                        exitIdDict[fenceNum][id] = dict(
                            {"startTime": startTime, "endTime": endTime, "stayTime": stayTime}
                        )

            # 從當前ID列表中移除消失的ID
            for id in leftIdList:
                self.existIdDict[fenceNum].pop(id)

            ### 刪除超過最大長度的舊資料
            if len(self.resultDict[fenceNum]) > self.maxLen:
                delNum = len(self.resultDict[fenceNum]) - self.maxLen
                while delNum != 0:
                    resultIdDict = list(self.resultDict[fenceNum].keys())
                    for delId in resultIdDict:
                        ### 避免刪到目前存在的ID
                        if delId not in self.existIdDict[fenceNum].keys():
                            self.resultDict[fenceNum].pop(delId)
                            delNum -= 1
                            break
                        ### 所有ID都還存在則不刪除任何資料
                        elif delId == resultIdDict[-1]:
                            delNum = 0

            ### DEVELOP: 輸出txt & 計算平均停留時間, 非必要開啟
            if False:
                stayTimeSum = 0
                file = open(os.path.join(self.outputFolder, "fence_" + fenceNum + ".txt"), "wt")
                for id, idInfo in self.resultDict[fenceNum].items():
                    startTime, endTime, stayTime = idInfo["startTime"], idInfo["endTime"], idInfo["stayTime"]

                    ### ID 尚未離開, 以目前時間計算
                    if stayTime is None:
                        stayTime = (
                            datetime.datetime.now() - datetime.datetime.strptime(startTime, "%Y-%m-%d %H:%M:%S")
                        ).total_seconds()

                        endTime = "None"

                    stayTimeSum += stayTime
                    file.write(
                        "{} startTime: {}, endTime:{}, stayTime: {:.2f}s\n".format(id, startTime, endTime, stayTime)
                    )
                if len(self.resultDict[fenceNum].keys()) != 0:
                    avgStayTimeDict[fenceNum] = stayTimeSum / len(self.resultDict[fenceNum].keys())
                else:
                    avgStayTimeDict[fenceNum] = 0
                file.write("Average Stay {:.2f}s".format(avgStayTimeDict[fenceNum]))
                file.close()

            else:
                stayTimeSum = 0
                file = open(os.path.join(self.outputFolder, "fence_" + fenceNum + ".txt"), "wt")
                for id, idInfo in self.resultDict[fenceNum].items():
                    startTime, endTime, stayTime = idInfo["startTime"], idInfo["endTime"], idInfo["stayTime"]

                    ### ID 尚未離開, 以目前時間計算
                    if stayTime is None:
                        stayTime = (
                            datetime.datetime.now() - datetime.datetime.strptime(startTime, "%Y-%m-%d %H:%M:%S")
                        ).total_seconds()

                        endTime = "None"

                    stayTimeSum += stayTime
                    file.write(
                        "{} startTime: {}, endTime:{}, stayTime: {:.2f}s\n".format(id, startTime, endTime, stayTime)
                    )
                if len(self.resultDict[fenceNum].keys()) != 0:
                    avgStayTimeDict[fenceNum] = stayTimeSum / len(self.resultDict[fenceNum].keys())
                else:
                    avgStayTimeDict[fenceNum] = 0

        return entryIdDict, exitIdDict, avgStayTimeDict
