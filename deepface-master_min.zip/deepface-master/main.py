from deepface import DeepFace 
import cv2
import time

def detect_pic(imgPath):
    img  = cv2.imread(imgPath)
    objs = DeepFace.analyze(img_path = img, 
        # actions = ['age', 'gender', 'race', 'emotion']
        actions = ['age', 'gender']
)

    for obj in objs:
        res = {
            'age': obj['age'],
            'gender': obj['dominant_gender'],
            # 'emotion': obj['dominant_emotion'],
            # 'race': obj['dominant_race'],
        }
        print(res)

def detect_video(videoPath):
    actions = ['age', 'gender']
    models = DeepFace.create_models(actions)
    cap = cv2.VideoCapture(videoPath)

    frameCnt = 0
    t1 = time.time()
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        
        t2 = time.time()
        objs = DeepFace.analyze_frame(frame, models, actions=actions)

        for obj in objs:
            res = {
                'age': obj['age'],
                'gender': obj['dominant_gender'],
            }
            # print(res)
        
        t3 = time.time()
        frameCnt += 1

        print('num_frame: {}, fps: {:.1f}, avg_fps: {:.1f}'.format(frameCnt, (1/(t3-t2)), (frameCnt/(t3-t1))))


if __name__ == '__main__':
    # detect_pic(imgPath = "girl1.jpg")
    detect_video(videoPath = 'WIN_20230727_09_26_17_Pro_short.mp4')
