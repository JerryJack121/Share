class Project:
    Sidadun = 0
    TC2Showroom = 1
    ATC = 2


class StreamData:
    streamImg = None
