import os
import schedule
import threading
import time


class Scheduler:
    checkThreadRunning = False

    @staticmethod
    def create_daily_job(timeFormat, job):
        schedule.every().day.at(timeFormat).do(job)

        if not Scheduler.checkThreadRunning:
            checkThread = threading.Thread(target=Scheduler.__check_sechedule)
            checkThread.start()
            Scheduler.checkThreadRunning = True

    @staticmethod
    def __check_sechedule():
        while True:
            schedule.run_pending()
            time.sleep(1)


class RestartManager:
    def __init__(self):
        self.pid = os.getpid()

    def create_daily_sechedule(self, timeFormat):
        """建立每日排程

        Args:
            timeFormat (_type_): _description_
        """
        Scheduler.create_daily_job(timeFormat, self.shutdown)

    def shutdown(self):
        """強制終止程式"""
        ### Windows 系統
        if os.name == "nt":
            cmd = f"taskkill /pid {self.pid} /f"
        ### Linux 系統
        elif os.name == "posix":
            cmd = f"kill {self.pid}"

        try:
            os.system(cmd)
        except Exception as e:
            print(f"Cann't kill process {self.pid}: e")


class ResetManager:
    def __init__(self):
        self.resetTrigger = False

    def create_daily_sechedule(self, timeFormat):
        """建立每日排程

        Args:
            timeFormat (_type_): _description_
        """
        Scheduler.create_daily_job(timeFormat, self.__enable_reset_trigger)

    def get_reset_trigger(self):
        return self.resetTrigger

    def __enable_reset_trigger(self):
        self.resetTrigger = True

    def disable_reset_trigger(self):
        self.resetTrigger = False
