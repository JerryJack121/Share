import os
import cv2


def get_fisheye(img):
    width, height = img.shape[1], img.shape[0]
    shortLen = min(width, height)  # 取短邊
    radius = shortLen // 2
    resImg = img[height // 2 - radius : height // 2 + radius, width // 2 - radius : width // 2 + radius]  # 根據短邊裁切圖片
    return resImg


inputFolder = r"\\yjchou\Share\WYLee\input\0707_ATC_data"
outputFolder = r"\\yjchou\Share\WYLee\output"

imgFilenameList = os.listdir(inputFolder)
for imgFilename in imgFilenameList:
    imgFilePath = os.path.join(inputFolder, imgFilename)
    img = cv2.imread(imgFilePath)
    resImg = get_fisheye(img)
    cv2.imwrite(os.path.join(outputFolder, imgFilename), resImg)
