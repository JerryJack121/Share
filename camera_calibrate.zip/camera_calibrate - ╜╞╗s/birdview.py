import cv2
import numpy as np
import math

from package.Calibration import Calibration, PerspectiveTransform, CamType


def order_points(corners):
    corners = np.array([coord[0] for coord in corners], dtype="float32")
    rectArr = np.zeros((4, 2), dtype="float32")
    s = corners.sum(axis=1)
    rectArr[0] = corners[np.argmin(s)]
    rectArr[2] = corners[np.argmax(s)]
    diff = np.diff(corners, axis=1)
    rectArr[1] = corners[np.argmin(diff)]
    rectArr[3] = corners[np.argmax(diff)]

    rectList = [(int(pt[0]), int(pt[1])) for pt in rectArr]

    return rectList


imgPath = r"images\0_fisheye\E96_muti_view_11_8(2)\20240124_133641.jpg"
cornerNum = (11, 8)
camType = CamType.FISHEYE


img = cv2.imread(imgPath)


ret, corners = Calibration.find_chessboard_corners(img, cornerNum)


### 畫角點
resImg = img.copy()
# resImg = cv2.drawChessboardCorners(resImg, cornerNum, corners, ret)

### 找出棋盤個的 4 個邊
srcPtsList = order_points(corners)
for i, pt in enumerate(srcPtsList):
    cv2.putText(resImg, str(i), pt, cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 1, cv2.LINE_AA)
    resImg = cv2.circle(resImg, pt, 5, (0, 0, 255), -1)

### 準備透視變換後的目標點
boardWidth = int(math.sqrt((srcPtsList[1][0] - srcPtsList[0][0]) ** 2 + (srcPtsList[1][1] - srcPtsList[0][1]) ** 2))
boardHeight = int(math.sqrt((srcPtsList[2][0] - srcPtsList[1][0]) ** 2 + (srcPtsList[2][1] - srcPtsList[1][1]) ** 2))


### FIXME: 移動棋盤格左上角的座標, 避免校正後圖片被裁切
origin = tuple((srcPtsList[0][0] + 500, srcPtsList[0][1] + 500))

### 維持棋盤格在畫面中的大小
targetPtsList = [
    [origin[0], origin[1]],
    [origin[0] + boardWidth, origin[1]],
    [origin[0] + boardWidth, origin[1] + boardHeight],
    [origin[0], origin[1] + boardHeight],
]

### 透視變換
width, height = img.shape[:2][::-1]
matrix = PerspectiveTransform.solve_matrix(srcPtsList, targetPtsList)
resImg = PerspectiveTransform.img_transfer(resImg, matrix, (width * 2, height * 2))


cv2.imshow("resImg", cv2.resize(resImg, (resImg.shape[1] // 2, resImg.shape[0] // 2)))
cv2.waitKey(0)
