from enum import Enum, auto
import numpy as np
import cv2


class CamType(Enum):
    PINHOLE = auto()  # 針孔相機模型
    FISHEYE = auto()  # 魚眼相機模型


class Calibration:
    """張正友標定法"""

    def __init__(self, cornerNum, camType):
        """_summary_

        Args:
            cornerNum (tuple): 棋盤格校正板的內角點數 (col, row)
            camType (_type_): _description_
        """
        self.cornerNum = cornerNum
        self.camType = camType

        ### 將世界座標系的 Z 軸原點建立在標定板上
        if camType == CamType.PINHOLE:
            self.objPoint = np.zeros((cornerNum[1] * cornerNum[0], 3), np.float32)
            self.objPoint[:, :2] = np.mgrid[0 : cornerNum[0], 0 : cornerNum[1]].T.reshape(-1, 2)
        elif camType == CamType.FISHEYE:
            self.objPoint = np.zeros((1, cornerNum[1] * cornerNum[0], 3), np.float32)
            self.objPoint[0, :, :2] = np.mgrid[0 : cornerNum[0], 0 : cornerNum[1]].T.reshape(-1, 2)

        self.objPointList = list()  # 3D 世界座標標定點
        self.imgpointList = list()  # 2D 圖像棋盤格角點
        self.imgSize = None

    def add_img(self, img):
        """加入校正圖片


        Args:
            img (_type_): _description_

        Returns:
            _type_: _description_
        """
        resImg = img.copy()

        if self.imgSize is None:
            self.imgSize = (img.shape[1], img.shape[0])

        assert self.imgSize == (img.shape[1], img.shape[0]), "圖像尺寸不一致"

        ### 抓角點
        ret, corners = Calibration.find_chessboard_corners(img, self.cornerNum, subPix=True)

        if ret:
            self.objPointList.append(self.objPoint)
            self.imgpointList.append(corners)
            ### 畫角點
            cv2.drawChessboardCorners(resImg, self.cornerNum, corners, ret)
        return ret, resImg

    def solve_parm(self):
        """計算相機參數

        Returns:
            ret:
            mtx: 內參數矩陣
            dist: 畸變系數
            rvecs: 旋轉向量 (外參數)
            tvecs": 平移向量 (外參數)
        """

        if len(self.objPointList) == 0:
            print("沒有找到任何合格的圖像")
            return None, None, None, None, None
        else:
            print(f"檢測到角點的圖像共 {len(self.objPointList)} 張")

        if self.camType == CamType.PINHOLE:
            ret, mtx, dist, rvecs, tvecs = cv2.calibrateCamera(
                self.objPointList,
                self.imgpointList,
                self.imgSize,
                None,
                None,
            )

        elif self.camType == CamType.FISHEYE:
            K = np.zeros((3, 3))  # 內參初始值
            D = np.zeros((4, 1))  # 畸變係數初始值
            # K = np.array([[1000, 0, self.imgSize[0] / 2], [0, 1000, self.imgSize[1] / 2], [0, 0, 1]], dtype=np.float32)# 內參初始值
            # D = np.array([0.0, 0.0, 0.0, 0.0], dtype=np.float32)# 畸變係數初始值

            ret, mtx, dist, rvecs, tvecs = cv2.fisheye.calibrate(
                self.objPointList,
                self.imgpointList,
                self.imgSize,
                K,
                D,
            )
        return ret, mtx, dist, rvecs, tvecs

    @staticmethod
    def find_chessboard_corners(img, cornerNum, subPix=True):
        """抓出棋盤格角點

        Args:
            img (_type_): _description_
            cornerNum (_type_): 內側角點數量
            subPix (bool, optional): 進行更精確的亞像素級別的角點定位. Defaults to True.

        Returns:
            _type_: _description_
        """
        grayImg = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        ret, corners = cv2.findChessboardCornersSB(
            grayImg,
            cornerNum,
            cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE,
        )
        ### 亞像素級別的角點定位
        if subPix and ret:
            criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001)
            corners = cv2.cornerSubPix(grayImg, corners, (11, 11), (-1, -1), criteria)

        return ret, corners

    @staticmethod
    def order_points(corners, cornerNum):
        """找出棋盤格的 4 個邊界

        Args:
            corners (_type_): find_chessboard_corners() 抓到的所有角點
            cornerNum (_type_): 內側角點數量

        Returns:
            _type_: _description_
        """
        corners = np.array([coord[0] for coord in corners], dtype="float32")
        rectArr = np.zeros((4, 2), dtype="float32")
        rectArr[0] = corners[0]
        rectArr[1] = corners[cornerNum[0] - 1]
        rectArr[3] = corners[cornerNum[0] * (cornerNum[1] - 1)]
        rectArr[2] = corners[-1]

        rectList = [(int(pt[0]), int(pt[1])) for pt in rectArr]

        return rectList


class StereoCalibration:
    """雙目相機標定"""

    def __init__(self, cornerNum, camType):
        """_summary_

        Args:
            cornerNum (tuple): 棋盤格校正板的內角點數 (col, row)
            camType (_type_): _description_
        """
        self.cornerNum = cornerNum
        self.camType = camType

        ### 將世界座標系的 Z 軸原點建立在標定板上
        if camType == CamType.PINHOLE:
            self.objPoint = np.zeros((cornerNum[1] * cornerNum[0], 3), np.float32)
            self.objPoint[:, :2] = np.mgrid[0 : cornerNum[0], 0 : cornerNum[1]].T.reshape(-1, 2)
        elif camType == CamType.FISHEYE:
            self.objPoint = np.zeros((1, cornerNum[1] * cornerNum[0], 3), np.float32)
            self.objPoint[0, :, :2] = np.mgrid[0 : cornerNum[0], 0 : cornerNum[1]].T.reshape(-1, 2)

        self.objPointList = list()  # 3D 世界座標標定點
        self.imgpointList1, self.imgpointList2 = list(), list()  # 2D 圖像棋盤格角點
        self.imgSize = None

    def add_img(self, img1, img2):
        self.objPointList.append(self.objPoint)
        imgList = [img1, img2]
        for index, img in enumerate(imgList):
            resImg = img.copy()

            if self.imgSize is None:
                self.imgSize = (img.shape[1], img.shape[0])

            assert self.imgSize == (img.shape[1], img.shape[0]), "圖像尺寸不一致"

            ### 抓角點
            ret, corners = Calibration.find_chessboard_corners(img, self.cornerNum, subPix=True)

            if not ret:
                raise RuntimeError(f"第 {index} 張圖片沒有抓到角點")

            ### 畫角點
            cv2.drawChessboardCorners(resImg, self.cornerNum, corners, ret)

            if index == 0:
                self.imgpointList1.append(corners)
                resImg1 = resImg
            else:
                self.imgpointList2.append(corners)
                resImg2 = resImg

        return resImg1, resImg2

    def solve_parm(self, mtx1=None, dist1=None, mtx2=None, dist2=None):
        """計算立體標定參數

        Args:
            mtx1 (_type_, optional): _description_. Defaults to None.
            dist1 (_type_, optional): _description_. Defaults to None.
            mtx2 (_type_, optional): _description_. Defaults to None.
            dist2 (_type_, optional): _description_. Defaults to None.

        Returns:
            ret: 立體標定的重投影誤差 (RMS)
            mtx1: 相機 1 的內參矩陣
            dist1: 相機 1 的失真係數
            mtx2: 相機 2 的內參矩陣
            dist2: 相機 2 的失真係數
            R: 兩台相機之間的旋轉矩陣, 表示從相機 1 的坐標系轉換到相機 2 的坐標系的旋轉變換
            T: 兩台相機之間的平移向量, 表示從相機1的坐標系轉換到相機 2 的坐標系的平移變換
            E: 本質矩陣, 描述了兩台相機之間的對極約束
            F: 基礎矩陣, 描述了兩台相機之間的對極約束, 與本質矩陣類似, 但在圖像坐標系中表示約束
        """
        if all(x is not None for x in (mtx1, dist1, mtx2, dist2)):
            ### 已經完成單目標定, 固定相機內參
            flags = cv2.CALIB_FIX_INTRINSIC
        else:
            flags = 0

        ret, mtx1, dist1, mtx2, dist2, R, T, E, F = cv2.stereoCalibrate(
            self.objPointList,
            self.imgpointList1,
            self.imgpointList2,
            mtx1,
            dist1,
            mtx2,
            dist2,
            self.imgSize,
            flags=flags,
        )
        return ret, mtx1, dist1, mtx2, dist2, R, T, E, F

    @staticmethod
    def img_transfer(img1, img2, mtx1, dist1, mtx2, dist2, R1, R2, P1, P2):
        imgSize = img1.shape[:2][::-1]
        mapX1, mapY1 = cv2.initUndistortRectifyMap(mtx1, dist1, R1, P1, imgSize, cv2.CV_16SC2)
        mapX2, mapY2 = cv2.initUndistortRectifyMap(mtx2, dist2, R2, P2, imgSize, cv2.CV_16SC2)
        resImg1 = cv2.remap(img1, mapX1, mapY1, interpolation=cv2.INTER_LINEAR)
        resImg2 = cv2.remap(img2, mapX2, mapY2, interpolation=cv2.INTER_LINEAR)
        return resImg1, resImg2


class Distortion:
    """畸變校正"""

    ############################################
    ##              已知相機內參
    ############################################
    @staticmethod
    def img_undistort(img, mtx, dist, camType, alpha=1):
        """圖像畸變校正

        Args:
            img (_type_): _description_
            mtx (_type_): _description_
            dist (_type_): _description_
            camType (_type_): _description_
            alpha (int, optional): 自由比例參數 (0 ~ 1), 0: 最大視野, 1: 最小視野. Defaults to 1.

        Returns:
            _type_: _description_
        """
        imgSize = img.shape[:2][::-1]
        if camType == CamType.PINHOLE:
            newCameraMtx, roi = cv2.getOptimalNewCameraMatrix(mtx, dist, imgSize, alpha, imgSize)
            undistortedImg = cv2.undistort(img, mtx, dist, None, newCameraMtx)
        elif camType == CamType.FISHEYE:
            if True:
                mtxNew = mtx.copy()
                mtxNew[(0, 1), (0, 1)] *= alpha
                ### 根據魚眼相機內部參數求校正矩陣
                mapX, mapY = cv2.fisheye.initUndistortRectifyMap(mtx, dist, np.eye(3), mtxNew, imgSize, cv2.CV_16SC2)
                undistortedImg = cv2.remap(
                    img, mapX, mapY, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT
                )

            ### FIXME: yjchou 2023/01/25 修正錯誤
            else:
                mtxNew = mtx.copy()
                mtxNew = cv2.fisheye.estimateNewCameraMatrixForUndistortRectify(
                    mtx, dist, imgSize, np.eye(3), balance=alpha
                )
                mapX, mapY = cv2.fisheye.initUndistortRectifyMap(mtx, dist, np.eye(3), mtxNew, imgSize, cv2.CV_16SC2)
                undistortedImg = cv2.remap(
                    img,
                    mapX,
                    mapY,
                    interpolation=cv2.INTER_LINEAR,
                    borderMode=cv2.BORDER_CONSTANT,
                )
        return undistortedImg

    @staticmethod
    def point_transfer(srcPtsList, mtx, dist, camType, alpha=1):
        srcPts = np.array(srcPtsList, dtype=np.float64)
        mtxNew = mtx.copy()
        mtxNew[(0, 1), (0, 1)] *= alpha
        if camType == CamType.PINHOLE:
            ### FIXME: yjchou 2023/01/26 沒有測試過
            dstPts = cv2.undistortPoints(srcPts, mtx, dist, P=mtx)
            dstPtList = dstPts.astype(int).tolist()
        elif camType == CamType.FISHEYE:
            srcPts = srcPts.reshape(1, -1, 2)  # (1, N, 2)
            dstPts = cv2.fisheye.undistortPoints(srcPts, mtx, dist, None, mtxNew)
            dstPtList = dstPts.astype(int)[0].tolist()
        return dstPtList

    ############################################
    ##              經緯度校正
    ############################################
    @staticmethod
    def solve_longitude_remap(img):
        """取得經度校正矩陣

        Args:
            img (np.array): 原始圖像

        Returns:
            tuple[0] (np.array): X 座標的轉移矩陣
            tuple[1] (np.array): Y 座標的轉移矩陣
        """
        r = img.shape[0] // 2
        mapX = np.zeros([2 * r, 2 * r], dtype=np.float32)
        mapY = np.zeros([2 * r, 2 * r], dtype=np.float32)
        for i in range(mapX.shape[0]):
            for j in range(mapX.shape[1]):
                mapX[i, j] = (j - r) / r * (r**2 - (i - r) ** 2) ** 0.5 + r
                mapY[i, j] = i
        return mapX, mapY

    @staticmethod
    def solve_latitude_remap(img):
        """取得緯度校正矩陣

        Args:
            img (np.array): 原始圖像

        Returns:
            tuple[0] (np.array): X 座標的轉移矩陣
            tuple[1] (np.array): Y 座標的轉移矩陣
        """
        r = img.shape[0] // 2
        mapX = np.zeros([2 * r, 2 * r], dtype=np.float32)
        mapY = np.zeros([2 * r, 2 * r], dtype=np.float32)
        for i in range(mapX.shape[0]):
            for j in range(mapX.shape[1]):
                mapX[i, j] = j
                mapY[i, j] = (i - r) / r * (r**2 - (j - r) ** 2) ** 0.5 + r
        return mapX, mapY


class PerspectiveTransform:
    """透視變換"""

    @staticmethod
    def solve_matrix(srcPtsList, targetPtsList):
        """至少提供 4 組對應座標

        Args:
            srcPtsList (_type_): _description_
            targetPtsList (_type_): _description_

        Returns:
            _type_: _description_
        """
        srcPtsArr = np.float32(srcPtsList)
        targetPtsArr = np.float32(targetPtsList)
        matrix = cv2.getPerspectiveTransform(srcPtsArr, targetPtsArr)
        return matrix

    @staticmethod
    def img_transfer(img, matrix, targetImgSize):
        """圖像轉換

        Args:
            img (_type_): _description_
            matrix (_type_): _description_
            targetImgSize (_type_): _description_

        Returns:
            _type_: _description_
        """
        resImg = img.copy()
        resImg = cv2.warpPerspective(resImg, matrix, targetImgSize)
        return resImg

    @staticmethod
    def point_transfer(srcPtsList, matrix):
        srcPts = np.array(srcPtsList, dtype=np.float32)
        srcPts = np.expand_dims(srcPts, 0)  # 將點座標轉換為1xNx2的形狀
        dstPts = cv2.perspectiveTransform(srcPts, matrix)
        dstPtList = dstPts.squeeze().tolist()
        return dstPtList


class AffineTransform:
    """仿射變換"""

    @staticmethod
    def solve_matrix(srcPtsList, targetPtsList):
        """至少提供 3 組對應座標

        Args:
            srcPtsList (_type_): _description_
            targetPtsList (_type_): _description_

        Returns:
            _type_: _description_
        """
        srcPtsArr = np.float32(srcPtsList)
        targetPtsArr = np.float32(targetPtsList)
        matrix = cv2.getAffineTransform(srcPtsArr, targetPtsArr)
        return matrix

    @staticmethod
    def img_transfer(img, matrix, targetImgSize):
        """圖像轉換

        Args:
            img (_type_): _description_
            matrix (_type_): _description_
            targetImgSize (_type_): _description_

        Returns:
            _type_: _description_
        """
        resImg = img.copy()
        resImg = cv2.warpAffine(resImg, matrix, targetImgSize)
        return resImg


class HomographyTransform:
    """單應性變換"""

    def __init__(self) -> None:
        pass


class CamPoseEstimation:
    """相機姿態估計"""

    def solve_pnp(imgPointList, worldPointList, mtx, dist):
        """計算相機外參

        Args:
            imgPointList (_type_): _description_
            worldPointList (_type_): _description_
            mtx (_type_): _description_
            dist (_type_): _description_

        Returns:
            _type_: _description_
        """
        imgPointArr = np.array(imgPointList).astype("float32")
        worldPointArr = np.array(worldPointList).astype("float32")
        _, rvec, tvec = cv2.solvePnP(worldPointArr, imgPointArr, mtx, dist)
        return rvec, tvec

    @staticmethod
    def img_transfer(img, mtx, rvec, tvec):
        """_summary_

        Args:
            img (_type_): _description_
            rvec (_type_): _description_
            tvec (_type_): _description_
        """
        ### 計算投影矩陣
        R, _ = cv2.Rodrigues(rvec)
        RT = np.hstack((R, tvec))
        P = mtx @ RT

        ### 計算變換矩陣
        transformMatrix = P[:3, :3] / P[2, 2]

        corrImg = cv2.warpPerspective(img, transformMatrix, (img.shape[1], img.shape[0]))
        return corrImg
