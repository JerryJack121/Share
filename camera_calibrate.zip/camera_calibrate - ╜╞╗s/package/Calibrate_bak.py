from enum import Enum, auto
import numpy as np
import cv2


class CamType(Enum):
    PINHOLE = auto()  # 針孔相機模型
    FISHEYE = auto()  # 魚眼相機模型


class Calibrate:
    def __init__(self, cornerNum, camType):
        """_summary_

        Args:
            cornerNum (tuple): 棋盤格校正板的內角點數 (col, row)
            camType (_type_): _description_
        """
        self.cornerNum = cornerNum
        self.camType = camType

        ### 將世界座標系的 Z 軸原點建立在標定板上
        if camType == CamType.PINHOLE:
            self.objPoint = np.zeros((cornerNum[1] * cornerNum[0], 3), np.float32)
            self.objPoint[:, :2] = np.mgrid[0 : cornerNum[0], 0 : cornerNum[1]].T.reshape(-1, 2)
        elif camType == CamType.FISHEYE:
            self.objPoint = np.zeros((1, cornerNum[1] * cornerNum[0], 3), np.float32)
            self.objPoint[0, :, :2] = np.mgrid[0 : cornerNum[0], 0 : cornerNum[1]].T.reshape(-1, 2)

        self.objPointList = list()  # 3D 世界座標標定點
        self.imgpointList = list()  # 2D 圖像棋盤格角點
        self.imgSize = None

    def add_img(self, img):
        """加入校正圖片


        Args:
            img (_type_): _description_

        Returns:
            _type_: _description_
        """
        resImg = img.copy()

        if self.imgSize is None:
            self.imgSize = (img.shape[1], img.shape[0])
        elif self.imgSize != (img.shape[1], img.shape[0]):
            raise RuntimeError("圖像尺寸不一致")

        ### 求角點
        ret, corners = Calibrate.find_chessboard_corners(img, self.cornerNum)
        ### TODO: cv2.cornerSubPix 在原角点的基础上寻找亚像素角点

        if ret:
            self.objPointList.append(self.objPoint)
            self.imgpointList.append(corners)
            ### 畫角點
            cv2.drawChessboardCorners(resImg, self.cornerNum, corners, ret)
        return ret, resImg

    @staticmethod
    def find_chessboard_corners(img, cornerNum, subPix=True):
        """抓出棋盤格角點

        Args:
            img (_type_): _description_
            cornerNum (_type_): 內側角點數量 (row, col)
            subPix (bool, optional): 進行更精確的亞像素級別的角點定位. Defaults to True.

        Returns:
            _type_: _description_
        """
        grayImg = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        ret, corners = cv2.findChessboardCornersSB(
            grayImg, cornerNum, cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE
        )
        ### 亞像素級別的角點定位
        if subPix and ret:
            criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001)
            corners = cv2.cornerSubPix(grayImg, corners, (11, 11), (-1, -1), criteria)

        return ret, corners

    def cal_parm(self):
        """計算相機參數

        Returns:
            ret:
            mtx: 內參數矩陣
            dist: 畸變系數
            rvecs: 旋轉向量 (外參數)
            tvecs": 平移向量 (外參數)
        """

        if len(self.objPointList) == 0:
            print("沒有找到任何合格的圖像")
            return None, None, None, None, None
        else:
            print(f"檢測到角點的圖像共 {len(self.objPointList)} 張")

        if self.camType == CamType.PINHOLE:
            ret, mtx, dist, rvecs, tvecs = cv2.calibrateCamera(
                self.objPointList,
                self.imgpointList,
                self.imgSize,
                None,
                None,
            )

        elif self.camType == CamType.FISHEYE:
            K = np.zeros((3, 3))  # 內參初始值
            D = np.zeros((4, 1))  # 畸變係數初始值
            # K = np.array([[1000, 0, self.imgSize[0] / 2], [0, 1000, self.imgSize[1] / 2], [0, 0, 1]], dtype=np.float32)# 內參初始值
            # D = np.array([0.0, 0.0, 0.0, 0.0], dtype=np.float32)# 畸變係數初始值

            ret, mtx, dist, rvecs, tvecs = cv2.fisheye.calibrate(
                self.objPointList,
                self.imgpointList,
                self.imgSize,
                K,
                D,
            )
        return ret, mtx, dist, rvecs, tvecs

    @staticmethod
    def solve_pnp(imgPointList, worldPointList, mtx, dist):
        """計算相機外參

        Args:
            imgPointList (_type_): _description_
            worldPointList (_type_): _description_
            mtx (_type_): _description_
            dist (_type_): _description_

        Returns:
            _type_: _description_
        """
        imgPointArr = np.array(imgPointList).astype("float32")
        worldPointArr = np.array(worldPointList).astype("float32")
        _, rvec, tvec = cv2.solvePnP(worldPointArr, imgPointArr, mtx, dist)
        return rvec, tvec

    @staticmethod
    def img_undistort(img, mtx, dist, camType):
        """畸變校正

        Args:
            img (_type_): _description_
            mtx (_type_): _description_
            dist (_type_): _description_
            camType (_type_): _description_

        Returns:
            _type_: _description_
        """
        if camType == CamType.PINHOLE:
            undistortedImg = cv2.undistort(img, mtx, dist, None, mtx)
        elif camType == CamType.FISHEYE:
            imgSize = (img.shape[1], img.shape[0])
            ### 計算映射表
            ### TODO: yjchou 2023/01/16 儲存 map1, map2
            map1, map2 = cv2.fisheye.initUndistortRectifyMap(mtx, dist, np.eye(3), mtx, imgSize, cv2.CV_16SC2)
            undistortedImg = cv2.remap(img, map1, map2, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)
        return undistortedImg

    @staticmethod
    def img_perspective(img, mtx, rvec, tvec):
        """_summary_

        Args:
            img (_type_): _description_
            rvec (_type_): _description_
            tvec (_type_): _description_
        """
        ### 計算投影矩陣
        R, _ = cv2.Rodrigues(rvec)
        RT = np.hstack((R, tvec))
        P = mtx @ RT

        ### 計算變換矩陣
        transformMatrix = P[:3, :3] / P[2, 2]

        corrImg = cv2.warpPerspective(img, transformMatrix, (img.shape[1], img.shape[0]))
        return corrImg
