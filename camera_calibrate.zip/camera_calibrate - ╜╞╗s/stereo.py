import json
import numpy as np
import cv2
import os

from package.Calibration import CamType, StereoCalibration


def stereo(img1, img2, cornerNum):
    ### 讀取內參數
    with open("inParams.json", "r") as file:
        inParamsDict = json.load(file)
        mtx, dist = np.array(inParamsDict["mtx"]), np.array(inParamsDict["dist"])

    ### 雙目相機標定
    stereoCalibration = StereoCalibration(cornerNum, CamType.FISHEYE)
    resImg1, resImg2 = stereoCalibration.add_img(img1, img2)
    ret, mtx1, dist1, mtx2, dist2, R, T, E, F = stereoCalibration.solve_parm(mtx, dist, mtx, dist)

    ### 計算旋轉矩陣與投影矩陣
    imgSize = img1.shape[:2][::-1]
    R1, R2, P1, P2, Q, validPixROI1, validPixROI2 = cv2.stereoRectify(
        cameraMatrix1=mtx1,
        distCoeffs1=dist1,
        cameraMatrix2=mtx2,
        distCoeffs2=dist2,
        imageSize=imgSize,
        R=R,
        T=T,
        flags=cv2.CALIB_ZERO_DISPARITY,
        alpha=-1,  # 比例因子: 0~1 , 0: 只保留有像素, 1: 保留最多原始圖像, -1: 自適應
    )

    resImg1, resImg2 = StereoCalibration.img_transfer(img1, img2, mtx1, dist1, mtx2, dist2, R1, R2, P1, P2)

    return resImg1, resImg2


if __name__ == "__main__":
    cornerNum = (11, 8)
    filePathList = [
        r"images\calibrate\undistorted_20240118_113523.jpg",
        # r"images\calibrate\undistorted_20240118_113537.jpg",
        # r"images\calibrate\undistorted_20240118_113551.jpg",
        r"images\calibrate\undistorted_20240118_113545.jpg",
    ]

    img1FilePath = filePathList[0]
    img1FileName = os.path.basename(img1FilePath)
    img1 = cv2.imread(img1FilePath)
    for filePath in filePathList[1:]:
        img2 = cv2.imread(filePath)
        img2FileName = os.path.basename(filePath)
        resImg1, resImg2 = stereo(img1, img2, cornerNum)
        cv2.imwrite(f"stereo_{img2FileName}", resImg2)
    cv2.imwrite(f"stereo_{img1FileName}", resImg1)
