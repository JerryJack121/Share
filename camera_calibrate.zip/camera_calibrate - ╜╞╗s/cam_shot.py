import cv2
import datetime

# 設定 rtsp 影像串流 URL
# rtsp_url = "rtsp://admin:Auo+84149738@192.168.0.100:7070"
rtsp_url = 0


# 建立 VideoCapture 物件
cap = cv2.VideoCapture(rtsp_url)

# 顯示影像串流並等待鍵盤事件
while True:
    ret, frame = cap.read()
    cv2.imshow("frame", frame)
    key = cv2.waitKey(1) & 0xFF
    if key == ord("q"):
        # 按下 q 鍵時，結束程式
        break
    # 按下 s 鍵時，儲存圖片
    elif key == ord("s"):
        now = datetime.datetime.now()
        imgName = datetime.datetime.strftime(now, "%Y%m%d_%H%M%S") + '.jpg'
        cv2.imwrite(imgName, frame)
        print(imgName)


# 釋放資源並關閉視窗
cap.release()
cv2.destroyAllWindows()
