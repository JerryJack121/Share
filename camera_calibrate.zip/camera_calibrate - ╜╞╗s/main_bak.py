import cv2
import numpy as np
from enum import Enum, auto


class CameraType(Enum):
    PINHOLE = auto()  # 針孔相機模型
    FISHEYE = auto()  # 魚眼相機模型


def main(cameraType, imgPathList, calibratePointArr):
    ### 準備物體點
    cornerNum = (calibratePointArr.shape[1], calibratePointArr[0])

    calibratePointList = []  # 3D 世界座標標定點
    imgpointList = []  # 2D 圖像棋盤格角點
    for imgPath in imgPathList:
        ### 讀取校準圖像(包含棋盤格)
        img = cv2.imread(imgPath)
        grayImg = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        ### 提取角點
        ret, corners = cv2.findChessboardCornersSB(grayImg, cornerNum, None)

        if ret:
            calibratePointList.append(calibratePointArr)
            imgpointList.append(corners)
        else:
            print("未檢測到角點")

    if cameraType == CameraType.PINHOLE:
        ### 計算針孔相機校正參數
        imgSize = grayImg.shape[::-1]
        ret, mtx, dist, rvecs, tvecs = cv2.calibrateCamera(calibratePointList, imgpointList, imgSize, None, None)

        ### 去除針孔相機畸變
        undistortedImg = cv2.undistort(img, mtx, dist, None, mtx)

    elif cameraType == CameraType.FISHEYE:
        ### 計算魚眼相機校正參數
        imgSize = grayImg.shape[::-1]
        K = np.zeros((3, 3))
        D = np.zeros((4, 1))
        ret, K, D, rvecs, tvecs = cv2.fisheye.calibrate(calibratePointList, imgpointList, imgSize, K, D)

        ### 去除魚眼相機畸變
        map1, map2 = cv2.fisheye.initUndistortRectifyMap(K, D, np.eye(3), K, imgSize, cv2.CV_16SC2)
        undistortedImg = cv2.remap(img, map1, map2, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)


if __name__ == "__main__":
    ### 棋盤格角點在世界座標系中的座標
    # calibratePointArr = np.array([
    # [x1, y1, 0],
    # [x2, y2, 0],
    # [x3, y3, 0],
    # [x4, y4, 0],
    # [x5, y5, 0],
    # [x6, y6, 0],
    # [x7, y7, 0],
    # [x8, y8, 0],
    # [x9, y9, 0],
    # ], dtype=np.float32)

    ### 假資料
    calibratePointArr = np.zeros((6 * 9, 3), np.float32)
    calibratePointArr[:, :2] = np.mgrid[0:9, 0:6].T.reshape(-1, 2)

    main(
        cameraType=CameraType.PINHOLE,
        imgPathList=["calib1.jpg", "calib2.jpg", "calib3.jpg"],
        calibratePointArr=calibratePointArr,
    )
