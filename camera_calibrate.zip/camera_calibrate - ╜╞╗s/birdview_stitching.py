import cv2
import numpy as np
import math
import json
import os

from package.Calibration import Calibration, Distortion, PerspectiveTransform, CamType


def img_preprocess(img, center_x, center_y, radius):
    resImg = img[
        center_y - radius : center_y + radius,
        center_x - radius : center_x + radius,
    ]
    return resImg


def main(dataDictList, overlapNum):
    ### 讀取內參數
    with open("inParams.json", "r") as file:
        inParamsDict = json.load(file)
        mtx, dist = np.array(inParamsDict["mtx"]), np.array(inParamsDict["dist"])

    targetSize = (5000, 5000)

    resImg = None
    wordCoordDict = dict()
    for overlapId in range(1, overlapNum + 1):
        wordCoordDict[str(overlapId)] = None

    for id, dataDict in enumerate(dataDictList):
        imgPath = dataDict["imgPath"]
        img = cv2.imread(imgPath)
        imgName = os.path.basename(imgPath)

        # ##########################################
        # ##              畸變校正
        # ##########################################
        if False:
            ### 裁掉黑色區域
            # img = img_preprocess(img, center_x=2048 // 2, center_y=1536 // 2, width=1536, height=1536)
            img = img_preprocess(img, center_x=1070, center_y=1536 // 2, radius=1536 // 2)

            ### 圖像畸變校正 (張氏標定法)
            undistortedImg = Distortion.img_undistort(img, mtx, dist, CamType.FISHEYE)
        else:
            undistortedImg = img

        ##########################################
        ##              標定
        ##########################################
        overlapDict = dataDict["overlapDict"]
        for overlapId, srcPtsList in overlapDict.items():
            if srcPtsList is None:
                ### 這張圖片沒有當前拼接中的重疊範圍
                continue

            ### 對齊第一張圖片的標定點
            if wordCoordDict[overlapId] is None:
                ### 準備透視變換後的目標點
                boardWidth = int(
                    math.sqrt((srcPtsList[1][0] - srcPtsList[0][0]) ** 2 + (srcPtsList[1][1] - srcPtsList[0][1]) ** 2)
                )
                boardHeight = int(
                    math.sqrt((srcPtsList[2][0] - srcPtsList[1][0]) ** 2 + (srcPtsList[2][1] - srcPtsList[1][1]) ** 2)
                )

                ### 移動棋盤格左上角的座標, 避免校正後圖片被裁切
                width, height = img.shape[:2][::-1]
                size = max(width, height)
                origin = tuple((srcPtsList[0][0] + size // 2, srcPtsList[0][1] + size // 2))

                ### 維持棋盤格在原畫面中的大小
                targetPtsList = [
                    [origin[0], origin[1]],
                    [origin[0] + boardWidth, origin[1]],
                    [origin[0] + boardWidth, origin[1] + boardHeight],
                    [origin[0], origin[1] + boardHeight],
                ]
                wordCoordDict[overlapId] = targetPtsList
            else:
                targetPtsList = wordCoordDict[overlapId]

            ##########################################
            ##         平視校正 & 投影到世界座標
            ##########################################
            ### 透視變換
            matrix = PerspectiveTransform.solve_matrix(srcPtsList, targetPtsList)
            perspectiveImg = PerspectiveTransform.img_transfer(undistortedImg, matrix, targetSize)
            cv2.imshow(
                f"perspectiveImg_{imgName}",
                cv2.resize(
                    perspectiveImg,
                    (targetSize[0] // 2, targetSize[1] // 2),
                ),
            )

            if resImg is None:
                resImg = perspectiveImg
            ### 圖像合併
            else:
                resImg = cv2.addWeighted(src1=resImg, alpha=0.5, src2=perspectiveImg, beta=0.5, gamma=0)

            ##########################################
            ##      TODO: 更新圖像中其他的標定點
            ##########################################
            for otherOverlap in range(int(overlapId) + 1, overlapNum + 1):
                srcPtsList = overlapDict[str(otherOverlap)]
                if srcPtsList is None:
                    continue
                newTargetPtList = PerspectiveTransform.point_transfer(srcPtsList, matrix)

                ### 透視變換後新的標定點
                wordCoordDict[str(otherOverlap)] = newTargetPtList
            ### 每張圖片只做一次校正
            break
    cv2.imshow("resImg", cv2.resize(resImg, (targetSize[0] // 2, targetSize[1] // 2)))
    cv2.imwrite("resImg.jpg", resImg)
    cv2.waitKey(0)


if __name__ == "__main__":
    overlapNum = 2
    dataDictList = [
        {
            "imgPath": r"images\1_undistort\undistortedImg_20240125_092919.jpg",
            "overlapDict": {
                "1": [[796, 799], [603, 757], [667, 563], [836, 600]],
                "2": None,
            },
        },
        {
            "imgPath": r"images\1_undistort\undistortedImg_20240125_093014.jpg",
            "overlapDict": {
                "1": [[630, 1118], [474, 966], [647, 776], [802, 913]],
                "2": [[919, 821], [724, 675], [839, 542], [1019, 672]],
            },
        },
        {
            "imgPath": r"images\1_undistort\undistorted_20240125_093053.jpg",
            "overlapDict": {
                "1": None,
                "2": [[668, 1069], [533, 868], [678, 748], [833, 939]],
            },
        },
    ]

    # overlapNum = 2
    # dataDictList = [
    #     {
    #         "imgPath": r"images\1_undistort\newUndistotedImg_cam1.png",
    #         "overlapDict": {
    #             "1": [[1142, 858], [1191, 718], [1437 + 50, 754], [1438, 889]],
    #             "2": None,
    #         },
    #     },
    #     {
    #         "imgPath": r"images\1_undistort\newUndistotedImg_cam2.png",
    #         "overlapDict": {
    #             "1": [[383, 692], [421, 550], [765, 566], [775, 719]],
    #             "2": [[518, 830], [776, 847], [761, 1003], [521, 994]],
    #         },
    #     },
    #     {
    #         "imgPath": r"images\1_undistort\newUndistotedImg_cam3.png",
    #         "overlapDict": {
    #             "1": None,
    #             "2": [[788, 222], [992, 232], [1011, 380], [787, 332]],
    #         },
    #     },
    # ]

    # overlapNum = 1
    # dataDictList = [
    #     {
    #         "imgPath": r"images\1_undistort\SiDaDun\cam3_1.jpg",
    #         "overlapDict": {
    #             "1": [[939, 1531], [1180, 1534], [1176, 1603], [942, 1595]],
    #         },
    #     },
    #     {
    #         "imgPath": r"images\1_undistort\SiDaDun\cam4_1.jpg",
    #         "overlapDict": {
    #             "1": [[495, 1324], [630, 1339], [635, 1412], [503, 1415]],
    #         },
    #     },
    # ]
    main(dataDictList, overlapNum)
