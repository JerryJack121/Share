import cv2
import numpy as np
import json

from package.Calibration import Calibration, CamType, Distortion, PerspectiveTransform, AffineTransform


def img_preprocess(img, center_x, center_y, radius):
    resImg = img[
        center_y - radius : center_y + radius,
        center_x - radius : center_x + radius,
    ]
    return resImg


def new_method(img, layoutImg):
    layoutImg = layoutImg.copy()
    srcPtsList = [[305, 863], [977, 891], [997, 223], [305, 223]]
    layoutPtsList = [[778, 629], [779, 112], [371, 124], [371, 629]]
    layoutRegion = [[341, 39], [850, 628]]

    targetPtsList = list()
    for layoutPoint in layoutPtsList:
        targetPtsList.append([(layoutPoint[0] - layoutRegion[0][0]), layoutPoint[1] - layoutRegion[0][1]])
    newImgSize = (layoutRegion[1][0] - layoutRegion[0][0], layoutRegion[1][1] - layoutRegion[0][1])

    # for layoutPoint in layoutPtsList:
    #     targetPtsList.append(layoutPoint)
    # newImgSize = layoutImg.shape[:2][::-1]

    ### 讀取內部參數
    with open("inParams.json", "r") as file:
        inParamsDict = json.load(file)
        mtx, dist = np.array(inParamsDict["mtx"]), np.array(inParamsDict["dist"])

    undistortedImg = undistort(img, mtx, dist)
    matrix = PerspectiveTransform.solve_matrix(srcPtsList, targetPtsList)
    transferImg = PerspectiveTransform.img_transfer(undistortedImg, matrix, newImgSize)

    ### 拼接到平面圖
    layoutImg[layoutRegion[0][1] : layoutRegion[1][1], layoutRegion[0][0] : layoutRegion[1][0]] = transferImg
    # layoutImg[layoutRegion[0][1] : layoutRegion[1][1], layoutRegion[0][0] : layoutRegion[1][0]] = transferImg[
    #     layoutRegion[0][1] : layoutRegion[1][1], layoutRegion[0][0] : layoutRegion[1][0]
    # ]

    cv2.imshow("newUndistortedImg", undistortedImg)
    cv2.imshow("newLayoutImg", layoutImg)


def undistort(img, mtx, dist):
    undistortedImg = Distortion.img_undistort(img, mtx, dist, CamType.FISHEYE)
    return undistortedImg


def org_method(img, layoutImg):
    layoutImg = layoutImg.copy()
    srcPtsList = []
    layoutPtsList = []
    layoutRegion = ()

    targetPtsList = list()
    for layoutPoint in layoutPtsList:
        targetPtsList.append([(layoutPoint[0] - layoutRegion[0][0]), layoutPoint[1] - layoutRegion[0][1]])
    # newImgSize = (layoutRegion[1][0] - layoutRegion[0][0], layoutRegion[1][1] - layoutRegion[0][1])

    img = cv2.resize(img, (2160, 2160))

    ### 讀取經緯度校正矩陣
    distortionCorrMatix = [
        np.load(r"distortion_corr_matix_mapx.npy"),
        np.load(r"distortion_corr_matix_mapy.npy"),
    ]
    undistortedImg = org_undistort(img, distortionCorrMatix)

    # matrix = AffineTransform.solve_matrix(srcPtsList, targetPtsList)
    # transferImg = AffineTransform.img_transfer(undistortedImg, matrix, newImgSize)

    # ### 拼接到平面圖
    # layoutImg[layoutRegion[0][1] : layoutRegion[1][1], layoutRegion[0][0] : layoutRegion[1][0]] = transferImg

    cv2.imshow("orgUndistortedImg", undistortedImg)
    cv2.imshow("orgLayoutImg", layoutImg)


def org_undistort(img, distortionCorrMatix):
    undistortedImg = img.copy()
    mapxList, mapyList = distortionCorrMatix
    for i in range(mapxList.shape[0]):
        ### 圖像重映射
        undistortedImg = cv2.remap(
            undistortedImg,
            mapxList[i],
            mapyList[i],
            interpolation=cv2.INTER_NEAREST,
            borderMode=cv2.BORDER_CONSTANT,
        )
    return undistortedImg


imgPath = r"D:\UserShare\Coding\camera_calibrate\images\cam3_1.jpg"
layoutImgPath = r"D:\UserShare\Coding\camera_calibrate\images\atc_layout.jpg"
img = cv2.imread(imgPath)
layoutImg = cv2.imread(layoutImgPath)
# img = img_preprocess(img, center_x=2048 // 2, center_y=1536 // 2, radius=1536//2)
img = img_preprocess(img, center_x=1070, center_y=1536 // 2, radius=1536 // 2)

cv2.imshow("img", img)
new_method(img, layoutImg)
org_method(img, layoutImg)
cv2.waitKey(0)
