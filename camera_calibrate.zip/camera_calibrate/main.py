import cv2
import os
import json
import numpy as np


from package.Calibrate import Calibrate, CamType


def calibrate_camera(imgPathList, cornerNum, camType, visulize=True):
    """拍攝多張圖片, 求相機的內外參數

    Args:
        imgPathList (_type_): _description_
        cornerNum (_type_): _description_
        cameraType (_type_): _description_
    """

    calibrate = Calibrate(cornerNum, camType)
    for imgPath in imgPathList:
        imgName = os.path.basename(imgPath)
        ### 讀取校準圖像(包含棋盤格)
        img = cv2.imread(imgPath)

        ### 加入校正圖片
        ret, resImg = calibrate.add_img(img)
        if ret:
            resImg = cv2.resize(resImg, (resImg.shape[1] // 2, resImg.shape[0] // 2))
            if visulize:
                cv2.imshow("imgName", resImg)
                cv2.waitKey(0)
                cv2.destroyAllWindows()
        else:
            print(f"{imgName} 未檢測到角點")

    ### 計算相機參數
    ret, mtx, dist, rvecs, tvecs = calibrate.cal_parm()

    return ret, mtx, dist, rvecs, tvecs


def img_corr(imgPathList, mtx, dist, rvec, tvec, camType):
    for imgPath in imgPathList:
        imgName = os.path.basename(imgPath)
        img = cv2.imread(imgPath)

        ### 圖像畸變校正
        undistortedImg = Calibrate.img_undistort(img, mtx, dist, camType)

        ### 圖像座標投影至世界座標
        corrImg = Calibrate.img_perspective(undistortedImg, mtx, rvec, tvec)

        img = cv2.resize(img, (img.shape[1] // 2, img.shape[0] // 2))
        undistortedImg = cv2.resize(undistortedImg, (undistortedImg.shape[1] // 2, undistortedImg.shape[0] // 2))
        corrImg = cv2.resize(corrImg, (corrImg.shape[1] // 2, corrImg.shape[0] // 2))

        cv2.imshow(imgName, img)
        cv2.imshow(f"undistort_{imgName}", undistortedImg)
        cv2.imshow(f"corrected_{imgName}", corrImg)
        cv2.waitKey(0)
        cv2.destroyAllWindows()


if __name__ == "__main__":
    ##########################################
    ##              相機標定
    ##########################################
    # imgPathList = [r".\images\111.jpg"]
    # cornerNum = (6, 4)  # (col, row)
    # camType = CamType.PINHOLE

    imgPathList = [r".\images\fishey.jpg"]
    cornerNum = (6, 9)
    camType = CamType.FISHEYE

    ### 多張圖片求相機內外參數
    ret, mtx, dist, rvecs, tvecs = calibrate_camera(
        imgPathList=imgPathList,
        cornerNum=cornerNum,
        camType=camType,
        visulize=True,
    )
    if ret:
        inParamsDict = {"mtx": mtx.tolist(), "dist": dist.tolist()}
    else:
        print("校正失敗")

    # print("mtx:\n", mtx)  # 內參數矩陣
    # print("dist:\n", dist)  # 畸變系數   distortion cofficients = (k_1,k_2,p_1,p_2,k_3)
    # print("rvecs:\n", rvecs)  # 旋轉向量 (外參數)
    # print("tvecs:\n", tvecs)  # 平移向量 (外參數)

    ### 相機固定後透過 PnP 求外參
    ### 假資料
    imgPointList = [[416, 268], [422, 535], [826, 543], [829, 264]]  # 圖像平面的 2 維座標
    worldPointList = [[0, 0, 0], [297, 0, 0], [297, 210, 0], [0, 210, 0]]  # 世界座標的 3 維座標
    rvec, tvec = Calibrate.solve_pnp(imgPointList, worldPointList, mtx, dist)

    exParamsDict = {"rvec": rvec.tolist(), "tvec": tvec.tolist()}

    ### 儲存內外參數
    with open("inParams.json", "w") as file:
        json.dump(inParamsDict, file)
    with open("exParams.json", "w") as file:
        json.dump(exParamsDict, file)

    ##########################################
    ##              圖像校正
    ##########################################
    ### 讀取內外參數
    with open("inParams.json", "r") as file:
        inParamsDict = json.load(file)
        mtx, dist = np.array(inParamsDict["mtx"]), np.array(inParamsDict["dist"])
    with open("exParams.json", "r") as file:
        exParamsDict = json.load(file)
        rvec, tvec = np.array(exParamsDict["rvec"]), np.array(exParamsDict["tvec"])

    img_corr(imgPathList, mtx, dist, rvec, tvec, camType)
