from configparser import ConfigParser
import json


class Config(object):
    def __init__(self):
        config = ConfigParser()

        class System:
            def __init__(self, cfgFilePath) -> None:
                config.read(cfgFilePath, encoding="utf-8")
                self.device = config.get("AIModel", "Device")
                self.modelWeightPath = config.get("AIModel", "WeightPath")
                self.maskVisualize = config.getboolean("Visualize", "Mask")
                self.peopleCntVisualize = config.getboolean("Visualize", "PeopleCnt")
                self.fenceVisualize = config.getboolean("Visualize", "Fence")
                self.stayTrackerVisualize = config.getboolean("Visualize", "StayTracker")
                self.heatmapVisualize = config.getboolean("Visualize", "Heatmap")
                self.debugMode = config.getboolean("System", "debugMode")
                self.settingFilePathDict = dict()
                for sysName, settingFilePath in config.items("SettingFilePath"):
                    ### config 讀進來的Key值都是小寫
                    self.settingFilePathDict[sysName] = settingFilePath

                self.restartTime = config.get("System", "restartTime")
                config.clear()

        class Switch:
            def __init__(self, cfgFilePath) -> None:
                config.read(cfgFilePath, encoding="utf-8")
                self.AISwitch = config.getboolean("Switch", "AISwitch")
                config.clear()

        class Cam:
            def __init__(self, cfgFilePath) -> None:
                config.read(cfgFilePath, encoding="utf-8")
                self.cam1Path = config.get("Source", "Cam1")
                self.cam2Path = config.get("Source", "Cam2")
                self.cam3Path = config.get("Source", "Cam3")
                self.cam4Path = config.get("Source", "Cam4")
                self.cam1Path = None if self.cam1Path == "None" else self.cam1Path
                self.cam2Path = None if self.cam2Path == "None" else self.cam2Path
                self.cam3Path = None if self.cam3Path == "None" else self.cam3Path
                self.cam4Path = None if self.cam4Path == "None" else self.cam4Path
                self.size = config.getint("Parameter", "CamSize")
                self.videoMode = config.getboolean("Parameter", "VideoMode")
                config.clear()

        class Api:
            def __init__(self, cfgFilePath) -> None:
                config.read(cfgFilePath, encoding="utf-8")
                url = config.get("Url", "Url")
                self.initUrl = url + config.get("Api", "initApi")
                self.heatmapUrl = url + config.get("Api", "heatmapApi")
                self.areaVisitorUrl = url + config.get("Api", "areaVisitorApi")
                self.addAvgTimeUrl = url + config.get("Api", "addAvgTimeApi")
                self.modifyAvgTimeUrl = url + config.get("Api", "ModifyAvgTimeApi")
                self.postInerval = config.getfloat("Parameter", "postInerval")
                config.clear()

        class Server:
            def __init__(self, cfgFilePath) -> None:
                config.read(cfgFilePath, encoding="utf-8")
                self.host = config.get("Server", "Host")
                self.port = config.getint("Server", "Port")
                config.clear()

        class Mask:
            def __init__(self, cfgFilePath) -> None:
                with open(cfgFilePath, encoding="utf-8") as f:
                    data = json.load(f)
                    self.maskList = data["maskList"]
                f.close()

        class PeoPleCnt:
            def __init__(self, cfgFilePath) -> None:
                with open(cfgFilePath, encoding="utf-8") as f:
                    data = json.load(f)
                    self.entry = data["entry"]
                    self.exit = data["exit"]
                    self.maxSize = data["maxSize"]
                f.close()

        class Fence:
            def __init__(self, cfgFilePath) -> None:
                with open(cfgFilePath, encoding="utf-8") as f:
                    data = json.load(f)
                    self.fenceDict = data["fenceDict"]
                f.close()

        class StayTracker:
            def __init__(self, cfgFilePath) -> None:
                with open(cfgFilePath, encoding="utf-8") as f:
                    data = json.load(f)
                    self.fenceDict = data["fenceDict"]
                f.close()

        class Calibrate:
            def __init__(self, cfgFilePath) -> None:
                with open(cfgFilePath, encoding="utf-8") as f:
                    data = json.load(f)
                    self.distortionCorrMapXPath = data["distortionCorrMapX"]
                    self.distortionCorrMapYPath = data["distortionCorrMapY"]
                    self.affineMatrixPathDict = data["affineMatrixPathDict"]
                f.close()

        class Layout:
            def __init__(self, cfgFilePath) -> None:
                with open(cfgFilePath, encoding="utf-8") as f:
                    data = json.load(f)
                    self.layoutImgPath = data["layoutImgPath"]
                    self.layoutRegionList = data["layoutRegionList"]
                f.close()

        class Log:
            def __init__(self, cfgFilePath) -> None:
                config.read(cfgFilePath, encoding="utf-8")
                self.logFolderPath = config.get("Log", "logFolderPath")
                self.logfileName = config.get("Log", "logfileName")
                self.maxMB = config.getint("Log", "maxMB")
                self.backupCount = config.getint("Log", "backupCount")
                config.clear()

        self.system = System(r"data\config\system.cfg")
        self.switch = Switch(self.system.settingFilePathDict["switch"])
        self.cam = Cam(self.system.settingFilePathDict["cam"])
        self.api = Api(self.system.settingFilePathDict["webapi"])
        self.server = Server(self.system.settingFilePathDict["webserver"])
        self.mask = Mask(self.system.settingFilePathDict["mask"])
        self.peopleCnt = PeoPleCnt(self.system.settingFilePathDict["peoplecnt"])
        self.fence = Fence(self.system.settingFilePathDict["fence"])
        self.stayTracker = StayTracker(self.system.settingFilePathDict["staytracker"])
        self.calibrate = Calibrate(self.system.settingFilePathDict["calibrate"])
        self.layout = Layout(self.system.settingFilePathDict["layout"])
        self.log = Log(self.system.settingFilePathDict["log"])
