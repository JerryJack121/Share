### 停留人數計數 (進店人數), 只支援單一攝影機
import cv2
import sys

sys.path.append("./")
from packages.CentroidTracker import CentroidTracker


class StayPeopleCnt:
    def __init__(self, entry, stayFrame, cntDay=0, maxSize=99, visualize=False):
        self.cntNow = 0
        self.maxSize = maxSize
        self.area = entry
        self.cntDay = cntDay
        self.visualize = visualize
        self.entryCamId = entry["camID"]
        self.entryArea = entry["area"]
        self.entryLines = entry["lines"]
        self.entryinIdList = list()
        self.entryPtDictList, self.historyEntryPtDictList = dict(), dict()
        self.stayArea = line2area(self.entryLines)
        self.entryTracker = CentroidTracker(maxDisappeared=2)
        self.stayFrame = stayFrame
        self.trackIdDict = dict()
        self.stayList = list()

    def cnt(self, dataDictList):
        for dataDict in dataDictList:
            if dataDict["camId"] == self.entryCamId:
                inNum, outNum, dayInNum = self.__cnt_stay_people(dataDict)

        self.cntNow = self.cntNow + inNum - outNum

        ### 邊界條件, 避免出現負值
        if self.cntNow < 0:
            self.cntNow = 0

        self.cntDay = self.cntDay + dayInNum
        return self.cntNow, self.cntDay

    def __cnt_stay_people(self, dataDict):
        inNum, outNum, dayInNum = 0, 0, 0
        pointList = dataDict["point"]

        if self.visualize:
            self.entryImg = dataDict["corrImg"].copy()

        self.pointInEntryArea = list()
        ### 在入口區域的點座標
        for point in pointList:
            if self.is_point_in_area(point, self.entryArea):
                self.pointInEntryArea.append(point)

        ### 點座標追蹤
        self.historyEntryPtDictList = self.entryPtDictList
        self.entryPtDictList = dict()
        objects = self.entryTracker.update(self.pointInEntryArea)
        for objectID, centroid in objects.items():
            self.entryPtDictList[objectID] = dict()
            self.entryPtDictList[objectID]["objectID"] = objectID
            self.entryPtDictList[objectID]["point"] = tuple((centroid[0], centroid[1]))

        ### FIXME:
        for personId, ptDict in self.entryPtDictList.items():
            point = ptDict["point"]
            ### 上一幀ID存在
            if personId in self.historyEntryPtDictList.keys():
                lastPoint = self.historyEntryPtDictList[personId]["point"]
                howCrossLine = self.__cross_line(self.entryLines, point, lastPoint)
                if howCrossLine != None:
                    # print(f"iD: {personId}, {howCrossLine}")
                    if howCrossLine == "Unknow":
                        ### 忽略剛好在計數線上的那一幀
                        self.entryPtDictList[personId]["point"] = self.historyEntryPtDictList[personId]["point"]
                    ### 過線後開始追蹤停留時間
                    elif howCrossLine:
                        self.trackIdDict[personId] = {"stay": 0, "disappear": 0}
                    ### 離開計數線時判斷是否有被計算過人數
                    else:
                        if personId in self.stayList:
                            outNum += 1

            ### 移除舊的暫存
            if len(self.entryinIdList) > self.maxSize:
                self.entryinIdList.pop(0)

        ### FIXME:
        ### 判斷追蹤的 ID 是否還存在
        for id in self.trackIdDict:
            if id in self.entryPtDictList.keys():
                if self.is_point_in_area(self.entryPtDictList[id]["point"], self.stayArea):
                    self.trackIdDict[id]["stay"] += 1
                else:
                    self.trackIdDict[id]["disappear"] += 1

        ### 處理停留時間夠久的 ID 與 離開的 ID
        delIdList = list()
        for id in self.trackIdDict.keys():
            ### 處理停留時間夠久
            if self.trackIdDict[id]["stay"] >= self.stayFrame:
                self.stayList.append(id)
                inNum += 1
                delIdList.append(id)
            ### 消失太久的 ID
            elif self.trackIdDict[id]["disappear"] >= 10:
                delIdList.append(id)

        for delId in delIdList:
            del self.trackIdDict[delId]

        ### 移除舊的暫存
        if len(self.stayList) > self.maxSize:
            self.stayList.pop(0)

        dayInNum = inNum
        return inNum, outNum, dayInNum

    def __cross_line(self, lines, point, lastPoint):
        """判斷是否滿足計數線規則

        Args:
            lines (_type_): _description_
        """
        ### ID 沒有移動
        if point[0] == lastPoint[0] and point[1] == lastPoint[1]:
            return None

        ### 判斷路徑是否跨越計數線
        result = None
        for line in lines:
            linePoint1, linePoint2, rule = line

            # 兩線段沒有交點
            if (
                min(point[0], lastPoint[0]) > max(linePoint1[0], linePoint2[0])
                or max(point[0], lastPoint[0]) < min(linePoint1[0], linePoint2[0])
                or min(point[1], lastPoint[1]) > max(linePoint1[1], linePoint2[1])
                or max(point[1], lastPoint[1]) < min(linePoint1[1], linePoint2[1])
            ):
                tmpResult = None
                continue

            ### 計數線為水平線
            if linePoint1[1] == linePoint2[1]:
                # print(f"{lastPoint}->{point}")
                if point[1] == linePoint1[1]:
                    ### 剛好停在線上
                    return "Unknow"
                elif (point[1] - lastPoint[1]) * rule * -1 > 0:
                    tmpResult = True
                else:
                    tmpResult = False

            ### 計數線為垂直線
            elif linePoint1[0] == linePoint2[0]:
                # print(f"{lastPoint}->{point}")
                if point[0] == linePoint1[0]:
                    ### 剛好停在線上
                    return "Unknow"
                elif (point[0] - lastPoint[0]) * rule > 0:
                    tmpResult = True
                else:
                    tmpResult = False

            else:
                errorMsg = "計數線設定錯誤: 只支援水平線和垂直線的組合"
                self.logger.error(errorMsg)
                raise (errorMsg)

            if result is None:
                result = tmpResult
            elif result != tmpResult:
                ### 同時跨越兩條計數線且結果有加有減
                return None

        return result

    def is_point_in_area(self, point, area):
        x, y = point[0], point[1]
        if x < area[0][0] or x > area[1][0] or y < area[0][1] or y > area[1][1]:
            return False
        else:
            return True


def line2area(lines):
    tmpX1, tmpX2, tmpY1, tmpY2 = None, None, None, None

    ### 計數線圍成的最小區域
    for line in lines:
        linePoint1, linePoint2, rule = line
        x1, y1 = linePoint1
        x2, y2 = linePoint2
        if tmpX1 is None:
            tmpX1, tmpX2, tmpY1, tmpY2 = x1, x2, y1, y2
        else:
            if x1 < tmpX1:
                tmpX1 = x1
            if y1 < tmpY1:
                tmpY1 = y1
            if x2 > tmpX2:
                tmpX2 = x2
            if y2 > tmpY2:
                tmpY2 = y2

    return ((tmpX1, tmpY1), (tmpX2, tmpY2))


def draw_area(img, bbox):
    resImg = img.copy()
    x1, y1, x2, y2 = int(bbox[0][0]), int(bbox[0][1]), int(bbox[1][0]), int(bbox[1][1])
    cv2.rectangle(resImg, (x1, y1), (x2, y2), color=(0, 0, 255), thickness=2)
    return resImg


def draw_pts(img, pts):
    rstImg = img.copy()
    for pt in pts:
        cv2.circle(rstImg, pt, 5, (0, 0, 255), -1)
    return rstImg
