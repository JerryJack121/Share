import pandas as pd
import os
import sys
import datetime


sys.path.append("./")
from packages.ScheduleManger import Scheduler


class FileDB:
    def __init__(self, filePath, minutes=5):
        self.filePath = filePath
        self.cntDay, self.stayCntDay = None, None

        ### 確認 csv 檔案存在
        columns = ["日期", "當日客流量", "當日進店人數", "更新時間"]
        if not os.path.isfile(self.filePath):
            df = pd.DataFrame(columns=columns)
            df.to_csv(self.filePath, index=False, encoding="utf-8_sig")

        ### 建立排程
        Scheduler.create_reapeat_job(minutes=minutes, job=self.write_db)

    def update(self, cntDay, stayCntDay):
        """更新人流資訊

        Args:
            cntDay (_type_): _description_
            stayCntDay (_type_): _description_
        """
        self.cntDay = cntDay
        self.stayCntDay = stayCntDay

    def write_db(self):
        """輸出 csv"""
        if self.cntDay or self.stayCntDay is not None:
            now = datetime.datetime.now()
            updateTime = datetime.datetime.strftime(now, "%y-%m-%d %H:%M:%S")
            date = datetime.datetime.strftime(now, "%y-%m-%d")
            df = pd.read_csv(self.filePath)

            if df.shape[0] == 0:
                ### 新增第一筆資料
                newData = {
                    "日期": date,
                    "當日客流量": self.cntDay,
                    "當日進店人數": self.stayCntDay,
                    "更新時間": updateTime,
                }
                df = df.append(newData, ignore_index=True)
            else:
                db_last_date = df.iloc[-1, :]["日期"]
                if db_last_date == date:
                    ### 修改最後一筆資料
                    data = {
                        "日期": date,
                        "當日客流量": self.cntDay,
                        "當日進店人數": self.stayCntDay,
                        "更新時間": updateTime,
                    }
                    df.iloc[-1, :] = data
                else:
                    ### 新增下一筆資料
                    newData = {
                        "日期": date,
                        "當日客流量": self.cntDay,
                        "當日進店人數": self.stayCntDay,
                        "更新時間": updateTime,
                    }
                    df = df.append(newData, ignore_index=True)

            df.to_csv(self.filePath, index=False, encoding="utf-8_sig")

    def get_init_data(self):
        """載入當天的最後一筆資料"""
        now = datetime.datetime.now()
        date = datetime.datetime.strftime(now, "%y-%m-%d")
        df = pd.read_csv(self.filePath)
        if df.shape[0] > 0:
            lastData = df.iloc[-1, :]
            db_last_date = lastData["日期"]
            if db_last_date == date:
                initDataDict = {
                    "idList": list((0 for i in range(1, 9))),
                    "cntDay": lastData["當日客流量"],
                    "stayCntDay": lastData["當日進店人數"],
                }
                return initDataDict
        initDataDict = {"idList": list((0 for i in range(1, 9))), "cntDay": 0, "stayCntDay": 0}
        return initDataDict


if __name__ == "__main__":
    fileDb = FileDB(filePath=r"data\csv\fileDB.csv", minutes=0)
    fileDb.update(10, 5)
