import cv2
import numpy as np


from const.Specification import CAM_SPEC_DICT


class Mask:
    def __init__(self, camDict, imgSize, maskList, visualize=False):
        self.maskList = list()
        self.visualize = visualize
        self.mask_transfer(camDict, imgSize, maskList)

    def mask_transfer(self, camDict, imgSize, maskList):
        """將遮罩從魚眼尺寸轉換至四合一辨識圖

        Args:
            camDict (_type_): _description_
            imgSize (_type_): _description_
            maskList (_type_): _description_
        """

        ### 單攝影機
        if len(camDict.keys()) == 1:
            for mask in maskList:
                camId, dataList = mask["camId"], mask["data"]
                camSpec = camDict[str(camId)]["camSpec"]
                camSpec = CAM_SPEC_DICT[camSpec]

                if camSpec.preProc:
                    orgWidth, orgHeight = camSpec.radius * 2, camSpec.radius * 2
                else:
                    orgWidth, orgHeight = camSpec.orgSize
                ratioX, ratioY = imgSize / orgWidth, imgSize / orgHeight

                for data in dataList:
                    ### 將矩形轉為多邊形格式
                    if len(data) == 2:
                        leftTop, rightDown = data
                        rightTop, leftDown = (rightDown[0], leftTop[1]), (leftTop[0], rightDown[1])
                        data = [leftTop, rightTop, rightDown, leftDown]

                    ### 尺寸縮到四合一辨識圖
                    tempData = data
                    data = list()
                    for point in tempData:
                        x, y = point
                        x *= ratioX
                        y *= ratioY
                        data.append((x, y))

                    self.maskList.append(data)

        ### 四合一圖像
        else:
            for mask in maskList:
                camId, dataList = mask["camId"], mask["data"]

                camSpec = camDict[str(camId)]["camSpec"]
                camSpec = CAM_SPEC_DICT[camSpec]

                if camSpec.preProc:
                    orgWidth, orgHeight = camSpec.radius * 2, camSpec.radius * 2
                else:
                    orgWidth, orgHeight = camSpec.orgSize
                ratioX, ratioY = imgSize / orgWidth, imgSize / orgHeight

                loc = camDict[str(camId)]["loc"]

                for data in dataList:
                    ### 將矩形轉為多邊形格式
                    if len(data) == 2:
                        leftTop, rightDown = data
                        rightTop, leftDown = (rightDown[0], leftTop[1]), (leftTop[0], rightDown[1])
                        data = [leftTop, rightTop, rightDown, leftDown]

                    ### 尺寸縮到四合一辨識圖
                    tempData = data
                    data = list()
                    for point in tempData:
                        x, y = point
                        x = (x * ratioX) + (imgSize * (loc[1] - 1))
                        y = (y * ratioY) + (imgSize * (loc[0] - 1))
                        data.append((x, y))

                    self.maskList.append(data)

    def noise_filter(self, img, pointList):
        ### 濾除遮罩內目標
        resPointList = list()
        for point in pointList:
            ok = True
            for mask in self.maskList:
                if is_point_inside_Polygon(point, mask):
                    ok = False
                    break
            if ok:
                resPointList.append(point)

        ### 遮罩可視化
        resImg = img.copy()
        if self.visualize:
            for mask in self.maskList:
                ### 繪製實心多邊形
                resImg = cv2.fillConvexPoly(resImg, np.array(mask, dtype=np.int32), 0)

        return resImg, resPointList


def is_point_inside_Polygon(point, maskPoints):
    polygon = np.array(maskPoints, dtype=np.int32).reshape((-1, 1, 2))
    res = cv2.pointPolygonTest(polygon, point, measureDist=False)
    if res >= 0:
        return True
    else:
        return False
