import sys
import os
import cv2
import numpy as np
import datetime

currentPath = os.path.abspath(__file__)
modulePath = os.path.dirname(currentPath)
sys.path.append(os.path.dirname(modulePath))

from packages.Calibration import PerspectiveTransform, AffineTransform
from packages.ImageProcess import Plot


class Fence:
    def __init__(self, fenceDict, bridViewDict, layoutDict, visualize=False):
        self.fenceDict = fenceDict
        self.bridViewDict = bridViewDict
        self.layoutDict = layoutDict
        self.visualize = visualize

        ### 載入變換矩陣
        self.get_mtx()

        ### 將 user 在畸變校正圖上設定的站點投影到平面圖
        self.layoutFenceDict = self.__fence_to_layout(fenceDict)

        ### 載入平面圖
        self.layoutImg = cv2.imread(self.layoutDict["imgPath"])

        self.setup()

    def setup(self):
        ### 初始化停留時間追蹤
        fenceIdList = list(self.layoutFenceDict.keys())
        self.stayTimeCal = StayTimeCal(fenceIdList, stayTimeThres=10, maxLen=99)

    def get_mtx(self):
        self.camPerspectiveMtxDict = dict()
        self.birdViewAffineMtxDict, self.bridViewCamIdListDict = dict(), dict()

        ### 讀取各攝影機的透視變換矩陣
        for bridViewId, bridView in self.bridViewDict.items():
            camIdSet = set()
            dataDict = bridView["dataDict"]
            mainCamId, mainCamMtx = dataDict["mainCamId"], dataDict["mainCamMtx"]
            camIdSet.add(mainCamId)
            self.camPerspectiveMtxDict[mainCamId] = mainCamMtx

            overlapDictList = dataDict["overlapDictList"]
            for i, overlap in enumerate(overlapDictList):
                srcCamId, srcCamMtx = overlap["srcCamId"], overlap["srcCamMtx"]
                camIdSet.add(srcCamId)
                self.camPerspectiveMtxDict[srcCamId] = srcCamMtx

            self.bridViewCamIdListDict[bridViewId] = camIdSet

        ### 讀取各全景圖的仿射變換矩陣
        layoutBlockDict = self.layoutDict["blockDict"]
        for blockId, block in layoutBlockDict.items():
            bridViewId = block["bridViewId"]
            mtx = block["mtx"]
            self.birdViewAffineMtxDict[bridViewId] = mtx

    def __fence_to_layout(self, fenceDict):
        """將站點設定從畸變校正圖投影到平面圖

        Args:
            fenceDict (_type_): _description_

        Returns:
            _type_: _description_
        """
        newFenceDict = dict()
        for fenceId in fenceDict.keys():
            fence = fenceDict[fenceId]
            newFenceDict[fenceId] = {
                "fenceId": fence["fenceId"],
                "fenceName": fence["fenceName"],
                "dataList": list(),
            }
            for i, fenceData in enumerate(fence["dataList"]):
                camId, fenceRegion = str(fenceData["camId"]), fenceData["data"]

                ### 將矩形轉為多邊形格式
                if len(fenceRegion) == 2:
                    leftTop, rightDown = fenceRegion
                    rightTop, leftDown = (rightDown[0], leftTop[1]), (leftTop[0], rightDown[1])
                    fenceRegion = [leftTop, rightTop, rightDown, leftDown]

                ### 平視校正 & 投影到世界座標
                perspectiveMtx = self.camPerspectiveMtxDict[camId]
                perspertivePts = PerspectiveTransform.point_transfer(fenceRegion, perspectiveMtx)

                ### 投影到平面圖
                for bridViewId, CamIdList in self.bridViewCamIdListDict.items():
                    if camId in CamIdList:
                        affineMtx = self.birdViewAffineMtxDict[bridViewId]
                        layoutpts = AffineTransform.point_transfer(perspertivePts, affineMtx)

                        ### 將邊界限制在平面圖邊界
                        layoutRegion = self.layoutDict["blockDict"][bridViewId]["layoutRegion"]
                        minX, minY, maxX, maxY = (
                            layoutRegion[0][0],
                            layoutRegion[0][1],
                            layoutRegion[1][0],
                            layoutRegion[1][1],
                        )
                        tmpLayoutpts = layoutpts
                        layoutpts = list()
                        for pt in tmpLayoutpts:
                            x, y = int(pt[0]), int(pt[1])
                            x = minX if x < minX else x
                            x = maxX if x > maxX else x
                            y = minY if y < minY else y
                            y = maxY if y > maxY else y
                            layoutpts.append((x, y))

                        newFenceDict[fenceId]["dataList"].append(layoutpts)
        return newFenceDict

    def cnt(self, camDataDict, globalObj):
        idDict = dict()
        for fenceId, fence in self.layoutFenceDict.items():
            idDict[fenceId] = set()
            for fenceRegion in fence["dataList"]:
                for globalId, pt in globalObj.items():
                    if is_point_inside_Polygon((int(pt[0]), int(pt[1])), fenceRegion):
                        idDict[fenceId].add(globalId)

        ### 計算各 ID 停留時間
        entryIdDict, exitIdDict, avgStayTimeDict = self.stayTimeCal.update(idDict)

        fencePeopleDict = dict()
        for fenceId, fence in self.layoutFenceDict.items():
            fencePeopleDict[fenceId] = len(idDict[fenceId])

        resDict = {"people": fencePeopleDict, "stayTime": exitIdDict}

        if self.visualize:
            ### 畸變校正圖上顯示站點
            for fenceId, fence in self.fenceDict.items():
                for fenceData in fence["dataList"]:
                    camId, fenceRegion = str(fenceData["camId"]), fenceData["data"]
                    camCorrImg = camDataDict[str(camId)].corrImg

                    ### 將矩形轉為多邊形格式
                    if len(fenceRegion) == 2:
                        leftTop, rightDown = fenceRegion
                        rightTop, leftDown = (rightDown[0], leftTop[1]), (leftTop[0], rightDown[1])
                        fenceRegion = [leftTop, rightTop, rightDown, leftDown]

                    polygon = np.array(fenceRegion)
                    cv2.polylines(
                        camCorrImg,
                        [polygon.reshape((-1, 1, 2))],
                        isClosed=True,
                        color=(255, 0, 0),
                        thickness=2,
                        lineType=cv2.LINE_4,
                    )

                    leftTop = (np.min(polygon[:, 0]), np.min(polygon[:, 1]))
                    cv2.putText(camCorrImg, f"fence_{fenceId}", leftTop, cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)
                    cv2.imshow(f"cam_{camId}", cv2.resize(camCorrImg, (1000, 1000)))

            ### 平面圖上顯示站點
            resImg = self.layoutImg.copy()
            for fenceId, fence in self.layoutFenceDict.items():
                for fenceRegion in fence["dataList"]:
                    polygon = np.array(fenceRegion)
                    cv2.polylines(
                        resImg,
                        [polygon.reshape((-1, 1, 2))],
                        isClosed=True,
                        color=(255, 0, 0),
                        thickness=2,
                        lineType=cv2.LINE_4,
                    )

                    leftTop = (np.min(polygon[:, 0]), np.min(polygon[:, 1]))
                    cv2.putText(resImg, f"fence_{fenceId}", leftTop, cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)

            ### 畫點
            for pt in globalObj.values():
                cv2.circle(resImg, pt, 5, (0, 255, 0), thickness=-1)

            cv2.imshow("fence", resImg)

        return resDict


class StayTimeCal:
    def __init__(self, fenceIdList, stayTimeThres=30, maxLen=99, outputFolder=r"data\txt\id_track") -> None:
        """計算各 ID 進出時間與各展區平均停留時間

        Args:
            stayTimeThres (int, optional): 停留時間秒數閾值, 低於閾值則不發送到前端. Defaults to 30.
            maxLen (int, optional): 各圍籬記錄ID的最大長度. Defaults to 99.
            outputFolder (str, optional): 輸出資料夾. Defaults to "data\txt".
        """
        self.fenceIdList = fenceIdList
        self.maxLen = maxLen
        self.outputFolder = outputFolder
        self.stayTimeThres = stayTimeThres

        os.makedirs(self.outputFolder, exist_ok=True)
        ### 初始化8個展區
        self.existIdDict, self.resultDict = dict(), dict()
        for fenceId in self.fenceIdList:
            self.existIdDict[fenceId] = dict()  # 紀錄各展區當前存在ID進入時間
            self.resultDict[fenceId] = dict()  # 紀錄各展區所有ID進出時間

    def update(self, idDict):
        ### 初始化8個展區
        entryIdDict, exitIdDict, avgStayTimeDict = dict(), dict(), dict()
        for fenceId in self.fenceIdList:
            entryIdDict[fenceId] = dict()  # 紀錄各展區進入的ID
            exitIdDict[fenceId] = dict()  # 紀錄各展區離開的ID
            avgStayTimeDict[fenceId] = 0  # maxLen時間區間內的平均停留時間

        for fenceId, idList in idDict.items():
            ### 沒有記錄過的ID, 記錄進入時間
            for id in idList:
                if id not in self.resultDict[fenceId].keys():
                    # startTime = time.time()
                    startTime = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    self.existIdDict[fenceId][id] = dict({"startTime": startTime})
                    entryIdDict[fenceId][id] = dict({"startTime": startTime, "endTime": None, "stayTime": None})
                    self.resultDict[fenceId][id] = dict({"startTime": startTime, "endTime": None, "stayTime": None})

            ### 消失的ID, 記錄離開時間
            leftIdList = list()
            for id in self.existIdDict[fenceId].keys():
                if id not in idList:
                    startTime = self.resultDict[fenceId][id]["startTime"]
                    # endTime = time.time()
                    endTime = datetime.datetime.now()
                    stayTime = (
                        endTime - datetime.datetime.strptime(startTime, "%Y-%m-%d %H:%M:%S")
                    ).total_seconds()  # 轉換成秒數
                    endTime = endTime.strftime("%Y-%m-%d %H:%M:%S")
                    leftIdList.append(id)
                    self.resultDict[fenceId][id] = dict(
                        {"startTime": startTime, "endTime": endTime, "stayTime": stayTime}
                    )

                    ### 高於閾值的才列入
                    if stayTime >= self.stayTimeThres:
                        exitIdDict[fenceId][id] = dict(
                            {"startTime": startTime, "endTime": endTime, "stayTime": stayTime}
                        )

            # 從當前ID列表中移除消失的ID
            for id in leftIdList:
                self.existIdDict[fenceId].pop(id)

            ### 刪除超過最大長度的舊資料
            if len(self.resultDict[fenceId]) > self.maxLen:
                delNum = len(self.resultDict[fenceId]) - self.maxLen
                while delNum != 0:
                    resultIdDict = list(self.resultDict[fenceId].keys())
                    for delId in resultIdDict:
                        ### 避免刪到目前存在的ID
                        if delId not in self.existIdDict[fenceId].keys():
                            self.resultDict[fenceId].pop(delId)
                            delNum -= 1
                            break
                        ### 所有ID都還存在則不刪除任何資料
                        elif delId == resultIdDict[-1]:
                            delNum = 0

            ### XXX: 輸出txt & 計算平均停留時間, 非必要開啟
            if False:
                stayTimeSum = 0
                file = open(os.path.join(self.outputFolder, "fence_" + fenceId + ".txt"), "wt")
                for id, idInfo in self.resultDict[fenceId].items():
                    startTime, endTime, stayTime = idInfo["startTime"], idInfo["endTime"], idInfo["stayTime"]

                    ### ID 尚未離開, 以目前時間計算
                    if stayTime is None:
                        stayTime = (
                            datetime.datetime.now() - datetime.datetime.strptime(startTime, "%Y-%m-%d %H:%M:%S")
                        ).total_seconds()

                        endTime = "None"

                    stayTimeSum += stayTime
                    file.write(
                        "{} startTime: {}, endTime:{}, stayTime: {:.2f}s\n".format(id, startTime, endTime, stayTime)
                    )
                if len(self.resultDict[fenceId].keys()) != 0:
                    avgStayTimeDict[fenceId] = stayTimeSum / len(self.resultDict[fenceId].keys())
                else:
                    avgStayTimeDict[fenceId] = 0
                file.write("Average Stay {:.2f}s".format(avgStayTimeDict[fenceId]))
                file.close()

            else:
                stayTimeSum = 0
                for id, idInfo in self.resultDict[fenceId].items():
                    startTime, endTime, stayTime = idInfo["startTime"], idInfo["endTime"], idInfo["stayTime"]

                    ### ID 尚未離開, 以目前時間計算
                    if stayTime is None:
                        stayTime = (
                            datetime.datetime.now() - datetime.datetime.strptime(startTime, "%Y-%m-%d %H:%M:%S")
                        ).total_seconds()

                        endTime = "None"

                    stayTimeSum += stayTime
                if len(self.resultDict[fenceId].keys()) != 0:
                    avgStayTimeDict[fenceId] = stayTimeSum / len(self.resultDict[fenceId].keys())
                else:
                    avgStayTimeDict[fenceId] = 0

        return entryIdDict, exitIdDict, avgStayTimeDict


def is_point_in_area(point, area):
    """判斷點座標是否位在矩形區域內

    Args:
        point (_type_): _description_
        area (_type_): _description_

    Returns:
        _type_: _description_
    """
    x, y = point[0], point[1]
    if x < area[0][0] or x > area[1][0] or y < area[0][1] or y > area[1][1]:
        return False
    else:
        return True


def is_point_inside_Polygon(point, maskPoints):
    polygon = np.array(maskPoints, dtype=np.int32).reshape((-1, 1, 2))
    res = cv2.pointPolygonTest(polygon, point, measureDist=False)
    if res >= 0:
        return True
    else:
        return False
