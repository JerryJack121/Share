import numpy as np
import cv2
from packages.Capture import IpCam, VideoLoader
from packages.ImageProcess import ImageProcess, Plot
from const.Object import CamData
from const.Global import GLOBAL_OBJECT
from const.Specification import CAM_SPEC_DICT


class CamCapture:
    def __init__(self, camDict, imgSize, videoMode=False):
        self.imgSize = imgSize
        self.camDict = camDict
        self.videoMode = videoMode

        camNum = len(self.camDict.keys())

        ### 建立畫布
        ### 單圖像
        if camNum == 1:
            self.canvas = np.zeros((self.imgSize, self.imgSize, 3), np.uint8)
        ### 四合一圖像
        elif 1 < camNum <= 4:
            self.canvas = np.zeros((self.imgSize * 2, self.imgSize * 2, 3), np.uint8)
        else:
            raise RuntimeError("僅支援 1~4 台攝影機")

        ### 建立 capture
        for camId in self.camDict.keys():
            ### 啟動攝影機
            if not self.videoMode:
                self.camDict[camId]["capture"] = IpCam(self.camDict[camId]["url"])
            ### for 影片測試
            else:
                self.camDict[camId]["noFrame"] = 0
                self.camDict[camId]["capture"] = VideoLoader(self.camDict[camId]["url"], waitTrigger=True)
                self.camDict[camId]["capture"].start()

    def get_combine_frame(self):
        """讀取畫面並回傳合併圖像"""
        combineImg = self.canvas.copy()
        camDataDict = dict()

        for camId in self.camDict.keys():
            camSpec = self.camDict[camId]["camSpec"]
            camSpec = CAM_SPEC_DICT[camSpec]
            capture = self.camDict[camId]["capture"]
            loc = self.camDict[camId]["loc"]
            frame = capture.get_frame()

            if frame is not None:
                status = True
                ### 前處理
                if camSpec.preProc:
                    centerX = camSpec.centerX
                    centerY = camSpec.centerY
                    radius = camSpec.radius
                    frame = ImageProcess.get_fisheye(
                        frame,
                        center=(centerX, centerY),
                        radius=radius,
                    )

            ### 產生無訊號圖像
            else:
                status = False
                ### XXX: yjchou 2023/12/08 hard code 取完短邊後的影像大小
                disconnectedImg = Plot.plot_disconnected_img((1536, 1536), fontSize=100)
                frame = disconnectedImg

            ### 重複播放影片 for 影片測試
            if self.videoMode:
                if not status:
                    self.camDict[camId]["noFrame"] += 1
                if self.camDict[camId]["noFrame"] > 10:
                    self.camDict[camId]["noFrame"] = 0
                    self.camDict[camId]["capture"] = VideoLoader(self.camDict[camId]["url"], waitTrigger=True)
                    self.camDict[camId]["capture"].start()
                    ### XXX: For demo 影片重播後重置人數
                    GLOBAL_OBJECT.resetTrigger = True

            camData = CamData()
            camData.camId, camData.loc, camData.frame, camData.status = int(camId), loc, frame, status
            camDataDict[camId] = camData

            ### 合併圖像
            img = cv2.resize(frame, (self.imgSize, self.imgSize))
            combineImg[
                self.imgSize * (loc[0] - 1) : self.imgSize * (loc[0]),
                self.imgSize * (loc[1] - 1) : self.imgSize * (loc[1]),
            ] = img

        return combineImg, camDataDict

    def get_org_frame(self):
        camDataDict = dict()
        for camId in self.camDict.keys():
            capture = self.camDict[camId]["capture"]
            frame = capture.get_frame()
            if frame is not None:
                camDataDict[camId] = frame
        return camDataDict
