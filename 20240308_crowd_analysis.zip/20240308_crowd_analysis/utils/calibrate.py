import numpy as np
import sys
import os

currentPath = os.path.abspath(__file__)
modulePath = os.path.dirname(currentPath)
sys.path.append(os.path.dirname(modulePath))

from const.Specification import DistortMethod
from packages.Calibration import LongitudeLatitudeCalibration, AffineTransform, Distortion, CamType


def get_layout_region(layoutRegionList, camId):
    for cam in layoutRegionList:
        if cam["camId"] == camId:
            region = cam["data"]
            return region
    return None


def img_distortion_corr(img, camDistortParmDict):
    """單張圖片畸變轉換

    Args:
        img (_type_): _description_
        camDistortParmDict (_type_): _description_

    Returns:
        _type_: _description_
    """

    if camDistortParmDict["method"] == DistortMethod.LATITUDE_LONGITUDE:
        resImg = LongitudeLatitudeCalibration.img_transfer(img, camDistortParmDict["mapX"], camDistortParmDict["mapY"])
    elif camDistortParmDict["method"] == DistortMethod.CHESSBOARD:
        resImg = Distortion.img_undistort(
            img,
            camDistortParmDict["mtx"],
            camDistortParmDict["dist"],
            camType=CamType.FISHEYE,
            alpha=camDistortParmDict["alpha"],
        )

    return resImg


def point_distortion_corr(pointList, camDistortParmDict, radius=None):
    """點座標畸變轉換

    Args:
        pointList (_type_): _description_
        imgSize (_type_): _description_

    Returns:
        _type_: _description_
    """
    if camDistortParmDict["method"] == DistortMethod.LATITUDE_LONGITUDE:
        resPointList = LongitudeLatitudeCalibration.point_transfer(pointList, radius, mode=1)
    elif camDistortParmDict["method"] == DistortMethod.CHESSBOARD:
        resPointList = Distortion.point_transfer(
            pointList,
            camDistortParmDict["mtx"],
            camDistortParmDict["dist"],
            camType=CamType.FISHEYE,
            alpha=camDistortParmDict["alpha"],
        )
    return resPointList


def img_affin_trans(img, region, affinMatrix):
    """單張圖片畸變轉換

    Args:
        img (_type_): _description_
        camId (_type_): _description_

    Returns:
        _type_: _description_
    """
    dSize = (int(region[1][0]) - int(region[0][0]), int(region[1][1]) - int(region[0][1]))
    resImg = AffineTransform.img_transfer(img, affinMatrix, dSize)
    return resImg


def point_affin_trans(pointList, region, affinMatrix):
    """點座標仿射轉換

    Args:
        pointList (_type_): _description_
        camId (_type_): _description_
        imgSize (_type_): _description_

    Returns:
        _type_: _description_
    """
    ### 座標轉換方法
    afinePointList = AffineTransform.point_transfer(pointList, affinMatrix)
    ### 拼入 Layout
    resPointList = list()
    for point in afinePointList:
        x, y = point
        dSize = (int(region[1][0]) - int(region[0][0]), int(region[1][1]) - int(region[0][1]))
        ### 濾除超出邊界的點
        if x < 0 or y < 0 or x > dSize[0] or y > dSize[1]:
            continue
        x += region[0][0]
        y += region[0][1]
        resPointList.append((int(x), int(y)))
    # print(f"{len(pointList)}->{len(resPointList)}")
    return resPointList
