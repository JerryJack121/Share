### 過線計數 (客流量)
import cv2
import sys
import time

sys.path.append("./")
from packages.CentroidTracker import CentroidTracker


def is_point_in_area(point, area):
    """判斷點座標是否位在矩形區域內

    Args:
        point (_type_): _description_
        area (_type_): _description_

    Returns:
        _type_: _description_
    """
    x, y = point[0], point[1]
    if x < area[0][0] or x > area[1][0] or y < area[0][1] or y > area[1][1]:
        return False
    else:
        return True


def draw_area(img, bbox):
    resImg = img.copy()
    x1, y1, x2, y2 = int(bbox[0][0]), int(bbox[0][1]), int(bbox[1][0]), int(bbox[1][1])
    cv2.rectangle(resImg, (x1, y1), (x2, y2), color=(0, 0, 255), thickness=2)
    return resImg


def draw_id(img, idDict):
    resImg = img.copy()
    for id in idDict.keys():
        pt = idDict[id].point
        cv2.circle(resImg, pt, 5, (0, 0, 255), -1)
        cv2.putText(
            resImg,
            str(id),
            tuple(pt),
            cv2.FONT_HERSHEY_SIMPLEX,
            1,
            (0, 0, 255),
            1,
            cv2.LINE_AA,
        )

    return resImg


def draw_line(img, lines):
    resImg = img.copy()
    for line in lines:
        linePoint1, linePoint2, rule = line
        cv2.line(
            resImg,
            (int(linePoint1[0]), int(linePoint1[1])),
            (int(linePoint2[0]), int(linePoint2[1])),
            (255, 0, 0),
            2,
        )
    return resImg


class ObjectInfo:
    def __init__(self, objectID, centroid):
        self.objectID = objectID
        self.point = tuple((centroid[0], centroid[1]))
        self.timeIn = None
        self.disappearFrame = 0


class Counter:
    def __init__(self, cntLineId, camId, area, lines, stayTime):
        self.listMaxSize = 9999  # 記憶體不爆炸即可
        self.maxDisappeared = 2  # 須測試
        self.cntLineId = cntLineId
        self.camId = camId
        self.area = area
        self.lines = lines
        self.stayTime = stayTime

        self.frameIdDict = dict()
        self.lastIdDict = dict()
        self.trackIdDict = dict()
        self.inIdList = list()
        self.dayInIdList = list()
        self.tracker = CentroidTracker(maxDisappeared=self.maxDisappeared)

    def count(self, camDataDict):
        inNum, outNum, dayInNum = 0, 0, 0
        pointList = camDataDict[str(self.camId)].corrPoint
        delIdList = list()

        ### 篩選在追蹤區域內的目標
        self.pointInArea = list()
        for point in pointList:
            if is_point_in_area(point, self.area):
                self.pointInArea.append(point)

        ### 追蹤 ID
        self.lastIdDict = self.frameIdDict
        self.frameIdDict = dict()
        objects = self.tracker.update(self.pointInArea)
        for objectID, centroid in objects.items():
            objCls = ObjectInfo(objectID, centroid)
            self.frameIdDict[str(objectID)] = objCls

        ### 在計數線內停留一段時間才計數 (stayTime=0 代表 通過計數線就計數)
        for person in self.frameIdDict.values():
            personId, point = person.objectID, person.point

            ### 上一幀ID存在
            if str(personId) in self.lastIdDict.keys():
                lastPoint = self.lastIdDict[str(personId)].point
                howCrossLine = self.__cross_line(self.lines, point, lastPoint)
                if howCrossLine != None:
                    # print(f"Line: {self.cntLineId}, iD: {personId}, {howCrossLine}")

                    if howCrossLine == "Unknow":
                        ### 忽略剛好在計數線上的那一幀
                        self.frameIdDict[str(personId)].point = self.lastIdDict[str(personId)].point

                    ### 進入計數線, 紀錄時間
                    elif howCrossLine:
                        self.trackIdDict[str(personId)] = self.frameIdDict[str(personId)]
                        self.trackIdDict[str(personId)].timeIn = time.time()

                    ### 離開計數線
                    else:
                        if self.stayTime == 0:
                            outNum += 1
                        else:
                            ### XXX: 判斷是否有被計算過進入人數 (暫時解, 必免多扣)
                            if personId in self.inIdList:
                                # print(f"ID {personId} OUT")
                                outNum += 1
                        delIdList.append(str(personId))

        for id, info in self.trackIdDict.items():
            ### 判斷紀錄中的 ID 是否還存在
            if not is_point_in_area(info.point, self.area):
                self.trackIdDict[id].disappearFrame += 1

            ### 處理停留一段時間或消失一段時間的 ID
            now = time.time()
            ### 停留一段時間
            timeIn = info.timeIn
            if now - timeIn >= self.stayTime:
                inNum += 1
                # print(f"ID {id} IN")
                self.inIdList.append(info.objectID)
                delIdList.append(id)

            ### 消失一段時間
            if self.trackIdDict[id].disappearFrame > self.maxDisappeared:
                delIdList.append(id)

        ### 刪除停留夠久, 離開, 消失的 ID
        for delId in set(delIdList):
            if delId in self.trackIdDict.keys():
                del self.trackIdDict[delId]

        ### 避免 list 無限增加
        if len(self.dayInIdList) > self.listMaxSize:
            self.dayInIdList.pop(0)

        dayInNum = inNum
        return inNum, outNum, dayInNum

    def __cross_line(self, lines, point, lastPoint):
        """判斷是否滿足計數線規則

        Args:
            lines (_type_): _description_
        """
        ### ID 沒有移動
        if point[0] == lastPoint[0] and point[1] == lastPoint[1]:
            return None

        ### 判斷路徑是否跨越計數線
        result = None
        for line in lines:
            linePoint1, linePoint2, rule = line

            # 兩線段沒有交點
            if (
                min(point[0], lastPoint[0]) > max(linePoint1[0], linePoint2[0])
                or max(point[0], lastPoint[0]) < min(linePoint1[0], linePoint2[0])
                or min(point[1], lastPoint[1]) > max(linePoint1[1], linePoint2[1])
                or max(point[1], lastPoint[1]) < min(linePoint1[1], linePoint2[1])
            ):
                tmpResult = None
                continue

            ### 計數線為水平線
            if linePoint1[1] == linePoint2[1]:
                # print(f"{lastPoint}->{point}")
                if point[1] == linePoint1[1]:
                    ### 剛好停在線上
                    return "Unknow"
                elif (point[1] - lastPoint[1]) * rule * -1 > 0:
                    tmpResult = True
                else:
                    tmpResult = False

            ### 計數線為垂直線
            elif linePoint1[0] == linePoint2[0]:
                # print(f"{lastPoint}->{point}")
                if point[0] == linePoint1[0]:
                    ### 剛好停在線上
                    return "Unknow"
                elif (point[0] - lastPoint[0]) * rule > 0:
                    tmpResult = True
                else:
                    tmpResult = False

            else:
                errorMsg = "計數線設定錯誤: 只支援水平線和垂直線的組合"
                self.logger.error(errorMsg)
                raise (errorMsg)

            if result is None:
                result = tmpResult
            elif result != tmpResult:
                ### 同時跨越兩條計數線且結果有加有減
                return None

        return result

    def visualize(self, camDataDict):
        img = camDataDict[str(self.camId)].corrImg
        resImg = img.copy()
        ### 畫追蹤範圍
        resImg = draw_area(img, self.area)
        ### 畫 ID
        resImg = draw_id(resImg, self.frameIdDict)
        ### 畫計數線
        resImg = draw_line(resImg, self.lines)
        ### Show
        resImg = cv2.resize(resImg, (resImg.shape[1] // 2, resImg.shape[0] // 2))
        cv2.imshow(f"line_{self.cntLineId}", resImg)
        cv2.waitKey(1)


class VenueCounter:
    def __init__(self, stayTime) -> None:
        self.counterDict = dict()
        self.stayTime = stayTime

    def add_count_line(self, cntLine):
        """初始化追蹤器對應案廠內的每個出入口

        Args:
            cntLine (_type_): _description_
        """
        cntLineId = cntLine["cntLineId"]
        self.counterDict[str(cntLineId)] = Counter(
            cntLineId,
            cntLine["camId"],
            cntLine["area"],
            cntLine["lines"],
            self.stayTime,
        )

    def count_one_venue(self, camDataDict):
        """計算單一案場的所有計數線加總

        Args:
            camDataDict (_type_): _description_
        """
        venueInNum, venueOutNum, venueDayInNum = 0, 0, 0
        for counter in self.counterDict.values():
            inNum, outNum, dayInNum = counter.count(camDataDict)
            venueInNum += inNum
            venueOutNum += outNum
            venueDayInNum += dayInNum
        return venueInNum, venueOutNum, venueDayInNum

    def visualize(self, camDataDict):
        for counter in self.counterDict.values():
            counter.visualize(camDataDict)


class PeopleCount:
    def __init__(self, config, logger, visualize=False):
        self.visualize = visualize
        self.logger = logger
        venueDict = config.venueDict
        cntLintDict = config.cntLintDict

        ### 初始化人數計數器對應每一個案場
        self.counterDict, self.resultDict = dict(), dict()
        for cntLine in cntLintDict.values():
            venueId = cntLine["venueId"]
            if str(venueId) not in self.counterDict.keys():
                venueName, stayTime = venueDict[str(venueId)]["venueName"], venueDict[str(venueId)]["stayTime"]
                self.counterDict[str(venueId)] = VenueCounter(stayTime)
                self.resultDict[str(venueId)] = {"cntNow": 0, "cntDay": 0, "inNum": 0, "outNum": 0, "dayInNum": 0}
            self.counterDict[str(venueId)].add_count_line(cntLine)

    def count_all_venue(self, camDataDict):
        for venueId, counter in self.counterDict.items():
            venueInNum, venueOutNum, venueDayInNum = counter.count_one_venue(camDataDict)
            venuecntNow = self.resultDict[venueId]["cntNow"]
            venuecntDay = self.resultDict[venueId]["cntDay"]
            self.resultDict[venueId]["cntNow"] = venuecntNow + venueInNum - venueOutNum
            self.resultDict[venueId]["cntDay"] = venuecntDay + venueDayInNum
            self.resultDict[venueId]["inNum"] = venueInNum
            self.resultDict[venueId]["outNum"] = venueOutNum
            self.resultDict[venueId]["dayInNum"] = venueDayInNum

            if self.visualize:
                counter.visualize(camDataDict)

        return self.resultDict

    def reset(self):
        """重置場館人數 (僅內部顯示)"""
        for venueId, counter in self.counterDict.items():
            self.resultDict[venueId]["cntNow"] = 0
            self.resultDict[venueId]["cntDay"] = 0
