import numpy as np
import cv2
import os


class Layout:
    def __init__(self, imgPath, blockDict, visualize=False):

        if visualize:
            if os.path.isfile(imgPath):
                self.layoutImg = cv2.imread(imgPath)
            else:
                exception = f"找不到 Layout 圖片: {imgPath}"
                raise RuntimeError(exception)
        self.blockDict = blockDict

    def img_to_layout(self, layoutdataDict):
        """魚眼畫面投射至 Layout

        Args:
            camDataDict (_type_): _description_
        """
        resLayoutImg = self.layoutImg.copy()
        for layoutdata in layoutdataDict.values():
            region =layoutdata.region
            affineImg = layoutdata.affineImg
            resLayoutImg[int(region[0][1]) : int(region[1][1]), int(region[0][0]) : int(region[1][0])] = affineImg
        return resLayoutImg


    def point_to_layout(self, layoutdataDict):
        """魚眼座標投射至 Layout

        Args:
            camDataDict (_type_): _description_
        """
        layoutPointList = list()
        for layoutdata in layoutdataDict.values():
            affinePoint = layoutdata.affinePoint
            for point in affinePoint:
                layoutPointList.append(point)
        return layoutPointList
