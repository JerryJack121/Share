from configparser import ConfigParser
import json
import os
import yaml


class Config:
    def __init__(self, cfgFolder):
        self.aiId, self.host, self.port, self.restartTime = None, None, None, None
        self.camDict = dict()
        self.mode = Mode()
        self.model = Model()
        self.visualize = Visualize()
        self.webServer = Server()
        self.aiServer = Server()
        self.customerFlow = CustomerFlow()
        self.storeVisitor = StoreVisitor()
        self.fence = Fence()
        # self.layout = Layout()
        self.newLayout = NewLayout()
        self.schedule = Schedule()
        self.mask = Mask()

        cfgFilePath = os.path.join(cfgFolder, "initial/setup.cfg")
        if os.path.isfile(cfgFilePath):
            self.load_setup(cfgFilePath)
        else:
            raise RuntimeError(f"{cfgFilePath} is not exist!")

        cfgFilePath = os.path.join(cfgFolder, "initial/equip.json")
        if os.path.isfile(cfgFilePath):
            self.load_equip(cfgFilePath)
        else:
            raise RuntimeError(f"{cfgFilePath} is not exist!")

        cfgFilePath = os.path.join(cfgFolder, "config/setting.cfg")
        if os.path.isfile(cfgFilePath):
            self.load_setting(cfgFilePath)
        else:
            raise RuntimeError(f"{cfgFilePath} is not exist!")

        cfgFilePath = os.path.join(cfgFolder, "config/customerFlow.json")
        if os.path.isfile(cfgFilePath):
            self.load_customerFlow(cfgFilePath)
        else:
            raise RuntimeError(f"{cfgFilePath} is not exist!")

        cfgFilePath = os.path.join(cfgFolder, "config/StoreVisitor.json")
        if os.path.isfile(cfgFilePath):
            self.load_StoreVisitor(cfgFilePath)
        else:
            raise RuntimeError(f"{cfgFilePath} is not exist!")

        # cfgFilePath = os.path.join(cfgFolder, "config/layout.json")
        # if os.path.isfile(cfgFilePath):
        #     self.load_layout(cfgFilePath)
        # else:
        #     raise RuntimeError(f"{cfgFilePath} is not exist!")

        cfgFilePath = os.path.join(cfgFolder, "config/new_layout.yml")
        if os.path.isfile(cfgFilePath):
            self.load_new_layout(cfgFilePath)
        else:
            raise RuntimeError(f"{cfgFilePath} is not exist!")

        cfgFilePath = os.path.join(cfgFolder, "config/fence.json")
        if os.path.isfile(cfgFilePath):
            self.load_fence(cfgFilePath)
        else:
            raise RuntimeError(f"{cfgFilePath} is not exist!")

        cfgFilePath = os.path.join(cfgFolder, "config/schedule.yml")
        if os.path.isfile(cfgFilePath):
            self.load_schedule(cfgFilePath)
        else:
            raise RuntimeError(f"{cfgFilePath} is not exist!")

        cfgFilePath = os.path.join(cfgFolder, "config/mask.json")
        if os.path.isfile(cfgFilePath):
            self.load_mask(cfgFilePath)
        else:
            raise RuntimeError(f"{cfgFilePath} is not exist!")

    def load_setup(self, filePath):
        config = ConfigParser()
        config.read(filePath, encoding="utf-8")
        self.aiId = config.get("setup", "aiId")
        self.host = config.get("setup", "host")
        self.port = config.get("setup", "port")
        self.webServer.serverIp = config.get("webServer", "serverIp")
        self.webServer.port = config.get("webServer", "port")
        self.aiServer.serverIp = config.get("aiServer", "serverIp")
        self.aiServer.port = config.get("aiServer", "port")
        config.clear()

    def load_equip(self, filePath):
        with open(filePath, encoding="utf-8") as f:
            data = json.load(f)
            aiComputerDict, allCamDict = data["aiComputer"], data["cam"]
            ### 只載入這台電腦會用到的攝影機資訊
            camIdList = aiComputerDict[self.aiId]["cam"]
            for camId in camIdList:
                self.camDict[str(camId)] = allCamDict[str(camId)]
        f.close()

    def load_setting(self, filePath):
        config = ConfigParser()
        config.read(filePath, encoding="utf-8")
        self.restartTime = config.get("common", "restartTime")
        self.mode.debugMode = config.getboolean("mode", "debugMode")
        self.mode.videoMode = config.getboolean("mode", "videoMode")
        self.model.device = config.get("model", "device")
        self.model.imgSize = config.getint("model", "imgSize")
        self.model.conf = config.getfloat("model", "conf")
        self.model.weightPath = config.get("model", "weightPath")
        self.visualize.mask = config.getboolean("visualize", "mask")
        self.visualize.fence = config.getboolean("visualize", "fence")
        self.visualize.storeVisitor = config.getboolean("visualize", "storeVisitor")
        self.visualize.peopleCnt = config.getboolean("visualize", "peopleCnt")
        self.visualize.mtmc = config.getboolean("visualize", "mtmc")
        config.clear()

    def load_customerFlow(self, filePath):
        with open(filePath, encoding="utf-8") as f:
            data = json.load(f)
            mainVenueId, venue, cntLine = data["mainVenue"], data["venue"], data["data"]
            self.customerFlow.mainVenueId = mainVenueId
            self.customerFlow.venueDict = venue
            ### 只載入這台電腦會用到的計數線
            for cntLineId in cntLine.keys():
                cntLineDataDict = cntLine[cntLineId]
                camId = cntLineDataDict["camId"]
                if str(camId) in self.camDict.keys():
                    self.customerFlow.cntLintDict[cntLineId] = cntLineDataDict
        f.close()

    def load_StoreVisitor(self, filePath):
        with open(filePath, encoding="utf-8") as f:
            data = json.load(f)
            mainVenueId, venue, cntLine = data["mainVenue"], data["venue"], data["data"]
            self.storeVisitor.mainVenueId = mainVenueId
            self.storeVisitor.venueDict = venue
            ### 只載入這台電腦會用到的計數線
            for cntLineId in cntLine.keys():
                cntLineDataDict = cntLine[cntLineId]
                camId = cntLineDataDict["camId"]
                if str(camId) in self.camDict.keys():
                    self.storeVisitor.cntLintDict[cntLineId] = cntLineDataDict
        f.close()

    def load_fence(self, filePath):
        with open(filePath, encoding="utf-8") as f:
            data = json.load(f)
            ### 只載入這台電腦會用到的圍籬
            fenceDict = data["fenceDict"]
            for fecceId, oneFence in fenceDict.items():
                oneFenceDataList = oneFence["dataList"]
                for oneFenceData in oneFenceDataList:
                    camId = oneFenceData["camId"]
                    if str(camId) in self.camDict.keys():
                        self.fence.fenceDict[fecceId] = oneFence
                        break
        f.close()

    # def load_layout(self, filePath):
    #     with open(filePath, encoding="utf-8") as f:
    #         data = json.load(f)
    #         data = data["layout"]
    #         self.layout.imgPath = data["imgPath"]
    #         self.layout.blockDict = data["blockDict"]
    #     f.close()

    def load_new_layout(self, filePath):
        with open(filePath, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
            self.newLayout.bridViewDict = data["bridViewDict"]
            self.newLayout.layoutDict = data["layoutDict"]
        f.close()

    def load_schedule(self, filePath):
        with open(filePath, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
            self.schedule.aiSwitch = data["aiSwitch"]
            self.schedule.weeks = data["weeks"]
            self.schedule.scheduleOnTime, self.schedule.scheduleOffTime = (
                data["scheduleOnTime"],
                data["scheduleOffTime"],
            )

    def load_mask(self, filePath):
        with open(filePath, encoding="utf-8") as f:
            data = json.load(f)
            self.mask.maskList = list()
            ### 只載入這台電腦會用到的遮罩
            maskList = data["maskList"]
            for mask in maskList:
                camId = mask["camId"]
                if str(camId) in self.camDict.keys():
                    self.mask.maskList.append(mask)
        f.close()


class GetMatrixConfig:
    def __init__(self, cfgFolder):
        self.layout = Layout()

        self.load_layout(os.path.join(cfgFolder, "config/layout.json"))

    def load_layout(self, filePath):
        with open(filePath, encoding="utf-8") as f:
            data = json.load(f)
            data = data["layout"]
            self.layout.imgPath = data["imgPath"]
            self.layout.blockDict = data["blockDict"]
        f.close()


class GetImgConfig:
    def __init__(self, cfgFolder):
        self.camDict = dict()
        ### FIXME: yjchou 2024/03/01 更改畸變方式
        # self.calibrate = Calibrate()

        self.load_equip(os.path.join(cfgFolder, "initial/equip.json"))
        self.load_calibrate(os.path.join(cfgFolder, "config/distortion.json"))

    def load_equip(self, filePath):
        with open(filePath, encoding="utf-8") as f:
            data = json.load(f)
            aiComputerDict, allCamDict = data["aiComputer"], data["cam"]
            ### 只載入這台電腦會用到的攝影機資訊
            for camId in allCamDict.keys():
                if camId.find("_") == -1:
                    self.camDict[str(camId)] = allCamDict[str(camId)]
        f.close()

    def load_calibrate(self, filePath):
        with open(filePath, encoding="utf-8") as f:
            data = json.load(f)
            self.calibrate.distortionCorrMapXPath = data["mapX"]
            self.calibrate.distortionCorrMapYPath = data["mapY"]
        f.close()


class Mode:
    debugMode = None
    videoMode = None


class Model:
    device = None
    imgSize = None
    conf = None
    weightPath = None


class Visualize:
    mask = None
    fence = None
    storeVisitor = None
    heatmap = None
    peopleCnt = None
    mtmc = None


class Server:
    serverIp = None
    port = None


class CustomerFlow:
    mainVenueId = None
    venueDict = dict()
    cntLintDict = dict()


class StoreVisitor:
    mainVenueId = None
    venueDict = dict()
    cntLintDict = dict()


class Fence:
    fenceDict = dict()


class Layout:
    imgPath = None
    blockDict = None


class NewLayout:
    bridViewDict = None
    layoutDict = None


class Schedule:
    aiSwitch = None
    weeks = None
    scheduleOnTime = None
    scheduleOffTime = None


class Mask:
    maskList = None
