### 鳥瞰全景圖片拼接, 生成透視變換矩陣
import cv2
import numpy as np
import math
import os
import sys

currentPath = os.path.abspath(__file__)
modulePath = os.path.dirname(currentPath)
sys.path.append(os.path.dirname(modulePath))

from packages.Calibration import PerspectiveTransform


def main(camDataDict, overlapNum, targetSize):
    """
    Args:
        camDataDict (Dict): 相機重疊視野標定
        overlapNum (int): 重疊視野數量
        targetSize (tuple): 目標畫布大小, 需足夠大以包含所有畫面
    """

    resImg = None
    wordCoordDict = dict()

    ### FIXME: yjchou 2023/02/26 自適應 overlap 的數量
    for overlapId in range(1, overlapNum + 1):
        wordCoordDict[str(overlapId)] = None

    for camId, dataDict in camDataDict.items():
        imgPath = dataDict["imgPath"]
        undistortedImg = cv2.imread(imgPath)
        imgFileName = os.path.basename(imgPath)
        imgName, _ = os.path.splitext(imgFileName)

        ##########################################
        ##              標定
        ##########################################
        overlapDict = dataDict["overlapDict"]
        for overlapId, srcPtsList in overlapDict.items():
            if srcPtsList is None:
                ### 這張圖片沒有當前拼接中的重疊範圍
                continue

            ### 對齊第一張圖片的標定點
            if wordCoordDict[overlapId] is None:
                ### 準備透視變換後的目標點
                boardWidth = int(
                    math.sqrt((srcPtsList[1][0] - srcPtsList[0][0]) ** 2 + (srcPtsList[1][1] - srcPtsList[0][1]) ** 2)
                )
                boardHeight = int(
                    math.sqrt((srcPtsList[2][0] - srcPtsList[1][0]) ** 2 + (srcPtsList[2][1] - srcPtsList[1][1]) ** 2)
                )

                ### 移動棋盤格左上角的座標, 避免校正後圖片被裁切
                width, height = undistortedImg.shape[:2][::-1]
                size = max(width, height)
                origin = tuple((srcPtsList[0][0] + size // 2, srcPtsList[0][1] + size // 2))

                ### 維持棋盤格在原畫面中的大小
                targetPtsList = [
                    [origin[0], origin[1]],
                    [origin[0] + boardWidth, origin[1]],
                    [origin[0] + boardWidth, origin[1] + boardHeight],
                    [origin[0], origin[1] + boardHeight],
                ]
                wordCoordDict[overlapId] = targetPtsList
            else:
                targetPtsList = wordCoordDict[overlapId]

            ##########################################
            ##         平視校正 & 投影到世界座標
            ##########################################
            ### 透視變換
            matrix = PerspectiveTransform.solve_matrix(srcPtsList, targetPtsList)
            perspectiveImg = PerspectiveTransform.img_transfer(undistortedImg, matrix, targetSize)
            cv2.imshow(
                f"perspectiveImg_{imgFileName}",
                cv2.resize(
                    perspectiveImg,
                    (targetSize[0] // 2, targetSize[1] // 2),
                ),
            )

            if resImg is None:
                resImg = perspectiveImg
            ### 圖像合併
            else:
                resImg = cv2.addWeighted(src1=resImg, alpha=0.5, src2=perspectiveImg, beta=0.5, gamma=0)

            ##########################################
            ##      更新圖像中其他的標定點
            ##########################################
            for otherOverlap in range(int(overlapId) + 1, overlapNum + 1):
                srcPtsList = overlapDict[str(otherOverlap)]
                if srcPtsList is None:
                    continue
                newTargetPtList = PerspectiveTransform.point_transfer(srcPtsList, matrix)

                ### 透視變換後新的標定點
                wordCoordDict[str(otherOverlap)] = newTargetPtList
            ### 每張圖片只做一次校正
            break

        ### 儲存圖片
        cv2.imwrite(f"perspectiveImg_{imgName}.jpg", perspectiveImg)

        ### 儲存透視變換矩陣
        np.save(f"perspective_{imgName}.npy", matrix)

    cv2.imshow("resImg", cv2.resize(resImg, (targetSize[0] // 2, targetSize[1] // 2)))
    cv2.imwrite("resImg.jpg", resImg)
    cv2.waitKey(0)


if __name__ == "__main__":
    ### Showroom
    overlapNum = 1
    camDataDict = {
        "1": {
            "imgPath": r"images\1_undistort\showroom\undistorted_vlcsnap-2024-01-29-10h10m09s123.png",
            "overlapDict": {
                "1": [[607, 553], [773, 552], [773, 691], [609, 691]],
            },
        },
        "2": {
            "imgPath": r"images\1_undistort\showroom\undistorted_vlcsnap-2024-01-29-10h12m27s337.png",
            "overlapDict": {
                "1": [[1512, 1390], [1615, 1210], [1763, 1294], [1660, 1474]],
            },
        },
    }

    ### 實驗取樣
    # overlapNum = 2
    # camDataDict = {
    #     "1": {
    #         "imgPath": r"images\1_undistort\E96_manual\undistortedImg_20240125_092919.jpg",
    #         "overlapDict": {
    #             "1": [[796, 799], [603, 757], [667, 563], [836, 600]],
    #             "2": None,
    #         },
    #     },
    #     "2": {
    #         "imgPath": r"images\1_undistort\E96_manual\undistortedImg_20240125_093014.jpg",
    #         "overlapDict": {
    #             "1": [[630, 1118], [474, 966], [647, 776], [802, 913]],
    #             "2": [[919, 821], [724, 675], [839, 542], [1019, 672]],
    #         },
    #     },
    #     "3": {
    #         "imgPath": r"images\1_undistort\E96_manual\undistorted_20240125_093053.jpg",
    #         "overlapDict": {
    #             "1": None,
    #             "2": [[668, 1069], [533, 868], [678, 748], [833, 939]],
    #         },
    #     },
    # }

    main(camDataDict, overlapNum, targetSize=(5000, 5000))
