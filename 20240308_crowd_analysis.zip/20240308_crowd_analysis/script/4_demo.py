### 整合畸變校正, 鳥瞰全景圖片拼接, 投影到平面圖, 驗證相機標定結果
import cv2
import json
import numpy as np
import os
import sys

currentPath = os.path.abspath(__file__)
modulePath = os.path.dirname(currentPath)
sys.path.append(os.path.dirname(modulePath))

from packages.ImageProcess import ImageProcess, Plot
from packages.Calibration import Distortion, PerspectiveTransform, AffineTransform
from const import Specification


def main(camDataDict, layoutImgPath, layoutBlock):
    """
    Args:
        camDataDict (Dict): 各相機參數
        layoutImgPath (str): 平面圖路徑
        layoutBlock (list): 平面圖有效區域, [(x1, y1), (x2, y2)]
    """
    resImg = None

    for camId, camData in camDataDict.items():
        ### 魚眼圖片
        img = cv2.imread(camData["imgPath"])
        ### 座標點
        ptList = cv2.imread(camData["ptList"])

        ### 載入相機參數
        camSpec = camData["camSpec"]
        with open(camSpec.inParamsPath, "r") as file:
            inParamsDict = json.load(file)
            ### 內參, 畸變係數
            mtx, dist = np.array(inParamsDict["mtx"]), np.array(inParamsDict["dist"])

        ### 載入平視校正矩陣
        perspectiveMtx = np.load(camData["perspectiveMtxPath"])

        ### 載入平面圖投影矩陣
        affineMtx = np.load(camData["affineMtxPath"])

        ### 載入平面圖
        layoutImg = cv2.imread(layoutImgPath)

        ##########################################
        ##              前處理
        ##########################################
        ### 裁掉魚眼黑色區域
        if camSpec.preProc:
            centerX = camSpec.centerX
            centerY = camSpec.centerY
            radius = camSpec.radius
            img = ImageProcess.get_fisheye(
                img,
                centerX,
                centerY,
                radius,
            )

            resPtList = list()
            for pt in ptList:
                x, y = pt
                x -= centerX - radius
                y -= centerY - radius
                resPtList.append((x, y))
            ptList = resPtList

        ### 畫上點座標
        img = Plot.Plot.plot_points_on_imgs_on_img(img, ptList, 10, (0, 255, 0))
        cv2.imshow("img", img)

        ##########################################
        ##              畸變校正
        ##########################################
        undistortedImg = Distortion.img_undistort(img, mtx, dist, camSpec.type, alpha=0.8)
        ptList = Distortion.point_transfer(ptList, mtx, dist, camSpec.type, alpha=0.8)
        # cv2.imshow("undistortedImg", undistortedImg)

        ##########################################
        ##       平視校正 & 投影到世界座標
        ##########################################
        ### 透視變換
        targetSize = (5000, 5000)
        perspectiveImg = PerspectiveTransform.img_transfer(undistortedImg, perspectiveMtx, targetSize)
        ptList = PerspectiveTransform.point_transfer(ptList, perspectiveMtx)
        # cv2.imshow("perspectiveImg", perspectiveImg)

        ##########################################
        ##           投影到平面圖
        ##########################################
        affineImg = AffineTransform.img_transfer(perspectiveImg, affineMtx, targetImgSize=layoutImg.shape[:2][::-1])
        ptList = AffineTransform.point_transfer(ptList, affineMtx)
        # cv2.imshow("affineImg", affineImg)
        cv2.waitKey(0)

        ##########################################
        ##           圖像拼接
        ##########################################
        if resImg is None:
            resImg = affineImg
        else:
            resImg = cv2.addWeighted(src1=resImg, alpha=0.5, src2=affineImg, beta=0.5, gamma=0)

        ### 畫上點座標
        if camId == "1":
            color = (0, 0, 255)
        elif camId == "2":
            color = (255, 0, 0)
        resImg = Plot.plot_points_on_img(resImg, ptList, 5, color)

        layoutImg[layoutBlock[0][1] : layoutBlock[1][1], layoutBlock[0][0] : layoutBlock[1][0]] = resImg[
            layoutBlock[0][1] : layoutBlock[1][1], layoutBlock[0][0] : layoutBlock[1][0]
        ]

    cv2.imshow("layoutImg", layoutImg)
    cv2.waitKey(0)


if __name__ == "__main__":
    camDataDict = {
        "1": {
            "imgPath": r"images\0_fisheye\multi_view_showroom\D063TR\vlcsnap-2024-01-29-10h10m09s123.png",
            "ptList": [(1457, 1157), (643, 1118), (834, 806)],
            "camSpec": Specification.D063TR,
            "perspectiveMtxPath": r"data\matrix\showroom\perspective_2024-01-29-10h10m09s123.npy",
            "affineMtxPath": r"data\matrix\showroom\affine.npy",
        },
        "2": {
            "imgPath": r"images\0_fisheye\multi_view_showroom\B511A\vlcsnap-2024-01-29-10h12m27s337.png",
            "ptList": [(2851, 1063), (2669, 1670), (2519, 1269)],
            "camSpec": Specification.B511A,
            "perspectiveMtxPath": r"data\matrix\showroom\perspective_2024-01-29-10h12m27s337.npy",
            "affineMtxPath": r"data\matrix\showroom\affine.npy",
        },
    }
    layoutImgPath = r"images\showroom_layout.png"
    layoutBlock = [(211, 14), (831, 806)]

    main(camDataDict, layoutImgPath, layoutBlock)
