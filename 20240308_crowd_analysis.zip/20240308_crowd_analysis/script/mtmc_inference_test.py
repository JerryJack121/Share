### FIXME: yjchou 2024/03/08 部分流程與人流系統不同

import cv2
import json
import numpy as np
import os
import math
import sys
from scipy.optimize import linear_sum_assignment

os.environ["CUDA_VISIBLE_DEVICES"] = "1"


from packages.Rapid import Detector
from packages.Calibration import Distortion, PerspectiveTransform, AffineTransform
from packages.ImageProcess import ImageProcess, Plot
from packages.CentroidTracker import CentroidTracker

from packages.Bytetrack.byte_tracker import BYTETracker
from packages.Bytetrack2.byte_tracker import BYTETracker as BYTETracker2

from const import Specification
from utils.CamCapture import CamCapture


COLOR_LIST = [
    (0, 0, 255),  # 紅色
    (255, 0, 0),  # 藍色
    (0, 165, 255),  # 橙色
    (238, 130, 238),  # 紫羅蘭
    (0, 215, 255),  # 金色
    (42, 42, 165),  # 棕色
    (255, 0, 255),  # 品紅色
    (32, 178, 170),  # 土黃色
    (255, 255, 0),  # 黃色
]


def is_point_inside_mask(point, maskPoints):
    res = cv2.pointPolygonTest(np.array(maskPoints, dtype=np.float32), point, measureDist=False)
    if res >= 0:
        return True
    else:
        return False


class Person:
    """Detecton 偵測到的目標"""

    def __init__(self):
        self.camId = None
        self.localId = None
        self.globalId = None

    def save_combine_coord_parm(self, center, foot, boxWidth, boxHeight, angle, conf):
        self.combineCoord = CombineCoord(center, foot, boxWidth, boxHeight, angle, conf)

    def save_one_cam_coord_parm(self, center, foot, boxWidth, boxHeight, angle, conf):
        self.oneCamCoord = OneCamCoord(center, foot, boxWidth, boxHeight, angle, conf)

    def save_distiort_coord_parm(self, center, foot):
        self.distiortCoord = DistortCoord(center, foot)

    def save_layout_coord_parm(self, foot):
        self.layoutCoord = LayoutCoord(foot)


class CombineCoord:
    """合併魚眼坐標系"""

    def __init__(self, center, foot, boxWidth, boxHeight, angle, conf):
        self.center = center
        self.foot = foot
        self.boxWidth = boxWidth
        self.boxHeight = boxHeight
        self.angle = angle
        self.conf = conf

    @staticmethod
    def point_to_one_cam(point, camWidth, camHeight, camSpec, loc):
        x, y = point
        if (
            x >= camWidth * (loc[0] - 1)
            and x < camWidth * (loc[0])
            and y >= camHeight * (loc[1] - 1)
            and y < camHeight * (loc[1])
        ):
            ### 切分攝影機
            x -= camWidth * (loc[0] - 1)
            y -= camHeight * (loc[1] - 1)

            ### 尺寸縮放
            if camSpec.preProc:
                orgWidth, orgHeight = (camSpec.radius * 2), (camSpec.radius * 2)
            else:
                orgWidth, orgHeight = camSpec.orgSize
            ratioX, ratioY = orgWidth / camWidth, orgHeight / camHeight
            resPoint = (int(x * ratioX), int(y * ratioY))
        else:
            resPoint = None
        return resPoint

    @staticmethod
    def box_to_one_cam(width, height, camWidth, camHeight, camSpec):
        ### 尺寸縮放
        if camSpec.preProc:
            orgWidth, orgHeight = (camSpec.radius * 2), (camSpec.radius * 2)
        else:
            orgWidth, orgHeight = camSpec.orgSize
        ratioX, ratioY = orgWidth / camWidth, orgHeight / camHeight
        resWidth = width * ratioX
        resHeight = height * ratioY
        return resWidth, resHeight


class OneCamCoord:
    """單攝影機坐標系"""

    def __init__(self, center, foot, boxWidth, boxHeight, angle, conf):
        self.center = center
        self.foot = foot
        self.boxWidth = boxWidth
        self.boxHeight = boxHeight
        self.angle = angle
        self.conf = conf

        x1, x2, y1, y2 = (
            center[0] - boxWidth // 2,
            center[0] + boxWidth // 2,
            center[1] - boxHeight // 2,
            center[1] + boxHeight // 2,
        )
        self.bbox = [x1, y1, x2, y2, conf, center]


class DistortCoord:
    """畸變校正坐標系"""

    def __init__(self, center, foot):
        self.center = center
        self.foot = foot


class LayoutCoord:
    """平面圖坐標系"""

    def __init__(self, foot):
        self.foot = foot


def plot_point(img, ptList, radius, color):
    resImg = img.copy()
    for pt in ptList:
        resImg = cv2.circle(resImg, pt, radius, color, thickness=-1)
    return resImg


def plot_bbox(img, x, y, w, h, angle, color, linewidth=3):
    resImg = img.copy()
    c, s = np.cos(angle / 180 * np.pi), np.sin(angle / 180 * np.pi)
    R = np.asarray([[c, s], [-s, c]])
    pts = np.asarray([[-w / 2, -h / 2], [w / 2, -h / 2], [w / 2, h / 2], [-w / 2, h / 2]])
    rot_pts = []
    for pt in pts:
        rot_pts.append(([x, y] + pt @ R).astype(int))
    contours = np.array([rot_pts[0], rot_pts[1], rot_pts[2], rot_pts[3]])

    ### 畫框
    cv2.polylines(resImg, [contours], isClosed=True, color=color, thickness=linewidth, lineType=cv2.LINE_4)

    return resImg


def main(camDataDict, layoutImgPath, layoutBlock, videoMode=False):
    ### 載入平面圖
    layoutImg = cv2.imread(layoutImgPath)

    for camId, camData in camDataDict.items():
        ##########################################
        ##              Initinalize
        ##########################################
        ### 載入相機參數
        with open(camData["camSpec"].inParamsPath, "r") as file:
            inParamsDict = json.load(file)
            ### 內參, 畸變係數
            camDataDict[camId]["mtx"] = np.array(inParamsDict["mtx"])
            camDataDict[camId]["dist"] = np.array(inParamsDict["dist"])

        ### 載入平視校正矩陣
        camDataDict[camId]["perspectiveMtx"] = np.load(camData["perspectiveMtxPath"])

        ### 載入平面圖投影矩陣
        camDataDict[camId]["affineMtx"] = np.load(camData["affineMtxPath"])

        ### 相機初始化
        camCapture = CamCapture(camDataDict, imgSize=1024, videoMode=videoMode)

        ### 載入 RAPiD Model
        detector = Detector(
            model_name="rapid",
            weights_path=r"D:\Users\YjChou\Smart Retail\rapid_data\model_weights\pL1_MWHB1024_Mar11_4000.ckpt",
            use_cuda=True,
        )

        ### 初始化單攝影機追蹤
        camSpec = camDataDict[camId]["camSpec"]
        ### XXX: maxDistance 比例手動調整
        alpha = 0.07
        if camSpec.preProc:
            maxDistance = camDataDict[camId]["camSpec"].radius * alpha
        else:
            maxDistance = camDataDict[camId]["camSpec"].orgSize[0] // 2 * alpha

        if True:
            camDataDict[camId]["tracker"] = CentroidTracker(maxDisappeared=8, maxDistance=maxDistance)
        else:
            # camDataDict[camId]["tracker"] = BYTETracker(
            #     frame_rate=15,
            #     track_thresh=0.5,
            #     track_buffer=30,
            #     match_thresh=0.5,
            # )
            camDataDict["1"]["tracker"] = BYTETracker(
                frame_rate=30,
                track_thresh=0.6,  # Detect 的信心分數
                track_buffer=50,
                match_thresh=0.8,
            )
            camDataDict["2"]["tracker"] = BYTETracker2(
                frame_rate=30,
                track_thresh=0.6,  # Detect 的信心分數
                track_buffer=50,
                match_thresh=0.8,
            )

        ### 初始化多攝影機追蹤
        matcher = Matcher(
            camIdList=["1", "2", "3"],
            associationList=[["1", "2"], ["1", "3"]],
            maxDistance=100,
            img=layoutImg,
            visualize=True,
        )
        camDataDict[camId]["trackPersonDict"] = dict()  # 追蹤過的所有 localId 的最新狀態 ### TODO: 刪除消失的 ID

    globalIdStableDict = dict()
    while True:
        resDict = dict()
        globalIdDict = dict()  # 當前幀所有 global id 在平面圖上的位置
        isRecordglobalId = False

        ##########################################
        ###              Load Data
        ##########################################
        combingOrgImg, combineMaskImg = camCapture.get_combine_frame()

        ##########################################
        ###              RAPiD
        ##########################################
        inputSize = combineMaskImg.shape[0]
        pilImg = ImageProcess.cv2pil(combineMaskImg)
        detections = detector.detect_one(pil_img=pilImg, input_size=inputSize, conf_thres=0.35, return_img=False)

        combineImg = combineMaskImg
        ### 計算腳座標
        detectImg = combineImg.copy()
        allPersonList = list()
        for bb in detections:
            x, y, w, h, a, conf = bb
            imgWidth, imgHeight = combineImg.shape[1], combineImg.shape[0]
            footPoint = detector.get_foot(x, y, w, h, a, imgWidth, imgHeight, mode=2)
            person = Person()
            person.save_combine_coord_parm((int(x), int(y)), footPoint, int(w), int(h), float(a), float(conf))
            allPersonList.append(person)

            detectImg = plot_bbox(detectImg, x, y, w, h, a, (255, 0, 0))

        ##############################################
        ###                 後處理
        ##############################################
        camWidth, camHeight = combineImg.shape[1] // 2, combineImg.shape[0] // 2
        for camId in camDataDict.keys():
            resDict[camId] = dict()
            resDict[camId]["detectImg"] = None
            resDict[camId]["persons"] = list()  # 當前幀有檢測到的人

            mtx, dist = camDataDict[camId]["mtx"], camDataDict[camId]["dist"]
            perspectiveMtx = camDataDict[camId]["perspectiveMtx"]
            affineMtx = camDataDict[camId]["affineMtx"]

            ###  XXX: 4合1大圖切分各攝影機
            if camId == "1":
                loc = [1, 1]
            elif camId == "2":
                loc = [2, 1]
            elif camId == "3":
                loc = [1, 2]
            camDetectImg = detectImg[
                camHeight * (loc[1] - 1) : camHeight * (loc[1]),
                camWidth * (loc[0] - 1) : camWidth * (loc[0]),
            ]

            ### 尺寸調整回原始魚眼尺寸
            camSpec = camDataDict[camId]["camSpec"]
            if camSpec.preProc:
                camDetectImg = cv2.resize(camDetectImg, (camSpec.radius * 2, camSpec.radius * 2))
            else:
                camDetectImg = cv2.resize(camDetectImg, camSpec.orgSize)

            resDict[camId]["detectImg"] = camDetectImg

            for i, person in enumerate(allPersonList):

                ### TODO: 以過濾點位方式過濾遮罩內的目標

                center = person.combineCoord.center
                foot = person.combineCoord.foot

                ### 原圖中畫辨識結果
                cv2.circle(detectImg, center, 5, (255, 0, 0), -1)
                cv2.circle(detectImg, foot, 5, (0, 255, 0), -1)

                ### 切分各攝影機
                center = CombineCoord.point_to_one_cam(center, camWidth, camHeight, camSpec, loc)
                foot = CombineCoord.point_to_one_cam(foot, camWidth, camHeight, camSpec, loc)

                if center is None:
                    ### 不屬於這台攝影機負責的目標
                    continue

                person.camId = camId
                boxWidth, boxHeight = CombineCoord.box_to_one_cam(
                    person.combineCoord.boxWidth,
                    person.combineCoord.boxHeight,
                    camWidth,
                    camHeight,
                    camSpec,
                )
                person.save_one_cam_coord_parm(
                    center,
                    foot,
                    boxWidth,
                    boxHeight,
                    person.combineCoord.angle,
                    person.combineCoord.conf,
                )

                ### 畸變校正
                corrCenter, corrFoot = Distortion.point_transfer([center, foot], mtx, dist, camSpec.type, alpha=0.8)
                person.save_distiort_coord_parm(corrCenter, corrFoot)

                ### 投影到平面圖的座標
                affineFoot = PerspectiveTransform.point_transfer([corrFoot], perspectiveMtx)[0]
                layoutFoot = AffineTransform.point_transfer([affineFoot], affineMtx)[0]
                x, y = layoutFoot
                layoutFoot = (
                    layoutFoot

                    else None
                )

                person.save_layout_coord_parm(layoutFoot)

                allPersonList[i] = person
                resDict[camId]["persons"].append(person)

            ### 單攝影機追蹤
            prepareForTrack = list()
            if True:
                ### 質心追蹤
                for person in resDict[camId]["persons"]:
                    point = person.layoutCoord.foot
                    if point is not None:
                        prepareForTrack.append(point)
            else:
                ### ByteTrack
                ### FIXME:
                for person in resDict[camId]["persons"]:
                    prepareForTrack.append(person.oneCamCoord.bbox)

            obj = camDataDict[camId]["tracker"].update(prepareForTrack)
            resDict[camId]["localId2trackPointDict"] = obj
            ### 將 localId 存回 person
            for localId, trackPoint in obj.items():
                for i, person in enumerate(resDict[camId]["persons"]):
                    if True:
                        ### 質心追蹤
                        point = person.layoutCoord.foot
                    else:
                        ### ByteTrack
                        point = person.oneCamCoord.center
                    if point is None:
                        continue
                    if tuple(trackPoint) == tuple(point):
                        person.localId = localId
                        resDict[camId]["persons"][i] = person
                        camDataDict[camId]["trackPersonDict"][str(person.localId)] = person
                        break

            resDict[camId]["localId2layoutFootDict"] = dict()
            for localId in resDict[camId]["localId2trackPointDict"].keys():
                person = camDataDict[camId]["trackPersonDict"][str(localId)]
                resDict[camId]["localId2layoutFootDict"][str(localId)] = person.layoutCoord.foot

        ### 多攝影機點位匹配
        prepareForMatcher = dict()
        for camId in resDict.keys():
            prepareForMatcher[str(camId)] = resDict[camId]["localId2layoutFootDict"]
        matcher.update(prepareForMatcher)

        for camId in resDict.keys():
            ### 將 globalId 存回 person
            personList = resDict[camId]["persons"]
            for i, person in enumerate(personList):
                localId = person.localId
                globalId = matcher.get_global_id(camId, localId)
                personList[i].globalId = globalId
            resDict[camId]["persons"] = personList

            ### 記錄當前所有 globalId 在平面圖上的位置與出現幀數
            for localId, _ in resDict[camId]["localId2trackPointDict"].items():
                person = camDataDict[camId]["trackPersonDict"][str(localId)]
                globalId = person.globalId
                layoutFoot = person.layoutCoord.foot
                if layoutFoot is None:
                    continue

                ### 記錄平面圖上的位置
                if globalId not in globalIdDict.keys():
                    globalIdDict[globalId] = [layoutFoot]
                else:
                    globalIdDict[globalId].append(layoutFoot)

                ### 記錄出現幀數
                if globalId not in globalIdStableDict.keys():
                    globalIdStableDict[globalId] = 1
                else:
                    if not isRecordglobalId:
                        globalIdStableDict[globalId] += 1

        ### Visuzlize
        ### 畸變校正
        # undistortedImg = Distortion.img_undistort(camDetectImg, mtx, dist, camSpec.type, alpha=0.8)
        # cv2.imshow(f"undistortedImg_{camId}", undistortedImg)

        ### 透視變換 (平視校正 & 投影到世界座標)
        # perspectiveImg = PerspectiveTransform.img_transfer(
        #     undistortedImg, perspectiveMtx, targetImgSize=(5000, 5000)
        # )
        # cv2.imshow(f"perspectiveImg_{camId}", perspectiveImg)

        ### 仿射變換
        # affineImg = AffineTransform.img_transfer(perspectiveImg, affineMtx, targetImgSize=layoutImg.shape[:2][::-1])
        # cv2.imshow(f"affineImg_{camId}", affineImg)

        globalIdImg = layoutImg.copy()
        for camId in resDict.keys():
            personList = resDict[camId]["persons"]

            ### 在魚眼圖上顯示有偵測到的目標的 Global ID
            for person in personList:
                globalId = person.globalId
                if globalId is None:
                    continue

                cv2.putText(
                    detectImg,
                    str(globalId),
                    tuple(person.combineCoord.foot),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    1.5,
                    (0, 255, 0),
                    2,
                    cv2.LINE_AA,
                )

        for globalId, layoutFootList in globalIdDict.items():
            ### 忽略短暫出現的 GlobalId 不顯示
            if not globalIdStableDict[globalId] > 15:
                continue

            for i, layoutFoot in enumerate(layoutFootList):
                if i == 0:
                    x, y = layoutFoot
                else:
                    x = (x + layoutFoot[0]) // 2
                    y = (x + layoutFoot[1]) // 2
            cv2.circle(globalIdImg, (x, y), 5, (0, 255, 0), thickness=-1)
            cv2.putText(
                globalIdImg,
                f"{str(globalId)}",
                (x, y),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 0, 0),
                1,
                cv2.LINE_AA,
            )

        detectImg = cv2.resize(detectImg, (1024, 1024))
        cv2.imshow("detectImg", detectImg)
        cv2.imshow("globalIdImg", globalIdImg)
        cv2.waitKey(1)


class Matcher:
    def __init__(self, camIdList, associationList, maxDistance=None, img=None, visualize=False):
        self.camIdList = camIdList
        self.associationList = associationList
        self.maxDistance = maxDistance
        self.img = img
        self.visualize = visualize

        self.singleCamSet, nonSingleCamSet = set(), set()
        for association in self.associationList:
            if len(association) < 2:
                raise ValueError("攝影機關聯至少要 2 台攝影機")
            for camId in association:
                nonSingleCamSet.add(camId)

        for camId in self.camIdList:
            if camId not in nonSingleCamSet:
                self.singleCamSet.add(camId)

        if self.visualize and self.img is None:
            raise ValueError("請輸用於可視化的圖片")

        self.maxCost = 1e6  # 極大值, 理論上不需要調整
        self.setup()

    def setup(self):
        self.nextGlobalId = 0  # 下一個賦予的 Global ID
        self.misMatchDict = dict()  # 記錄因匹配到不同的 Global ID 而被取消配對的次數

        ### 建立各攝影機 Local ID 對應 Global ID 的對照表
        self.local2GlobalIdDict = dict()  # 各攝影機 local ID 對應 Global ID 的對照表
        for camId in self.camIdList:
            self.local2GlobalIdDict[str(camId)] = dict()

        ### TODO: 建立 yjchou 2024/02/29 Global ID 對應各攝影機 local ID 的對照表
        self.golbal2LocalIdDict = dict()

    def update(self, camLocalId2layoutFootDict):
        camNum = len(camLocalId2layoutFootDict.keys())
        camObjDict, fullGlobalIdList = self.__prepare_data(camLocalId2layoutFootDict)
        camIdList = list(camObjDict.keys())

        ### 即將取得新 global ID, 全部攝影機, 等所有攝影機匹配後仍沒有 Global ID 再賦予
        self.readyGetGlobalIdList = list()

        ### TODO: yjchou 2024/02/29 根據設定的關聯性進行匹配
        if True:
            resList = list()
            ### 依序兩兩匹配有關聯性的攝影機
            for association in self.associationList:
                camNum = len(association)
                for camId in association:
                    if camId not in camIdList:
                        raise ValueError("請檢查 associationList 中的 camId 與 camLocalId2layoutFootDict 是否一致")

                    for i in range(camNum - 1):
                        camId1 = association[i]
                        for j in range(i + 1, camNum):
                            camId2 = association[j]
                            tmpResList = self.__match_two_cam(
                                camId1,
                                camId2,
                                camObjDict[camId1],
                                camObjDict[camId2],
                                fullGlobalIdList,
                            )
                            resList = resList + tmpResList

            ### TODO: 與其他攝影機無關聯性的目標, 加入準備給予 readyGetGlobalIdList
            for camId in self.singleCamSet:
                obj = camObjDict[str(camId)]
                for localId in obj.keys():
                    readyGet = f"{camId}_{localId}"
                    self.readyGetGlobalIdList.append([readyGet])

        ### 兩兩攝影機輪流做匹配
        elif False:
            resList = list()
            camNum = len(camIdList)
            for i in range(camNum - 1):
                camId1 = camIdList[i]
                for j in range(i + 1, camNum):
                    camId2 = camIdList[j]
                    tmpResList = self.__match_two_cam(
                        camId1,
                        camId2,
                        camObjDict[camId1],
                        camObjDict[camId2],
                        fullGlobalIdList,
                    )
                    resList = resList + tmpResList

        ### XXX: Hard code 兩台攝影機輪做匹配
        else:
            camId1, camId2 = "1", "2"
            resList = self.__match_two_cam(
                camId1,
                camId2,
                camObjDict[camId1],
                camObjDict[camId2],
                fullGlobalIdList,
            )

        ### NOTE: 判斷在準備要獲得 Global ID 的組合中, 是否有已經配對到既有 Global ID 的
        for readyGetGlobalId in self.readyGetGlobalIdList:
            withGlobalId = False
            for readyGetText in readyGetGlobalId:
                camId, localId = readyGetText.split("_")
                globalId = self.get_global_id(camId, localId)
                if globalId is not None:
                    withGlobalId = True
                    break

            for readyGetText in readyGetGlobalId:
                camId, localId = readyGetText.split("_")
                ### 全部給既有的 Global Id
                if withGlobalId:
                    self.local2GlobalIdDict[str(camId)][str(localId)] = globalId
                ### 全部給新的相同 Global Id
                else:
                    self.local2GlobalIdDict[str(camId)][str(localId)] = self.nextGlobalId
            if not withGlobalId:
                self.nextGlobalId += 1

        if self.visualize:
            self.resImg = self.img.copy()
            ### 畫各攝影機追蹤中的點, Local ID -> Global ID (包含短暫消失的目標)
            for i, camId in enumerate(camIdList):
                obj = camObjDict[camId]
                color = COLOR_LIST[i]
                for localId, layoutPt in obj.items():
                    globalId = self.get_global_id(camId, localId)
                    self.resImg = cv2.circle(self.resImg, layoutPt, 5, color, thickness=-1)
                    cv2.putText(
                        self.resImg,
                        f"{localId}->{globalId}",
                        tuple(layoutPt),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        color,
                        1,
                        cv2.LINE_AA,
                    )

            ### 畫匹配成功的線
            if len(resList) > 0:
                for res in resList:
                    globalId, layoutPt1, layoutPt2 = res
                    cv2.line(self.resImg, layoutPt1, layoutPt2, (0, 255, 0), 2)
                    if True:
                        ### 顯示距離
                        dist = cal_dis(layoutPt1, layoutPt2)

                        textLocX = (layoutPt1[0] + layoutPt2[0]) // 2
                        textLocY = (layoutPt1[1] + layoutPt2[1]) // 2
                        cv2.putText(
                            self.resImg,
                            str(round(dist, 1)),
                            (textLocX, textLocY),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.3,
                            (0, 0, 0),
                            1,
                            cv2.LINE_AA,
                        )
            cv2.imshow("MTMCTracker", self.resImg)
            cv2.waitKey(1)

    def get_global_id(self, camId, localId):
        if str(localId) in self.local2GlobalIdDict[str(camId)].keys():
            return self.local2GlobalIdDict[str(camId)][str(localId)]
        return None

    def __match_two_cam(self, camId1, camId2, obj1, obj2, fullGlobalIdList):
        resList = list()

        if len(obj1) > 0 and len(obj2) > 0:
            arr = np.empty((len(obj1), len(obj2)), dtype=np.float32)
            for i, pt1 in enumerate(obj1.values()):
                for j, pt2 in enumerate(obj2.values()):
                    ### 計算歐式距離
                    ### TODO: yjchou 2024/02/26 用 numpy 優化
                    dist = cal_dis(pt1, pt2)
                    arr[i][j] = dist
            arr[arr > self.maxDistance] = self.maxCost

            ### NOTE: 使用匈牙利算法配對點
            rowIdx, colIdx = linear_sum_assignment(arr)

            ### NOTE: 根據多項機制判斷是否配對成功
            for i, j in zip(rowIdx, colIdx):
                isCancel = False
                localId1 = list(obj1.keys())[i]
                localId2 = list(obj2.keys())[j]
                pt1 = obj1[localId1]
                pt2 = obj2[localId2]

                ### 超過匹配距離限制, 取消配對
                dist = cal_dis(pt1, pt2)
                if self.maxDistance is not None:
                    if not self.__check_rule1(dist):
                        isCancel = True
                        continue

                ### 兩個 ID 都沒有被配對過, 賦予相同新 ID
                if (
                    str(localId1) not in self.local2GlobalIdDict[str(camId1)].keys()
                    and str(localId2) not in self.local2GlobalIdDict[str(camId2)].keys()
                ):
                    globalId = self.nextGlobalId
                    ### 等所有攝影機匹配後, 仍沒有 Global ID 再賦予
                    if True:
                        readyGet1 = f"{camId1}_{localId1}"
                        readyGet2 = f"{camId2}_{localId2}"
                        self.readyGetGlobalIdList.append([readyGet1, readyGet2])
                    ### 馬上賦予 Global ID
                    else:
                        self.local2GlobalIdDict[str(camId1)][str(localId1)] = globalId
                        self.local2GlobalIdDict[str(camId2)][str(localId2)] = globalId
                        self.nextGlobalId += 1

                ### Cam2 繼承 Cam1 的 Global ID
                elif (
                    str(localId1) in self.local2GlobalIdDict[str(camId1)].keys()
                    and str(localId2) not in self.local2GlobalIdDict[str(camId2)].keys()
                ):
                    globalId = self.local2GlobalIdDict[str(camId1)][str(localId1)]
                    if self.__check_rule2(globalId, fullGlobalIdList):
                        self.local2GlobalIdDict[str(camId2)][str(localId2)] = globalId
                    else:
                        isCancel = True

                ### Cam1 繼承 Cam2 的 Global ID
                elif (
                    str(localId1) not in self.local2GlobalIdDict[str(camId1)].keys()
                    and str(localId2) in self.local2GlobalIdDict[str(camId2)].keys()
                ):
                    globalId = self.local2GlobalIdDict[str(camId2)][str(localId2)]
                    if self.__check_rule2(globalId, fullGlobalIdList):
                        self.local2GlobalIdDict[str(camId1)][str(localId1)] = globalId
                    else:
                        isCancel = True

                else:
                    ### 兩個已被配對為相同 Global ID
                    if (
                        self.local2GlobalIdDict[str(camId1)][str(localId1)]
                        == self.local2GlobalIdDict[str(camId2)][str(localId2)]
                    ):
                        globalId = self.local2GlobalIdDict[str(camId1)][str(localId1)]
                    ### 兩個都已經被賦予不同的 Global ID
                    else:
                        ### 多次配對後以較小的 Global ID 為主
                        if self.__check_rule3(camId1, localId1, camId2, localId2):
                            globalId = min(
                                self.local2GlobalIdDict[str(camId1)][str(localId1)],
                                self.local2GlobalIdDict[str(camId2)][str(localId2)],
                            )
                            self.local2GlobalIdDict[str(camId1)][str(localId1)] = globalId
                            self.local2GlobalIdDict[str(camId2)][str(localId2)] = globalId
                        else:
                            isCancel = True

                if not isCancel:
                    resList.append(list((globalId, obj1[localId1], obj2[localId2])))

        ### 沒有配對到的單獨賦予 Global ID
        for camId, obj in [[camId1, obj1], [camId2, obj2]]:
            for localId in obj.keys():
                if str(localId) not in self.local2GlobalIdDict[str(camId)].keys():
                    ### 等所有攝影機匹配後, 仍沒有 Global ID 再賦予
                    if True:
                        readyGet = f"{camId}_{localId}"
                        self.readyGetGlobalIdList.append([readyGet])
                    ### 馬上賦予 Global ID
                    else:
                        self.local2GlobalIdDict[str(camId)][str(localId)] = self.nextGlobalId
                        self.nextGlobalId += 1

        return resList

    def __prepare_data(self, camLocalId2layoutFootDict):
        camObjDict = dict()  # 當前用於匹配的目標

        ### 準備資料
        numGlobalIdDict = dict()  # 當前已被佔滿的 Global ID
        for camId, localId2layoutFootDict in camLocalId2layoutFootDict.items():
            ### 建立各攝影機 Local ID 對應平面圖腳座標的對照表
            if str(camId) not in camObjDict.keys():
                camObjDict[str(camId)] = dict()

            ### 在平面圖上以腳座標做追蹤
            for localId, layoutFoot in localId2layoutFootDict.items():
                ### 只匹配在平面圖有效區中的目標
                if layoutFoot is None:
                    continue

                camObjDict[str(camId)][str(localId)] = layoutFoot

                ### 如果當前追蹤的目標已經有 Global ID, 計算畫面中相同 Global ID 的數量
                if str(localId) in self.local2GlobalIdDict[str(camId)].keys():
                    globalId = self.local2GlobalIdDict[str(camId)][str(localId)]
                    if str(globalId) not in numGlobalIdDict.keys():
                        numGlobalIdDict[str(globalId)] = 1
                    else:
                        numGlobalIdDict[str(globalId)] += 1

        ### 列出當前已達數量上限的 Global ID
        fullGlobalIdList = list()
        camNum = len(camLocalId2layoutFootDict)
        for globalId, num in numGlobalIdDict.items():
            if num >= camNum:
                fullGlobalIdList.append(globalId)

        return camObjDict, fullGlobalIdList

    def __check_rule1(self, dist):
        """互相配對的點距離要小於 maxDistance"""
        if dist <= self.maxDistance:
            return True
        else:
            return False

    def __check_rule2(self, globalId, fullGlobalIdList):
        """相同 Global ID 數量要小於相機數

        Args:
            globalId (str)
            fullGlobalIdList (list)

        Returns:
            Bool
        """
        if str(globalId) not in fullGlobalIdList:
            return True
        else:
            return False

    def __check_rule3(self, camId1, localId1, camId2, localId2):
        """若兩個都已經被賦予不同的 Global ID, 要配對達一定次數才更改 Global ID"""
        key = f"{camId1}_{localId1}_{camId2}_{localId2}"
        if key not in self.misMatchDict.keys():
            self.misMatchDict[key] = 1  # 取消配對的次數
            return False
        else:
            if self.misMatchDict[key] < 10:  # FIXME: 建議大於 maxDisappeared
                self.misMatchDict[key] += 1
                return False
            else:
                del self.misMatchDict[key]
                return True


def cal_dis(pt1, pt2):
    x1, y1 = pt1
    x2, y2 = pt2
    dist = math.sqrt((math.pow((x1 - x2), 2) + math.pow((y1 - y2), 2)))
    return dist


if __name__ == "__main__":
    camDataDict = {
        "1": {
            "url": "D:/Users/YjChou/Smart Retail/rapid_data/videos/showroom/4/20240220163603_cam1_align.mp4",
            "camSpec": Specification.D063TR,
            "perspectiveMtxPath": r"data\matrix\showroom\perspective_2024-01-29-10h10m09s123.npy",
            "affineMtxPath": r"data\matrix\showroom\affine.npy",
            "maskList": [
                [(1251, 397), (1600, 433), (1600, 751), (1251, 751)],
                [(331, 420), (786, 271), (786, 823), (331, 823)],
                [(1081, 321), (1691, 321), (1691, 1529), (1081, 1529)],
            ],
        },
        "2": {
            "url": "D:/Users/YjChou/Smart Retail/rapid_data/videos/showroom/4/20240220163603_cam2_align.mp4",
            "camSpec": Specification.B511A,
            "perspectiveMtxPath": r"data\matrix\showroom\perspective_2024-01-29-10h12m27s337.npy",
            "affineMtxPath": r"data\matrix\showroom\affine.npy",
            "maskList": [
                [(2935, 1009), (3133, 1253), (2773, 2297), (2509, 2057)],
                [(2337, 407), (2851, 671), (2709, 907), (2239, 629)],
            ],
        },
        "3": {
            "url": "D:/Users/YjChou/Smart Retail/rapid_data/videos/showroom/4/20240220163603_cam1_align.mp4",
            "camSpec": Specification.D063TR,
            "perspectiveMtxPath": r"data\matrix\showroom\perspective_2024-01-29-10h10m09s123.npy",
            "affineMtxPath": r"data\matrix\showroom\affine.npy",
            "maskList": [
                [(1251, 397), (1600, 433), (1600, 751), (1251, 751)],
                [(331, 420), (786, 271), (786, 823), (331, 823)],
                [(237, 271), (817, 271), (817, 1527), (237, 1527)],
                [(817, 271), (1600, 271), (1600, 751), (817, 751)],
            ],
        },
    }
    layoutImgPath = r"images\showroom_layout.png"
    layoutBlock = [(211, 0), (831, 806)]

    main(camDataDict, layoutImgPath, layoutBlock, videoMode=True)
