### 相機內參標定, 畸變校正
import cv2
import os
import json
import numpy as np
import sys

currentPath = os.path.abspath(__file__)
modulePath = os.path.dirname(currentPath)
sys.path.append(os.path.dirname(modulePath))

from packages.ImageProcess import ImageProcess
from packages.Calibration import Calibration, Distortion
from const import Specification


def calibrate_camera(imgPathList, cornerNum, camType, visulize=True):
    """拍攝多張圖片, 求相機的內外參數

    Args:
        imgPathList (_type_): _description_
        cornerNum (_type_): _description_
        cameraType (_type_): _description_
    """

    calibrate = Calibration(cornerNum, camType)
    for imgPath in imgPathList:
        imgName = os.path.basename(imgPath)
        ### 讀取校準圖像(包含棋盤格)
        img = cv2.imread(imgPath)

        ### 裁掉黑色區域
        if camSpec.preProc:
            img = ImageProcess.get_fisheye(
                img,
                center_x=camSpec.centerX,
                center_y=camSpec.centerY,
                radius=camSpec.radius,
            )

        ### 加入校正圖片
        ret, resImg = calibrate.add_img(img)
        if ret:
            print(f"{imgName} Done")
            resImg = cv2.resize(resImg, (resImg.shape[1] // 2, resImg.shape[0] // 2))
            if visulize:
                cv2.imshow(imgName, resImg)
                cv2.waitKey(0)
                cv2.destroyAllWindows()
        else:
            print(f"{imgName} 未檢測到角點")

    ### 計算相機參數
    ret, mtx, dist, rvecs, tvecs = calibrate.solve_parm()

    return ret, mtx, dist, rvecs, tvecs


if __name__ == "__main__":
    folder = r"D:\UserShare\Coding\camera_calibrate\images\0_fisheye\multi_view_showroom\D063TR"
    camSpec = Specification.D063TR
    cornerNum = (11, 8)

    imgPathList = [os.path.join(folder, imgName) for imgName in os.listdir(folder)]
    ##########################################
    ##              相機標定
    ##########################################
    ### 多張圖片求相機內外參數
    ret, mtx, dist, rvecs, tvecs = calibrate_camera(
        imgPathList=imgPathList,
        cornerNum=cornerNum,
        camType=camSpec.type,
        visulize=False,
    )
    if ret:
        inParamsDict = {"mtx": mtx.tolist(), "dist": dist.tolist()}
    else:
        print("校正失敗")

    # print("mtx:\n", mtx)  # 內參數矩陣
    # print("dist:\n", dist)  # 畸變系數   distortion cofficients = (k_1,k_2,p_1,p_2,k_3)
    # print("rvecs:\n", rvecs)  # 旋轉向量 (外參數)
    # print("tvecs:\n", tvecs)  # 平移向量 (外參數)

    ### 儲存內部參數
    with open("inParams.json", "w") as file:
        json.dump(inParamsDict, file)

    ##########################################
    ##              圖像校正
    ##########################################
    ### 讀取內參數
    with open("inParams.json", "r") as file:
        inParamsDict = json.load(file)
        mtx, dist = np.array(inParamsDict["mtx"]), np.array(inParamsDict["dist"])

    for imgPath in imgPathList:
        imgName = os.path.basename(imgPath)
        img = cv2.imread(imgPath)

        ### 裁掉黑色區域
        if camSpec.preProc:
            img = ImageProcess.get_fisheye(
                img,
                center_x=camSpec.centerX,
                center_y=camSpec.centerY,
                radius=camSpec.radius,
            )

        ### 圖像畸變校正 (張氏標定法)
        undistortedImg = Distortion.img_undistort(img, mtx, dist, camSpec.type, alpha=0.8)

        ### Show Image
        cv2.imshow(imgName, img)
        cv2.imshow(f"undistorted_{imgName}", undistortedImg)
        cv2.imwrite(f"undistorted_{imgName}", undistortedImg)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
