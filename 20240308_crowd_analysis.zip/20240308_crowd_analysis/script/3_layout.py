### 鳥瞰全景投影到平面圖, 生成仿射變換矩陣
import cv2
import os
import numpy as np
import sys

currentPath = os.path.abspath(__file__)
modulePath = os.path.dirname(currentPath)
sys.path.append(os.path.dirname(modulePath))

from packages.Calibration import AffineTransform


def main(layoutImgPath, imgPath, layoutBlock, srcPtsList, targetPtsList):
    """
    Args:
        layoutImgPath (str): 平面圖路徑
        imgPath (str): 鳥瞰全景圖片路徑
        layoutBlock (list): 平面圖有效區域, [(x1, y1), (x2, y2)]
        srcPtsList (list): 鳥瞰全景圖片中的三個參考點, [(x1, y1), (x2, y2), (x3, y3)]
        targetPtsList (list): 平面圖中的三個參考點, [(x'1, y'1), (x'2, y'2), (x'3, y'3)]
    """
    imgFileName = os.path.basename(imgPath)
    imgName, _ = os.path.splitext(imgFileName)

    layoutImg = cv2.imread(layoutImgPath)
    img = cv2.imread(imgPath)
    matrix = AffineTransform.solve_matrix(srcPtsList, targetPtsList)
    affineImg = AffineTransform.img_transfer(img, matrix, targetImgSize=layoutImg.shape[:2][::-1])
    layoutImg[layoutBlock[0][1] : layoutBlock[1][1], layoutBlock[0][0] : layoutBlock[1][0]] = affineImg[
        layoutBlock[0][1] : layoutBlock[1][1], layoutBlock[0][0] : layoutBlock[1][0]
    ]

    ### 儲存仿射變換矩陣
    np.save(f"affine_{imgName}.npy", matrix)

    cv2.imshow("layoutImg", layoutImg)
    cv2.waitKey(0)


if __name__ == "__main__":
    ### Showroom
    layoutImgPath = r"images\showroom_layout.png"
    imgPath = r"images\2_birdview_stitching\showroom\resImg.jpg"

    layoutBlock = [(211, 14), (831, 806)]
    srcPtsList = [(1218, 1348), (2620, 1360), (2660, 2532)]
    targetPtsList = [(831, 14), (831, 806), (211, 806)]

    main(layoutImgPath, imgPath, layoutBlock, srcPtsList, targetPtsList)
