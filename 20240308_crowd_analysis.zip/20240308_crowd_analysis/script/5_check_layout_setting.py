import numpy as np
import yaml
import json
import os
import sys
import cv2
import math

currentPath = os.path.abspath(__file__)
modulePath = os.path.dirname(currentPath)
sys.path.append(os.path.dirname(modulePath))

from const.Specification import DistortMethod, CAM_SPEC_DICT
from packages.ImageProcess import ImageProcess, Plot
from utils.calibrate import img_distortion_corr
from packages.Calibration import PerspectiveTransform, AffineTransform


camDataDict = {
    "1": {
        "imgPath": r"crowd_analysis\data\Showroom\images\dev_images\0_cam\multi_view_showroom\D063TR\vlcsnap-2024-01-29-10h07m15s971.png",
        "camSpec": "D063TR",
    },
    "2": {
        "imgPath": r"crowd_analysis\data\Showroom\images\dev_images\0_cam\multi_view_showroom\B511A\vlcsnap-2024-01-29-10h07m06s225.png",
        "camSpec": "ACTi_B511A",
    },
    "3": {
        "imgPath": r"crowd_analysis\data\Showroom\images\dev_images\0_cam\multi_view_showroom\D063TR\vlcsnap-2024-01-29-10h07m15s971.png",
        "camSpec": "D063TR",
    },
}
layoutCfgPath = r"crowd_analysis\data\Showroom\config\new_layout.yml"

##############################################
###            初始化
##############################################
distortParmDict = dict()
### 相機初始化
for camId in camDataDict.keys():
    imgPath = camDataDict[camId]["imgPath"]
    camDataDict[camId]["img"] = cv2.imread(imgPath)

    ### 畸變校正參數初始化
    distortParmDict[camId] = dict()
    camSpec = camDataDict[camId]["camSpec"]
    camSpec = CAM_SPEC_DICT[camSpec]
    camDataDict[camId]["camSpec"] = camSpec

    method = camSpec.method
    distortParmDict[camId]["method"] = method
    if method == DistortMethod.LATITUDE_LONGITUDE:
        distortParmDict[camId]["mapX"] = np.load(camSpec.mapXPath)
        distortParmDict[camId]["mapY"] = np.load(camSpec.mapYPath)
    elif method == DistortMethod.CHESSBOARD:
        distortParmDict[camId]["alpha"] = np.array(camSpec.alpha)
        with open(camSpec.inParamsPath, "r") as file:
            inParamsDict = json.load(file)
            distortParmDict[camId]["mtx"] = np.array(inParamsDict["mtx"])
            distortParmDict[camId]["dist"] = np.array(inParamsDict["dist"])
            file.close()

### 載入設定檔
with open(layoutCfgPath, "r", encoding="utf-8") as file:
    config = yaml.safe_load(file)
    bridViewDict = config["bridViewDict"]
    layoutDict = config["layoutDict"]

### 載入平面圖
imgPath = layoutDict["imgPath"]
layoutImg = cv2.imread(imgPath)

for camId in camDataDict.keys():
    img = camDataDict[camId]["img"]
    camSpec = camDataDict[camId]["camSpec"]

    cv2.imwrite(f"cam{camId}.jpg", img)

    ### 前處理
    if camSpec.preProc:
        centerX = camSpec.centerX
        centerY = camSpec.centerY
        radius = camSpec.radius
        img = ImageProcess.get_fisheye(
            img,
            center=(centerX, centerY),
            radius=radius,
        )

    cv2.imwrite(f"fisheye_{camId}.jpg", img)

    ### 畸變校正
    undistortedImg = img_distortion_corr(img, distortParmDict[camId])

    ### 畸變校正後處理 (統一畸變校正上的標定尺寸)
    if camSpec.postProc:
        undistortedImg = cv2.resize(undistortedImg, camSpec.postImgSize)

    camDataDict[camId]["undistortedImg"] = undistortedImg
    # cv2.imshow(f"undistort_{camId}", undistortedImg)
    cv2.imwrite(f"undistort_{camId}.jpg", undistortedImg)

### 全景圖拼接
for bridViewId in bridViewDict.keys():
    birdViewImgList = list()
    targetSize = bridViewDict[bridViewId]["targetSize"]
    bridViewDataDict = bridViewDict[bridViewId]["dataDict"]
    overlapDictList = bridViewDataDict["overlapDictList"]
    ### 建立 overlapDictDict
    overlapNum = len(overlapDictList)
    overlapDictDict = dict()
    for i in range(overlapNum):
        overlapDictDict[str(i)] = overlapDictList[i]

    ### NOTE: 主要攝影機平視校正並建立世界坐標系
    ### 將主要攝影機, 建立在世界座標
    mainCamId, mianSrcPts = bridViewDataDict["mainCamId"], bridViewDataDict["mianSrcPts"]

    ### 準備透視變換後的目標點
    boardWidth = int(math.sqrt((mianSrcPts[1][0] - mianSrcPts[0][0]) ** 2 + (mianSrcPts[1][1] - mianSrcPts[0][1]) ** 2))
    boardHeight = int(
        math.sqrt((mianSrcPts[2][0] - mianSrcPts[1][0]) ** 2 + (mianSrcPts[2][1] - mianSrcPts[1][1]) ** 2)
    )

    ### 移動棋盤格左上角的座標, 避免校正後圖片被裁切
    undistortedImg = camDataDict[mainCamId]["undistortedImg"]
    width, height = undistortedImg.shape[:2][::-1]
    size = max(width, height)
    origin = tuple((mianSrcPts[0][0] + size // 2, mianSrcPts[0][1] + size // 2))

    ### 維持棋盤格在原畫面中的大小
    worldPts = [
        [origin[0], origin[1]],
        [origin[0] + boardWidth, origin[1]],
        [origin[0] + boardWidth, origin[1] + boardHeight],
        [origin[0], origin[1] + boardHeight],
    ]

    ### 透視變換
    matrix = PerspectiveTransform.solve_matrix(srcPtsList=mianSrcPts, targetPtsList=worldPts)
    perspectiveImg = PerspectiveTransform.img_transfer(undistortedImg, matrix, targetSize)
    birdViewImgList.append(perspectiveImg)
    ### 儲存透視變換矩陣
    np.save(f"perspective-bridView_{bridViewId}-mainCamMtxPath.npy", matrix)

    ### 更新與 mainCam 有關的其他 targetPts
    for j in range(overlapNum):
        overlapDict = overlapDictDict[str(j)]
        otherTargetCamId = overlapDict["targetCamId"]

        if str(otherTargetCamId) == mainCamId:
            overlapDictDict[str(j)]["targetPts"] = worldPts

    ### 依序拼接其他重疊視野
    for i in range(overlapNum):
        overlapDict = overlapDictDict[str(i)]
        srcCamId, srcPts = overlapDict["srcCamId"], overlapDict["srcPts"]
        targetCamId, targetPts = overlapDict["targetCamId"], overlapDict["targetPts"]
        undistortedImg = camDataDict[srcCamId]["undistortedImg"]
        matrix = PerspectiveTransform.solve_matrix(srcPtsList=srcPts, targetPtsList=targetPts)
        perspectiveImg = PerspectiveTransform.img_transfer(undistortedImg, matrix, targetSize)
        birdViewImgList.append(perspectiveImg)
        ### 儲存透視變換矩陣
        np.save(f"perspective-bridView_{bridViewId}-overlap_{(i+1)}.npy", matrix)

        ### 更新與該攝影機有關的 targetPts
        for j in range(1, overlapNum):
            overlapDict = overlapDictDict[str(j)]
            otherTargetCamId = overlapDict["targetCamId"]
            if str(otherTargetCamId) == srcCamId:
                ### 透視變換後新的標定點
                newTargetPtList = PerspectiveTransform.point_transfer(targetPts, matrix)
                overlapDictDict[str(j)]["targetPts"] = newTargetPtList

    ### 合併有重疊視野的拼接圖
    for i, birdViewImg in enumerate(birdViewImgList):
        if i == 0:
            mergeBirdViewImg = birdViewImg
        else:
            mergeBirdViewImg = cv2.addWeighted(src1=mergeBirdViewImg, alpha=0.5, src2=birdViewImg, beta=0.5, gamma=0)
    bridViewDict[bridViewId]["mergeBirdViewImg"] = mergeBirdViewImg

    cv2.imshow(
        f"bridView_{bridViewId}",
        cv2.resize(mergeBirdViewImg, (mergeBirdViewImg.shape[1] // 3, mergeBirdViewImg.shape[0] // 3)),
    )
    cv2.imwrite(f"bridView_{bridViewId}.jpg", mergeBirdViewImg)

### 平面圖
layoutBlockDict = layoutDict["blockDict"]
for blockId, block in layoutBlockDict.items():
    bridViewId = block["bridViewId"]
    srcPts, targetPts = block["srcPts"], block["targetPts"]
    layoutRegion = block["layoutRegion"]

    img = bridViewDict[bridViewId]["mergeBirdViewImg"]

    ### 仿射變換
    matrix = AffineTransform.solve_matrix(srcPts, targetPts)
    affineImg = AffineTransform.img_transfer(img, matrix, targetImgSize=layoutImg.shape[:2][::-1])
    layoutImg[layoutRegion[0][1] : layoutRegion[1][1], layoutRegion[0][0] : layoutRegion[1][0]] = affineImg[
        layoutRegion[0][1] : layoutRegion[1][1], layoutRegion[0][0] : layoutRegion[1][0]
    ]
    ### 儲存仿射變換矩陣
    np.save(f"affine-block_{blockId}.npy", matrix)

cv2.imshow("layoutImg", layoutImg)
cv2.imwrite("layoutImg.jpg", layoutImg)
cv2.waitKey(0)
