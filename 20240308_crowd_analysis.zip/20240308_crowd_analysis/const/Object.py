from enum import Enum, auto


class CamData(object):
    camId = None
    status = False
    loc = None
    frame = None
    detectImg = None
    detectPoint = list()
    corrImg = None
    corrPoint = list()


class LayoutData(object):
    blockId = None
    camId = None
    matrix = None
    region = None
    affineImg = None
    affinePoint = None


class DetectResult(object):
    center = None
    foot = None
    bboxWidth = None
    bboxHeight = None
    angle = None
    conf = None


class ServerEvent(Enum):
    CHANGE_SCHEDULE = auto()
