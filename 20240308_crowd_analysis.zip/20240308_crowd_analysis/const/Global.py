from enum import Enum
import queue


class PROJECT(Enum):
    SiDaDun = "SiDaDun"  # 對應到設定檔的資料夾名稱
    ATC = "ATC"
    AnneProject = "AnneProject"
    TC2 = "TC2"
    Showroom = "Showroom"


class GLOBAL_OBJECT(object):
    serverEventQue = queue.Queue()
    resetTrigger = False


WEEK_DICT = {
    "mon": 0,
    "tue": 1,
    "wed": 2,
    "thu": 3,
    "fri": 4,
    "sat": 5,
    "sun": 6,
}
