import os
import sys
from enum import Enum, auto

currentPath = os.path.abspath(__file__)
modulePath = os.path.dirname(currentPath)
sys.path.append(os.path.dirname(modulePath))

from packages.Calibration import CamType


class DistortMethod(Enum):
    LATITUDE_LONGITUDE = auto()  # 經緯度校正法
    CHESSBOARD = auto()  # 張氏棋盤格校正法


class Cam_Spec:
    def __init__(self, name, type, orgSize, preProc=False, postProc=False):
        self.name = name
        self.type = type
        self.orgSize = orgSize  # 原圖 (width, height)
        self.preProc = preProc  # 畸變校正前處理
        self.postProc = postProc  # 畸變校正後處理

    def pre_process_param(self, centerX, centerY, radius):
        self.centerX = centerX
        self.centerY = centerY
        self.radius = radius

    def distort_param(self, method, **Args):
        argsDict = Args
        self.method = method
        if method == DistortMethod.LATITUDE_LONGITUDE:
            assert "mapXPath" in argsDict.keys()
            assert "mapYPath" in argsDict.keys()
            self.mapXPath = argsDict["mapXPath"]
            self.mapYPath = argsDict["mapYPath"]

        elif method == DistortMethod.CHESSBOARD:
            assert "inParamsPath" in argsDict.keys()
            assert "alpha" in argsDict.keys()
            self.inParamsPath = argsDict["inParamsPath"]
            self.alpha = argsDict["alpha"]

    def post_process_parm(self, imgSize):
        self.postImgSize = imgSize


### ACTi E96
E96 = Cam_Spec(
    name="ACTi_E96",
    type=CamType.FISHEYE,
    orgSize=(2048, 1536),
    preProc=True,
    postProc=True,
)
E96.pre_process_param(
    centerX=1070,
    centerY=1536 // 2,
    radius=1536 // 2,
)
E96.distort_param(
    DistortMethod.CHESSBOARD, inParamsPath=r"crowd_analysis/data/camera_param/ACTi_E96/inParams.json", alpha=0.8
)
E96.post_process_parm((2160, 2160))

### ACTi E96 舊版程式使用 (ATC, TC2 商場)
E96_old_version = Cam_Spec(
    name="ACTi_E96_old_version",
    type=CamType.FISHEYE,
    orgSize=(2048, 1536),
    preProc=True,
    postProc=True,
)
E96_old_version.pre_process_param(
    centerX=2048 // 2,
    centerY=1536 // 2,
    radius=1536 // 2,
)
E96_old_version.distort_param(
    DistortMethod.LATITUDE_LONGITUDE,
    mapXPath=r"crowd_analysis/data/ATC/matrix/distorition/distortion_corr_matix_mapx.npy",
    mapYPath=r"crowd_analysis/data/ATC/matrix/distorition/distortion_corr_matix_mapy.npy",
)
E96_old_version.post_process_parm((2160, 2160))

### ACTi B511A
B511A = Cam_Spec(
    name="ACTi_B511A",
    type=CamType.FISHEYE,
    orgSize=(4000, 3000),
    preProc=True,
    postProc=True,
)
B511A.pre_process_param(
    centerX=4000 // 2,
    centerY=3000 // 2,
    radius=3000 // 2,
)
B511A.distort_param(
    DistortMethod.CHESSBOARD, inParamsPath=r"crowd_analysis/data/camera_param/ACTi_B511A/inParams.json", alpha=0.8
)
B511A.post_process_parm((2160, 2160))

### 昇銳 HS-D063TR
D063TR = Cam_Spec(
    name="D063TR",
    type=CamType.FISHEYE,
    orgSize=(2160, 2160),
    preProc=False,
    postProc=True,
)
D063TR.distort_param(
    DistortMethod.CHESSBOARD, inParamsPath=r"crowd_analysis/data/camera_param/D063TR/inParams.json", alpha=0.8
)
D063TR.post_process_parm((2160, 2160))

### 昇銳 HS-D063TR 舊版程式使用 (SiDaDun)
D063TR_old_version = Cam_Spec(
    name="D063TR_old_version",
    type=CamType.FISHEYE,
    orgSize=(2160, 2160),
    preProc=False,
    postProc=True,
)
D063TR_old_version.distort_param(
    DistortMethod.LATITUDE_LONGITUDE,
    mapXPath=r"crowd_analysis/data/SiDaDun/matrix/distorition/distortion_corr_matix_mapx.npy",
    mapYPath=r"crowd_analysis/data/SiDaDun/matrix/distorition/distortion_corr_matix_mapy.npy",
)
D063TR_old_version.post_process_parm((2160, 2160))

CAM_SPEC_DICT = {
    "ACTi_E96": E96,
    "ACTi_E96_old_version": E96_old_version,
    "ACTi_B511A": B511A,
    "D063TR": D063TR,
    "D063TR_old_version": D063TR_old_version,
}
