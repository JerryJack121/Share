import sys
import os

currentPath = os.path.abspath(__file__)
modulePath = os.path.dirname(currentPath)
sys.path.append(os.path.dirname(modulePath))

from crowd_analysis.core.core import run as run_crowd_analysis
from crowd_analysis.const.Global import PROJECT


project = PROJECT.TC2
print(f"Running Crowd Analysis for project '{project.name}'")
run_crowd_analysis(project)
