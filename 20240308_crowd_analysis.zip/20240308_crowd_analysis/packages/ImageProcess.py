from PIL import Image
import cv2
import os
import numpy as np


class ImageProcess:
    @staticmethod
    def cv2pil(imgCV):
        imgCV_RGB = cv2.cvtColor(imgCV, cv2.COLOR_BGR2RGB)
        imgPIL = Image.fromarray(imgCV_RGB)
        return imgPIL

    @staticmethod
    def get_fisheye(img, center=None, radius=None):
        """根據半徑裁減圖片
        Args:
            img (np.array): 原始圖片
            center (tuple, optional): (centerX, centerY). Defaults to None.
            radius (int, optional): 半徑. Defaults to None.

        Returns:
            np.array: 結果圖片
        """
        width, height = img.shape[1], img.shape[0]
        if center is None:
            centerX, centerY = width // 2, height // 2
        else:
            centerX, centerY = center
            centerX, centerY = int(centerX), int(centerY)

        if radius is None:
            shortLen = min(width, height)  # 取短邊當直徑
            radius = shortLen // 2

        resImg = img[
            centerY - radius : centerY + radius,
            centerX - radius : centerX + radius,
        ]
        return resImg


class Plot:
    @staticmethod
    def plot_disconnected_img(imgSize, fontSize=120):
        font = "No Signal!"
        w, h = imgSize
        scaleFactor = fontSize / 30  # 假定基本大小為 30，可以根據需要調整此值
        text_size, _ = cv2.getTextSize(font, cv2.FONT_HERSHEY_SIMPLEX, scaleFactor, 2)
        textLocation = ((w - text_size[0]) // 2, (h + text_size[1]) // 2)
        disconnectedImg = np.zeros((h, w, 3), dtype="uint8")
        ### 計算縮放因子
        disconnectedImg = cv2.putText(
            disconnectedImg, font, textLocation, cv2.FONT_HERSHEY_SIMPLEX, scaleFactor, (0, 0, 255), 2
        )
        return disconnectedImg

    @staticmethod
    def plot_points_on_img(img, pointList, pointSize, color=(0, 0, 255)):
        resImg = img.copy()
        for point in pointList:
            cv2.circle(resImg, point, pointSize, color, -1)
        return resImg

    @staticmethod
    def plot_mask(img, maskPoints):
        """繪製黑色多邊形遮罩

        Args:
            img (np.array): 原始圖片
            maskPoints (list): 遮罩的各角座標

        Returns:
            np.array: 結果圖片
        """
        resImg = img.copy()
        cv2.fillConvexPoly(resImg, np.array(maskPoints, dtype=np.int32), 0)
        return resImg


if __name__ == "__main__":
    inputFolder = r"\\yjchou\Share\WYLee\input\0707_ATC_data"
    outputFolder = r"\\yjchou\Share\WYLee\output"

    imgFilenameList = os.listdir(inputFolder)
    for imgFilename in imgFilenameList:
        imgFilePath = os.path.join(inputFolder, imgFilename)
        img = cv2.imread(imgFilePath)
        resImg = ImageProcess.get_fisheye(img)
        cv2.imwrite(os.path.join(outputFolder, imgFilename), resImg)
