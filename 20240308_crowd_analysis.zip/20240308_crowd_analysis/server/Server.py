import cv2
from flask import Flask, Response, jsonify, request
from flask_cors import CORS
import threading
import logging
import sys
import os

currentPath = os.path.abspath(__file__)
modulePath = os.path.dirname(currentPath)
sys.path.append(os.path.dirname(modulePath))
from const.Global import GLOBAL_OBJECT
from const.Object import ServerEvent


class Server:
    def __init__(self, host, port):
        self.statusDict = dict()
        self.streamImg = None

        ### 初始化 Flask 應用程式
        self.app = Flask(__name__)
        CORS(self.app)  # 允許跨域連線

        ### 隱藏 Flask 的呼叫紀錄
        log = logging.getLogger("werkzeug")
        log.setLevel(logging.WARNING)

        ### 註冊路由
        self.app.add_url_rule("/stream", endpoint="stream", view_func=self.stream, methods=["GET"])
        self.app.add_url_rule("/status", endpoint="status", view_func=self.status, methods=["GET"])
        self.app.add_url_rule("/schedule", view_func=self.schedule, methods=["POST"])

        ### 啟動伺服器執行序
        self.serverThread = threading.Thread(target=self.start_server, args=(host, port))
        self.serverThread.start()

    def start_server(self, host, port):
        """啟動伺服器

        Args:
            host (str): 本機 ip
            port (int): port
        """
        self.app.run(host, port, debug=False, use_reloader=False)

    ##############################################
    ###                 API
    ##############################################
    def stream(self):
        """攝影機串流"""
        return Response(
            self.gen_frames(),
            content_type="multipart/x-mixed-replace; boundary=frame",
        )

    def gen_frames(self):
        """生成串流圖片"""
        while True:
            if self.streamImg is not None:
                encodedImage = Server.encoder(self.streamImg)
                yield encodedImage

    def status(self):
        """設備狀態監測 API"""
        return jsonify(self.statusDict)

    def schedule(self):
        body = request.get_json()
        try:
            scheduleData = {
                "aiSwitch": body["aiSwitch"],
                "weeks": body["weeks"],
                "scheduleOnTime": body["scheduleOnTime"],
                "scheduleOffTime": body["scheduleOffTime"],
            }

            GLOBAL_OBJECT.serverEventQue.put(
                (
                    ServerEvent.CHANGE_SCHEDULE,
                    scheduleData,
                )
            )
            print("收到來自 AI Server 的排程設定")
        except Exception as e:
            print(f"Error: {e}")

        return Response(status=200)

    ##############################################
    ###               更新系統狀態
    ##############################################
    def update_stream(self, stramImg):
        self.streamImg = stramImg

    def update_status(self, camDataDict):
        for camId in camDataDict.keys():
            status = camDataDict[camId].status
            self.statusDict[camId] = status

    ##############################################
    ###               function
    ##############################################
    @staticmethod
    def encoder(img):
        """圖像編碼

        Args:
            img (np.array): 串流圖片

        Returns:
            str: 編碼後的圖片
        """
        ret, buffer = cv2.imencode(".jpg", img)
        byteImg = buffer.tobytes()
        encodedImage = (
            b"--frame\r\n" b"Content-Type: image/jpeg\r\n\r\n" + byteImg + b"\r\n"
        )  # Concatenates frame bytes
        return encodedImage


if __name__ == "__main__":
    server = Server(host="0.0.0.0", port="4001")
