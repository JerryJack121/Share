import requests
import threading


class Api:
    def __init__(self, aiId):
        self.aiId = aiId

    # def init_api_for_webServer(self, serverIp, port):
    #     self.webServerIP, self.webServerPort = serverIp, port

    def init_api_for_aiServer(self, serverIp, port):
        self.aiServerIP, self.aiServerPort = serverIp, port

    def update_pepleCnt(self, peopleCntResultDict):
        url = f"http://{self.aiServerIP}:{self.aiServerPort}/peopleCnt"

        trigger, body = False, dict()
        for key, resultDict in peopleCntResultDict.items():
            body[key] = dict()
            for venueId, aiResult in resultDict.items():
                inNum, outNum, dayInNum = aiResult["inNum"], aiResult["outNum"], aiResult["dayInNum"]
                if inNum != 0 or outNum != 0 or dayInNum != 0:
                    trigger = True
                    body[key][venueId] = {
                        "inNum": aiResult["inNum"],
                        "outNum": aiResult["outNum"],
                        "dayInNum": aiResult["dayInNum"],
                    }

        ### 人數有變動時才呼叫 API
        if trigger:
            postThread = threading.Thread(target=self.send_post_request, args=(url, None, body))
            postThread.start()

    def update_heatmap(self, heatmapData):
        url = f"http://{self.aiServerIP}:{self.aiServerPort}/heatmap"
        body = {"aiId": self.aiId, "heatmapData": heatmapData}
        postThread = threading.Thread(target=self.send_post_request, args=(url, None, body))
        postThread.start()

    def update_fence(self, fenceResDict):
        url = f"http://{self.aiServerIP}:{self.aiServerPort}/fence"

        body = fenceResDict
        body = {"aiId": self.aiId, "fenceData": fenceResDict}
        postThread = threading.Thread(target=self.send_post_request, args=(url, None, body))
        postThread.start()

    ### 向 AI Server 請求排程設定
    def get_schedule(self):
        url = f"http://{self.aiServerIP}:{self.aiServerPort}/schedule"

        try:
            response = requests.get(url)
            data = response.json()
            scheduleDict = {
                "aiSwitch": data["aiSwitch"],
                "weeks": data["weeks"],
                "scheduleOnTime": data["scheduleOnTime"],
                "scheduleOffTime": data["scheduleOffTime"],
            }
            return True, scheduleDict
        except Exception as e:
            print(e)
            return False, e

    def send_post_request(self, url, data=None, json=None, headers=None, cookies=None):
        response = None
        try:
            response = requests.post(url, data=data, json=json, headers=headers, cookies=cookies)
            if response.status_code != 200:
                raise RuntimeError(response.status_code)
        except Exception as e:
            print(f"{url} error: {e}")

        return response
