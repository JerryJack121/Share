import datetime
import time
import os
import cv2
import logging
import numpy as np
import sys
import datetime
import yaml
import json

currentPath = os.path.abspath(__file__)
modulePath = os.path.dirname(currentPath)
sys.path.append(os.path.dirname(modulePath))

from const.Global import GLOBAL_OBJECT, WEEK_DICT
from const.Object import ServerEvent
from const.Specification import DistortMethod
from const.Object import LayoutData
from const.Object import DetectResult
from const.Specification import CAM_SPEC_DICT
from packages.ImageProcess import ImageProcess, Plot
from packages.Rapid import Detector
from packages.Logger import Logger
from packages.ScheduleManger import RestartManager
from utils.Config import Config
from utils.CamCapture import CamCapture
from utils.calibrate import (
    img_distortion_corr,
    point_distortion_corr,
    img_affin_trans,
    point_affin_trans,
)
from utils.PeopleCount import PeopleCount
from utils.Layout import Layout
from utils.Mask import Mask
from server.Server import Server
from server.Api import Api
from utils.Fence import Fence


def run(project):
    ##############################################
    ###            初始化
    ##############################################
    t1 = time.time()
    runDate = datetime.date.today()  # 記錄系統啟動日期

    ### 載入設定檔
    cfgFolder = os.path.join(os.path.join(os.path.dirname(modulePath), "./data"), project.value)
    config = Config(cfgFolder)

    ### TODO: yjchou 2023/12/01 完成各模組 log 紀錄
    ### 建立 Logger
    if config.mode.debugMode:
        level = logging.DEBUG
    else:
        level = logging.INFO
    logger = Logger("main", level=level)
    # camLogger = Logger("main.cam", level=level)
    # webLogger = Logger("main.web", level=level)
    peopleCountLogger = Logger("main.peopleCount", level=level)

    ### Create handler
    logger.create_stream_handler()
    # logger.create_file_handler(
    #     config.log.logFolderPath,
    #     config.log.logfileName,
    #     config.log.maxMB,
    #     config.log.backupCount,
    # )

    ### TODO: yjchou 2023/12/06 Show information
    # if config.system.debugMode:
    #     logger.info("System start running with debugMode")
    # else:
    #     logger.info("System start running without debugMode")
    # if config.cam.videoMode:
    #     logger.warning("Video mode is ON. This is only for video testing!")
    # if not config.switch.AISwitch:
    #     logger.warning("人流辨識功能未開啟")
    # logger.info("Initial starting...")

    ### 設定 GPU 使用編號
    if config.model.device.lower() != "cpu":
        os.environ["CUDA_VISIBLE_DEVICES"] = config.model.device
        useCuda = True
        logger.info(f"Using GPU: {config.model.device}")
    else:
        os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
        logger.info("Using CPU")

    ### 初始化每日重啟功能, 需搭配第三方工具 "RestartOnCreashed" 使用
    restartManager = RestartManager()
    restartManager.create_daily_sechedule(config.restartTime)

    ### 攝影機初始化
    camCapture = CamCapture(
        config.camDict,
        config.model.imgSize,
        config.mode.videoMode,
    )

    ### 畸變校正參數初始化
    distortParmDict = dict()
    for camId in config.camDict.keys():
        distortParmDict[camId] = dict()
        camSpec = config.camDict[camId]["camSpec"]
        camSpec = CAM_SPEC_DICT[camSpec]

        method = camSpec.method
        distortParmDict[camId]["method"] = method
        if method == DistortMethod.LATITUDE_LONGITUDE:
            distortParmDict[camId]["mapX"] = np.load(camSpec.mapXPath)
            distortParmDict[camId]["mapY"] = np.load(camSpec.mapYPath)
        elif method == DistortMethod.CHESSBOARD:
            distortParmDict[camId]["alpha"] = np.array(camSpec.alpha)
            with open(camSpec.inParamsPath, "r") as file:
                inParamsDict = json.load(file)
                distortParmDict[camId]["mtx"] = np.array(inParamsDict["mtx"])
                distortParmDict[camId]["dist"] = np.array(inParamsDict["dist"])
                file.close()

    ### RAPiD 初始化
    detector = Detector(model_name="rapid", weights_path=config.model.weightPath, use_cuda=useCuda)

    mask = Mask(config.camDict, config.model.imgSize, config.mask.maskList, config.visualize.mask)

    ### 客流量計數初始化
    customerFlow = PeopleCount(
        config.customerFlow,
        peopleCountLogger,
        visualize=config.visualize.peopleCnt,
    )

    ### 進店人數計數初始化
    storeVisitor = PeopleCount(
        config.storeVisitor,
        peopleCountLogger,
        visualize=config.visualize.storeVisitor,
    )

    ### TODO: yjchou 2023/12/01
    ### 站點人數計數 & 停留時間初始化
    fence = Fence(config.fence.fenceDict)

    ### 平面圖初始化
    layoutdataDict = dict()
    for blockId, block in config.layout.blockDict.items():
        camId = block["camId"]
        region = config.layout.blockDict[blockId]["region"]
        matrixPath = config.layout.blockDict[blockId]["matrixPath"]
        ### 只載入與這台 AI 主機相關的矩陣
        if str(camId) in config.camDict.keys():
            layoutdata = LayoutData()
            layoutdata.blockId = int(blockId)
            layoutdata.camId = camId
            layoutdata.region = region
            if os.path.isfile(matrixPath):
                layoutdata.matrix = np.load(matrixPath)
            else:
                exception = f"找不到 Affine Transform 矩陣: {matrixPath}"
                raise RuntimeError(exception)
            layoutdataDict[blockId] = layoutdata
    layout = Layout(config.layout.imgPath, config.layout.blockDict, config.visualize.heatmap)

    ### Server, API 初始化
    server = Server(config.host, config.port)
    api = Api(config.aiId)
    api.init_api_for_aiServer(config.aiServer.serverIp, config.aiServer.port)

    ### 排程設定初始化
    success, scheduleDict = api.get_schedule()
    if success:
        ### 如果排程設定修改時儲存排程
        if check_schedule_change(
            config.schedule,
            scheduleDict,
        ):
            (
                config.schedule.aiSwitch,
                config.schedule.weeks,
                config.schedule.scheduleOnTime,
                config.schedule.scheduleOffTime,
            ) = (
                scheduleDict["aiSwitch"],
                scheduleDict["weeks"],
                scheduleDict["scheduleOnTime"],
                scheduleDict["scheduleOffTime"],
            )
            ### 儲存排程設定儲存排程設定
            cfgFilePath = os.path.join(cfgFolder, "config/schedule.yml")
            save_schedule_to_yaml(config.schedule, cfgFilePath)

    ##############################################
    ###            主流程
    ##############################################
    while True:
        ##############################################
        ###         跨日重置人數
        ##############################################
        today = datetime.date.today()
        if today != runDate:
            customerFlow.reset()
            storeVisitor.reset()
            runDate = today

        ##############################################
        ###           處理 Server 事件
        ##############################################
        if not GLOBAL_OBJECT.serverEventQue.empty():
            event, msg = GLOBAL_OBJECT.serverEventQue.get()
            if event == ServerEvent.CHANGE_SCHEDULE:
                scheduleDict = msg
                ### 如果排程設定修改時儲存排程
                if check_schedule_change(
                    config.schedule,
                    scheduleDict,
                ):
                    (
                        config.schedule.aiSwitch,
                        config.schedule.weeks,
                        config.schedule.scheduleOnTime,
                        config.schedule.scheduleOffTime,
                    ) = (
                        scheduleDict["aiSwitch"],
                        scheduleDict["weeks"],
                        scheduleDict["scheduleOnTime"],
                        scheduleDict["scheduleOffTime"],
                    )
                    ### 儲存排程設定儲存排程設定
                    cfgFilePath = os.path.join(cfgFolder, "config/schedule.yml")
                    save_schedule_to_yaml(config.schedule, cfgFilePath)

        ##############################################
        ###                辨識排程
        ##############################################
        if not config.schedule.aiSwitch:
            print("辨識功能關閉")
            time.sleep(10)
            continue

        ### 確認排程
        scheduleWeeks = list()
        for week in config.schedule.weeks.split(","):
            scheduleWeeks.append(WEEK_DICT[week])
        scheduleOnTime, scheduleOffTime = config.schedule.scheduleOnTime, config.schedule.scheduleOffTime
        if scheduleOnTime is not None and scheduleOffTime is not None:
            ### 判斷星期
            today = datetime.date.today()
            weekToday = today.weekday()
            if weekToday in scheduleWeeks:
                ### 判斷時間
                now = datetime.datetime.now()
                todayFormat = datetime.datetime.strftime(today, "%Y_%m_%d")
                onTime = datetime.datetime.strptime(todayFormat + "_" + scheduleOnTime, "%Y_%m_%d_%H:%M")
                offTime = datetime.datetime.strptime(todayFormat + "_" + scheduleOffTime, "%Y_%m_%d_%H:%M")
                if now < onTime or now > offTime:
                    print("非排程時間")
                    time.sleep(10)
                    continue
            else:
                print("非排程時間")
                time.sleep(10)
                continue

        ##############################################
        ###             取得攝影機畫面
        ##############################################
        combineImg, camDataDict = camCapture.get_combine_frame()
        camNum = len(config.camDict.keys())

        ##############################################
        ###            RAPiD 模型檢測
        ##############################################
        ### RAPiD inference
        inputSize = combineImg.shape[0]
        pilImg = ImageProcess.cv2pil(combineImg)
        detections = detector.detect_one(
            pil_img=pilImg, input_size=inputSize, conf_thres=config.model.conf, return_img=False
        )

        ### 計算腳座標
        resultList = list()
        for bb in detections:
            x, y, w, h, a, conf = bb
            imgWidth, imgHeight = combineImg.shape[1], combineImg.shape[0]
            footPoint = detector.get_foot(x, y, w, h, a, imgWidth, imgHeight, mode=1 if camNum == 1 else 2)
            resultCls = DetectResult()
            (
                resultCls.center,
                resultCls.bboxWidth,
                resultCls.bboxHeight,
                resultCls.angle,
                resultCls.conf,
                resultCls.foot,
            ) = (tuple((x, y)), w, h, a, conf, tuple(footPoint))
            resultList.append(resultCls)

        ### 畫辨識結果
        footPointsList = [resultCls.foot for resultCls in resultList]
        detectImg = Plot.plot_points_on_img(combineImg, footPointsList, pointSize=1, color=(0, 255, 0))

        ##############################################
        ###                 後處理
        ##############################################
        ### 濾除遮罩內的預測點
        detectImg, footPointsList = mask.noise_filter(detectImg, footPointsList)

        ### FIXME: 舊版程式的畸變校正綁定在 2160*2160 尺寸下, 改為同步魚眼尺寸
        ### 校正資料準備
        camWidth, camHeight = 2160, 2160
        if camNum == 1:
            ### 尺寸縮放
            detectImg = cv2.resize(detectImg, (camWidth, camHeight))
            ratioX, ratioY = detectImg.shape[1] / combineImg.shape[1], detectImg.shape[0] / combineImg.shape[0]
            tmpList = footPointsList
            footPointsList = list()
            for footPoint in tmpList:
                x, y = footPoint
                footPointsList.append(tuple((int(x * ratioX), int(y * ratioY))))

            camId = next(iter(camDataDict.keys()))
            camDataDict[camId].detectImg = detectImg
            camDataDict[camId].detectPoint = footPointsList

            ### 魚眼畸變校正
            if (
                config.visualize.fence
                or config.visualize.storeVisitor
                or config.visualize.heatmap
                or config.visualize.peopleCnt
            ):
                camDataDict[camId].corrImg = img_distortion_corr(camDataDict[camId].detectImg, distortParmDict[camId])
            camDataDict[camId].corrPoint = point_distortion_corr(
                camDataDict[camId].detectPoint, distortParmDict[camId], radius=camWidth // 2
            )

        elif 1 < camNum <= 4:
            ### 尺寸縮放
            detectImg = cv2.resize(detectImg, (camWidth * 2, camHeight * 2))
            ratioX, ratioY = detectImg.shape[1] / combineImg.shape[1], detectImg.shape[0] / combineImg.shape[0]
            tmpList = footPointsList
            footPointsList = list()
            for footPoint in tmpList:
                x, y = footPoint
                footPointsList.append(tuple((int(x * ratioX), int(y * ratioY))))

            for camId in camDataDict.keys():
                ###  4合1大圖切分各攝影機
                loc = camDataDict[camId].loc
                camDataDict[camId].detectImg = detectImg[
                    camHeight * (loc[0] - 1) : camHeight * (loc[0]),
                    camWidth * (loc[1] - 1) : camWidth * (loc[1]),
                ]

                camDataDict[camId].detectPoint = list()
                for point in footPointsList:
                    x, y = point

                    if (
                        x >= camWidth * (loc[1] - 1)
                        and x < camWidth * (loc[1])
                        and y >= camHeight * (loc[0] - 1)
                        and y < camHeight * (loc[0])
                    ):
                        x -= camWidth * (loc[1] - 1)
                        y -= camHeight * (loc[0] - 1)
                        camDataDict[camId].detectPoint.append((x, y))

                ### 魚眼畸變校正
                if (
                    config.visualize.fence
                    or config.visualize.storeVisitor
                    or config.visualize.heatmap
                    or config.visualize.peopleCnt
                ):
                    camDataDict[camId].corrImg = img_distortion_corr(
                        camDataDict[camId].detectImg, distortParmDict[camId]
                    )
                camDataDict[camId].corrPoint = point_distortion_corr(
                    camDataDict[camId].detectPoint, distortParmDict[camId], radius=camWidth // 2
                )

        ### 仿射變換
        for blockId, layoutdata in layoutdataDict.items():
            camId = layoutdata.camId
            region = layoutdata.region
            corrImg = camDataDict[str(camId)].corrImg
            corrPoint = camDataDict[str(camId)].corrPoint
            affinMatrix = layoutdata.matrix
            if config.visualize.heatmap:
                layoutdataDict[blockId].affineImg = img_affin_trans(corrImg, region, affinMatrix)
            layoutdataDict[blockId].affinePoint = point_affin_trans(corrPoint, region, affinMatrix)

        ##############################################
        ###         客流量計算 / 進店人數計算
        ##############################################
        customerFlowResDict = customerFlow.count_all_venue(camDataDict)
        storeVisitorResDict = storeVisitor.count_all_venue(camDataDict)

        ### XXX: For demo 影片重播後重置人數
        if GLOBAL_OBJECT.resetTrigger:
            for venueId in customerFlowResDict.keys():
                customerFlowResDict[venueId]["outNum"] = customerFlowResDict[venueId]["cntNow"]
                storeVisitorResDict[venueId]["outNum"] = storeVisitorResDict[venueId]["cntNow"]
                GLOBAL_OBJECT.resetTrigger = False

        ##############################################
        ###         魚眼座標投射至平面圖
        ##############################################
        layoutPointList = layout.point_to_layout(layoutdataDict)

        ##############################################
        ###            站點人數計數 & 停留時間
        ##############################################
        ### TODO: yjchou 2023/12/06 尚未完成
        fence.cnt(camDataDict)
        fenceResDict = fence.cnt()

        ##############################################
        ###            Server 服務
        ##############################################
        ### 更新攝影機狀態
        server.update_status(camDataDict)
        ### 影像串流
        server.update_stream(detectImg)

        ##############################################
        ###             API 串接
        ##############################################
        api.update_pepleCnt({"customerFlow": customerFlowResDict, "storeVisitor": storeVisitorResDict})
        api.update_heatmap(layoutPointList)
        api.update_fence(fenceResDict)

        ##############################################
        ###       Terminal 輸出 & Visualize
        ##############################################
        print("=" * 50)
        print("客流量:")
        print(customerFlowResDict)
        print("進店人數:")
        print(storeVisitorResDict)
        print("=" * 50)

        if config.mode.debugMode:
            cv2.namedWindow("detectImg", cv2.WINDOW_NORMAL)
            cv2.resizeWindow("detectImg", 800, 800)
            cv2.imshow("detectImg", detectImg)

        if config.visualize.heatmap:
            layoutImg = layout.img_to_layout(layoutdataDict)
            layoutImg = Plot.plot_points_on_img(layoutImg, layoutPointList, pointSize=5, color=(0, 0, 255))
            cv2.imshow("layoutImg", layoutImg)

        if config.visualize.fence:
            for fenceId, fenceData in config.fence.fenceDict.items():
                areaList = fenceData["dataList"]
                for area in areaList:
                    camId = area["camId"]
                    areaData = area["data"]
                    camCorrImg = camDataDict[str(camId)].corrImg
                    cv2.rectangle(camCorrImg, tuple(areaData[0]), tuple(areaData[1]), (255, 0, 0), 2)
                    cv2.putText(
                        camCorrImg, f"fence_{fenceId}", tuple(areaData[0]), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2
                    )

            for camId, camData in camDataDict.items():
                camCorrImg = camData.corrImg
                windowName = f"cam_{camId}"
                cv2.namedWindow(windowName, cv2.WINDOW_NORMAL)
                cv2.resizeWindow(windowName, 1000, 1000)
                cv2.imshow(windowName, camCorrImg)

        if config.mode.debugMode or config.visualize.heatmap or config.visualize.fence:
            cv2.waitKey(1)


def check_schedule_change(configSchedule, ScheduleNow):
    if (
        configSchedule.aiSwitch != ScheduleNow["aiSwitch"]
        or configSchedule.weeks != ScheduleNow["weeks"]
        or configSchedule.scheduleOnTime != ScheduleNow["scheduleOnTime"]
        or configSchedule.scheduleOffTime != ScheduleNow["scheduleOffTime"]
    ):
        return True
    else:
        return False


def save_schedule_to_yaml(scheduleData, cfgFilePath):
    with open(cfgFilePath, "w") as file:
        data = {
            "aiSwitch": scheduleData.aiSwitch,
            "weeks": scheduleData.weeks,
            "scheduleOnTime": scheduleData.scheduleOnTime,
            "scheduleOffTime": scheduleData.scheduleOffTime,
        }
        yaml.dump(data, file, default_flow_style=False, allow_unicode=True)
