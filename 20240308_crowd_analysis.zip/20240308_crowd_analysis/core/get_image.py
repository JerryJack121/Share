import os
import cv2
import numpy as np
import sys

currentPath = os.path.abspath(__file__)
modulePath = os.path.dirname(currentPath)
sys.path.append(os.path.dirname(modulePath))

from const.Global import PROJECT
from utils.Config import GetImgConfig
from utils.CamCapture import CamCapture
from utils.calibrate import img_distortion_corr
from packages.ImageProcess import ImageProcess


def get_image(project, calibrateImg=False):
    ### 載入設定檔
    cfgFolder = os.path.join(os.path.join(os.path.dirname(modulePath), "./data"), project.value)
    config = GetImgConfig(cfgFolder)

    ### 攝影機初始化
    camCapture = CamCapture(config.camDict, 1024, True)

    ### 魚眼矯正矩陣初始化
    if calibrateImg:
        mapxList = np.load(config.calibrate.distortionCorrMapXPath)
        mapyList = np.load(config.calibrate.distortionCorrMapYPath)
        distortionCorrMatix = [mapxList, mapyList]

    ### 初始化資料夾
    orgFolder = "./img_tmp/org"
    calibrateFolder = "./img_tmp/calibrate"
    os.makedirs(orgFolder, exist_ok=True)
    os.makedirs(calibrateFolder, exist_ok=True)

    frameCnt = 0

    while frameCnt < 10:
        camDataDict = camCapture.get_org_frame()
        if len(camDataDict.keys()) == 0:
            continue

        for camId, frame in camDataDict.items():
            filePath = os.path.join(orgFolder, f"cam{camId}_{frameCnt}.jpg")
            cv2.imwrite(filePath, frame)

            if calibrateImg:
                frame = ImageProcess.get_fisheye(frame)
                frame = cv2.resize(frame, (2160, 2160))
                frame = img_distortion_corr(frame, distortionCorrMatix)
                filePath = os.path.join(calibrateFolder, f"cam{camId}_{frameCnt}.jpg")
                cv2.imwrite(filePath, frame)

        frameCnt += 1


if __name__ == "__main__":
    project = PROJECT.SiDaDun
    get_image(project, calibrateImg=True)
