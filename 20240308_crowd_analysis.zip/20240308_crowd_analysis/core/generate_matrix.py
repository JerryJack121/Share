import cv2
import numpy as np
import sys
import os

currentPath = os.path.abspath(__file__)
modulePath = os.path.dirname(currentPath)
sys.path.append(os.path.dirname(modulePath))

from const.Global import PROJECT
from utils.Config import GetMatrixConfig
from packages.Calibrate import DistortionCorrection, AffineTransform


##############################################
###             魚眼畸變校正
##############################################
def save_distortion_matrix(imgPath, matrixSavePath, matrixName, resultImgPath=None, visualize=True):
    """取得畸變校正(經緯度變換)矩陣 (相同尺寸的攝影機可共用轉換矩陣)

    Args:
        imgPath (str): 原圖檔案路徑
        matrixSavePath (str): 矩陣儲存資料夾路徑
        matrixName (str): 矩陣名稱
        resultImgPath (str, optional): 結果圖輸出檔案路徑. Defaults to None.
        visualize (bool, optional): 結果圖可視化. Defaults to True.
    """
    img = cv2.imread(imgPath)

    ### 經緯度校正
    finalMapx, finalMapy, resImg = DistortionCorrection.get_matrix(img, mode=3, visualize=visualize)

    ### save matrix
    os.makedirs(matrixSavePath, exist_ok=True)
    np.save(os.path.join(matrixSavePath, f"{matrixName}_mapx.npy"), finalMapx)
    np.save(os.path.join(matrixSavePath, f"{matrixName}_mapy.npy"), finalMapy)
    print(f"Save matrix to '{os.path.join(matrixSavePath)}'")

    ### save result img
    if resultImgPath is not None:
        cv2.imwrite(resultImgPath, resImg)


##############################################
###             仿射變換
##############################################
def save_one_affine_matrix(srcPts, targetPts, matrixSavePath, matrixName):
    """取得仿射變換矩陣

    Args:
        srcPts (list):  3個原圖參考座標 [(x1,y1), (x2,y2), (x3,y3)]
        targetPts (list): 對應到仿射變換後的3個座標 [(x1',y1'), (x2',y2'), (x3',y3')]
        matrixSavePath (str): 矩陣儲存資料夾路徑
        matrixName (str): 矩陣名稱
    """
    affineMatrix = AffineTransform.get_matrix(srcPts, targetPts)

    ### save matrix
    os.makedirs(matrixSavePath, exist_ok=True)
    matrixFileName = f"{matrixName}.npy"
    np.save(os.path.join(matrixSavePath, matrixFileName), affineMatrix)
    print(f"Save {matrixFileName} to '{os.path.join(matrixSavePath)}'")


def save_all_affin_matrixs(srcList, targetList, matrixSavePath):
    """取得多個仿射變換矩陣 (src 與 target 的順序必須一致)

    Args:
        srcList (list): 原圖參考座標
        targetList (list): 對應到仿射變換後座標 (圖片尺寸為 layout 指定區域的大小)
        matrixSavePath (str): 矩陣儲存資料夾路徑
    """
    for i in range(len(srcList)):
        srcPts = np.float32((srcList[i]["Point"]))
        targetPts = np.float32(targetList[i]["Point"])
        camId = srcList[i]["camId"]

        save_one_affine_matrix(
            srcPts,
            targetPts,
            matrixSavePath=matrixSavePath,
            matrixName=f"cam{camId}_affine_matrix",
        )


if __name__ == "__main__":
    project = PROJECT.TC2

    ##########################################
    ##     畸變校正 (各專案共用)
    ##########################################
    save_distortion_matrix(
        imgPath=r"D:\Users\YjChou\Smart Retail\TC2 Crowd Analysis\data\images\tc2\1.jpg",
        matrixSavePath=r"data\calibrate\matrix\distortion_tmp",
        matrixName="distortion_corr_matix",
        resultImgPath="./distortion_correction_tmp.jpg",
        visualize=False,
    )

    ###########################################
    ###      仿射變換
    ###########################################
    cfgFolder = os.path.join(os.path.join(modulePath, "./data"), project.value)
    config = GetMatrixConfig(cfgFolder)
    blockDict = config.layout.blockDict

    srcList, distList = list(), list()
    for block in blockDict.values():
        region = block["region"]
        srcPoint = [
            tuple(block["affineTrans"]["src_1"]),
            tuple(block["affineTrans"]["src_2"]),
            tuple(block["affineTrans"]["src_3"]),
        ]
        distPoint = [
            tuple((block["affineTrans"]["dist_1"][0] - region[0], block["affineTrans"]["dist_1"][1] - region[1])),
            tuple((block["affineTrans"]["dist_2"][0] - region[0], block["affineTrans"]["dist_2"][1] - region[1])),
            tuple((block["affineTrans"]["dist_3"][0] - region[0], block["affineTrans"]["dist_3"][1] - region[1])),
        ]

        srcList.append(dict({"blockId": block["blockId"], "Point": srcPoint}))
        distList.append(dict({"blockId": block["blockId"], "Point": distPoint}))
    save_all_affin_matrixs(srcList, distList, matrixSavePath=r"data\affine_tmp")
