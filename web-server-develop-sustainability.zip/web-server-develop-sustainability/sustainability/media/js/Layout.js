var info = new Vue({
    el: "#info",
    data: {
        isDisplay: true
    }
})

var app = new Vue({
    el: "#app",
    data: {
        heatMapObs: null,
        heatMapData: {},
        all_status: '',
        heatMapInstance: {},
        drawingData: [],
        visitorData: {},
        AreaData1: [],
        AreaData2: [],
        HotAreaData: [{
            num: "序廳",
            img: "",
            time: ""
        }]
    },
    created: function () {
        this.init();
    },
    watch: {
        heatMapData: {
            handler: function (newValue, oldValue) {
                this.heatMapInit();
            },
            deep: true,
            immediate: false
        }
    },
    mounted() {
        let self = this;
        self.HeatmapTimer = setInterval(self.LoadHeatmapData, 1000);
        self.visitorTimer = setInterval(self.LoadVisitorData, 180000);
        self.HotAreaTimer = setInterval(self.LoadHotAreaData, 180000);
    },
    computed: {
        peopleCountClass() {
            value = parseInt(this.heatMapData.all_count);
            if (value >= 31) {
                return 'gradient-2'
            } else if (value >= 21 && value <= 30) {
                return 'gradient-3'
            } else if (value >= 11 && value <= 20) {
                return 'gradient-1'
            } else {
                return 'gradient-4'
            }
        }
    },
    methods: {
        init: async function () {
            let self = this;
            await self.GetArea();
            await self.LoadHotAreaData();
            await self.LoadHeatmapData();
            await self.LoadVisitorData();
            await self.heatMapInit();
            // await self.createAreaVisitorChart();
            self.heatMapObs = new ResizeObserver(self.heatMapInit);
            self.heatMapObs.observe(document.getElementById('layout'));
        },
        async LoadVisitorData() {
            let self = this;
            // console.log("LoadVisitorData")
            await axios.get('../API/GetAreaVisitor')
                .then((res) => {
                    // console.log(res)
                    self.visitorData = res.data[0];
                })
                .catch((error) => {
                    console.log(error);
                });
        },
        async LoadHeatmapData() {
            let self = this;
            // console.log("LoadHeatmapData")
            await axios.get('../API/GetHeatmap')
                .then((res) => {
                    self.heatMapData = res.data[0];
                    // console.log('heatMapData:', self.heatMapData);
                    if (typeof(self.heatMapData) == 'undefined') {
                        function CurrentTime() {
                            var today = new Date();
                            var day = today.getDate();
                            var month = today.getMonth() + 1;
                            var year = today.getFullYear();
                            var hour = today.getHours();
                            if (day < 10) day = "0" + day;
                            if (month < 10) month = "0" + month;
                            if (hour < 10) hour = "0" + hour;
                            var minute = today.getMinutes();
                            if (minute < 10) minute = "0" + minute;
                            var second = today.getSeconds();
                            if (second < 10) second = "0" + second;
                            return year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second;
                        }
                        self.heatMapData = {
                            "id": 1,
                            "all_count": "0",
                            "acc_count": "0",
                            "data": "",
                            "insert_time": CurrentTime()
                        }                        
                        self.all_status = '舒適'
                    } else {
                        if (self.heatMapData.all_count >= 31) {
                            self.all_status = '壅擠'
                        } else if (self.heatMapData.all_count >= 21 && self.heatMapData.all_count <= 30) {
                            self.all_status = '略多'
                        } else if (self.heatMapData.all_count >= 11 && self.heatMapData.all_count <= 20) {
                            self.all_status = '普通'
                        } else {
                            self.all_status = '舒適'
                        }
                    }
                })
                .catch((error) => {
                    console.log(error);
                });
        },
        createPointData(data) {
            this.drawData = []
            var scaleRatio = {};
            scaleRatio = {
                width: document.getElementById('map').width / 1044,
                height: document.getElementById('map').height / 822,
            }
            data.forEach(element => {
                obj = {
                    "x": element[0] * scaleRatio.width,
                    "y": element[1] * scaleRatio.height,
                    "value": element[2]
                }
                this.drawData.push(obj);
            });
        },
        async heatMapInit() {
            let self = this;
            if (document.getElementsByClassName('heatmap-canvas')[0] != undefined) {
                document.getElementsByClassName('heatmap-canvas')[0].remove();
                self.heatMapInstance = {}
                var radiuScale = document.getElementById('map').width * (60 / 1120)
            }
            self.heatMapInstance = h337.create({
                container: document.getElementById('layout'), //存放heatmap的div
                maxOpacity: 0.4,
                backgroundColor: 'rgba(63, 127, 191,.2)',
                radius: radiuScale,
                gradient: {
                    '.0': 'rgba(63, 127, 191,.2)',
                    '.25': 'green',
                    '.5': 'yellow',
                    '.75': 'red'
                },
            });
            if(self.heatMapData.data != '') {
                self.createPointData(JSON.parse(self.heatMapData.data));

                const drawData = { // 熱區繪製的資料格式
                    max: 100,
                    data: self.drawData
                };
                self.heatMapInstance.setData(drawData);
                var gradientCfg = {};

                function updateLegend(data) {
                    // the onExtremaChange callback gives us min, max, and the gradientConfig
                    // so we can update the legend
                    document.querySelector('#min').innerHTML = "舒適";
                    document.querySelector('#max').innerHTML = "擁擠";
                    // regenerate gradient image
                    if (data.gradient != gradientCfg) {
                        gradientCfg = data.gradient;
                        var gradient = document.getElementsByClassName('heatmap-canvas')[0].getContext('2d').createLinearGradient(0, 0, 100, 1);
                        for (var key in gradientCfg) {
                            gradient.addColorStop(key, gradientCfg[key]);
                        }
                        document.getElementsByClassName('heatmap-canvas')[0].getContext('2d').fillStyle = gradient;
                        document.getElementsByClassName('heatmap-canvas')[0].getContext('2d').fillRect(0, 0, 100, 10);
                        document.querySelector('#gradient').src = document.getElementsByClassName('heatmap-canvas')[0].toDataURL();
                    }
                };

                var heatMapWrapper = document.querySelector('.heatmap-canvas');
                var tooltip = document.querySelector('.heat-map-tooltip');
            }
        },
        async GetArea() {
            let self = this;
            await axios.get('../API/GetAllArea')
                .then(function (response) {
                    // console.log('AreaList:', response.data);
                    var options_num = [];
                    var options_name = [];
                    for (var i = 0; i < response.data.length; i++) {
                        options_num.push(response.data[i]['area_num']);
                        options_name.push(response.data[i]['area_name']);
                    }
                    // console.log('options_num:', options_num);
                    // console.log('options_name:', options_name);

                    const num_middleIndex = Math.ceil(options_num.length / 2);
                    const num_firstHalf = options_num.splice(0, num_middleIndex);
                    const num_secondHalf = options_num.splice(-num_middleIndex);
                    const name_middleIndex = Math.ceil(options_name.length / 2);
                    const name_firstHalf = options_name.splice(0, name_middleIndex);
                    const name_secondHalf = options_name.splice(-name_middleIndex);

                    // console.log(num_firstHalf);
                    // console.log(num_secondHalf);
                    // console.log(name_firstHalf);
                    // console.log(name_secondHalf);

                    var Data1 = [];
                    for (var i = 0; i < num_firstHalf.length; i++) {
                        var tmp_dict = {
                            num: num_firstHalf[i],
                            name: name_firstHalf[i]
                        };
                        Data1.push(tmp_dict);
                    }
                    self.AreaData1 = Data1;
                    // console.log('AreaData1:', self.AreaData1);

                    var Data2 = [];
                    for (var i = 0; i < num_secondHalf.length; i++) {
                        var tmp_dict = {
                            num: num_secondHalf[i],
                            name: name_secondHalf[i]
                        };
                        Data2.push(tmp_dict);
                    }
                    self.AreaData2 = Data2;
                    // console.log('AreaData2:', self.AreaData2);
                })
                .catch((error) => {
                    console.log('GetArea error - ', error);
                });
        },
        async LoadHotAreaData() {
            let self = this;
            await axios.get('../API/GetHotAreaVisitor')
                .then(function (response) {
                    // console.log('HotAreaList:', response.data);
                    if (response.data[0].length == 0) {
                        function CurrentTime() {
                            var today = new Date();
                            var day = today.getDate();
                            var month = today.getMonth() + 1;
                            var year = today.getFullYear();
                            var hour = today.getHours();
                            if (day < 10) day = "0" + day;
                            if (month < 10) month = "0" + month;
                            if (hour < 10) hour = "0" + hour;
                            var minute = today.getMinutes();
                            if (minute < 10) minute = "0" + minute;
                            var second = today.getSeconds();
                            if (second < 10) second = "0" + second;
                            return year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second;
                        }
                        self.HotAreaData = [{
                            num: '1',
                            image: '展區1',
                            name: '主打商品區',
                            time: CurrentTime()
                        },
                        {
                            num: '2',
                            image: '展區2',
                            name: '行為觀察區',
                            time: CurrentTime()
                        },
                        {
                            num: '3',
                            image: '展區3',
                            name: '常態商品區',
                            time: CurrentTime()
                        }]
                    } else {
                        var Data = [];
                        for (var i = 0; i < response.data[0].length; i++) {
                            var tmp_dict = {
                                num: (i + 1).toString(),
                                image: response.data[0][i],
                                name: response.data[0][i],
                                time: response.data[2]
                            };
                            Data.push(tmp_dict);
                        }
                        self.HotAreaData = Data;
                        // console.log('HotAreaData:', self.HotAreaData);
                    }
                })
                .catch((error) => {
                    console.log('GetHotArea error - ', error);
                });
        },
        createAreaVisitorChart() {
            var self = this;
            var area = app.visitorData.area.substring(2, app.visitorData.area.length - 2).replaceAll("'", "").split(", ")
            var myLayoutCountChart = echarts.init(document.getElementById('LayoutCountChart'));
            myLayoutCountChart.setOption({
                grid: {
                    left: '5%',
                    right: '5%'
                },
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow'
                    },
                    valueFormatter: (value) => value + '人'
                },
                xAxis: [{
                    type: 'category',
                    data: area,
                    axisTick: {
                        show: false,
                    },
                    splitLine: {
                        show: false,
                    },
                    axisLine: {
                        show: false,
                    },
                    axisLabel: {
                        color: '#959494',
                        fontSize: 18,
                        fontWeight: 600,
                        interval: 0,
                        padding: [8, 0, 0, 0]
                    },
                }],
                yAxis: [{
                    type: 'value',
                    name: '(人)',
                    nameTextStyle: {
                        color: "#959494",
                        fontSize: 18,
                        padding: [0, 0, 6, -60],
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#959494'
                        },
                        padding: 10
                    },
                }],
                series: [{
                    name: '人數',
                    type: 'bar',
                    emphasis: {
                        focus: 'series'
                    },
                    barWidth: 80,
                    itemStyle: {
                        color: '#2581BA'
                    },
                    label: {
                        normal: {
                            show: true,
                            position: "top",
                            formatter: function (data) {
                                return '{a0|' + data.value + '}';
                            },
                            rich: {
                                a0: {
                                    color: '#2581BA',
                                    fontSize: 20
                                },
                            }
                        },
                    },
                    data: JSON.parse(self.visitorData.count)
                }]
            });
        }
    }
});