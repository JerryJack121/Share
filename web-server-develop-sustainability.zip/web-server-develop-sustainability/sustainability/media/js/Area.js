var info = new Vue({
    el: "#info",
    data: {
        isDisplay: false
    }
})

var app = new Vue({
    el: "#app",
    data: {
        TableSetting: {},
        AreaTable: {},
        AreaData: [],
        AreaDetail: {
            area_num: null,
            area_name: null,
        },
        ClickCellid: '',
        Permission: 0, // 預設0沒權限
    },
    created: function () {
        this.init();
    },
    methods: {
        init: async function () {
            let self = this;
            await self.LoadAreaList();
            await self.InitTable();
            await self.CheckPermission();
        },
        getCookie(cookieName) {
            var name = cookieName + "=";
            var ca = document.cookie.split(';');
            for (var i = 0; i < ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ') c = c.substring(1);
                if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
            }
            return "";
        },
        async InitTable() {
            let self = this;
            self.TableSetting = {
                height: "700px",
                layout: "fitColumns",
                pagination: "local",
                paginationSize: 10,
                paginationSizeSelector: [10, 15, 20],
                data: self.AreaData,
                columns: [{
                        title: "No",
                        field: "id",
                        sorter: "number",
                        visible: false,
                        vertAlign: "middle"
                    },
                    {
                        title: "展區編號",
                        field: "area_num",
                        vertAlign: "middle",
                        bottomCalc: function (values, data, calcParams) {
                            var calc = 0;
                            values.forEach(function (value) {
                                if (value != '') {
                                    calc++;
                                }
                            });
                            return '共 ' + calc.toString() + ' 區';
                        }
                    },
                    {
                        title: "展區名稱",
                        field: "area_name",
                        vertAlign: "middle"
                    },
                    {
                        title: "新增時間",
                        field: "insert_time",
                        vertAlign: "middle"
                    },
                    {
                        title: "編輯",
                        field: "edit",
                        width: "100",
                        vertAlign: "middle",
                        formatter: function (cell, formatterParams, onRendered) {
                            var editBtn =
                                '<button type="button" class="btn mb-1 btn-info btn-sm" style="border-color: #2581BA; background-color: #2581BA;" data-toggle="modal" data-target="#AreaDetailModal">\
                                    <i class="fa fa-pencil-square-o"></i></button>'
                            return editBtn
                        },
                        cellClick: function (e, cell) {
                            self.editAreaClick(e, cell);
                        },
                        visible: true,
                    },
                    {
                        title: "刪除",
                        field: "delete",
                        width: "100",
                        vertAlign: "middle",
                        formatter: function (cell, formatterParams, onRendered) {
                            var deleteBtn =
                                '<button type="button" class="btn mb-1 btn-danger btn-sm">\
                                    <i class="fa fa-trash"></i></button>'
                            return deleteBtn
                        },
                        cellClick: function (e, cell) {
                            self.deleteAreaClick(e, cell);
                        },
                        visible: true,
                    }
                ]
            }
            self.AreaTable = new Tabulator("#AreaTable", self.TableSetting);
        },
        async LoadAreaList() {
            let self = this;
            await axios.get('../API/GetAllArea')
                .then((response) => {
                    // console.log('GetAllArea:', response.data);
                    self.AreaData = response.data;
                    // console.log('1-init', self.AreaData);
                })
                .catch((error) => {
                    console.log('GetAllArea error -', error);
                });
        },
        async AddArea() {
            let self = this;

            Swal.fire({
                title: '新增展區資訊',
                icon: 'info',
                stopKeydownPropagation: false,
                html: '<div class="input-group mb-3">' +
                    '<div class="input-group-prepend">' +
                    '<span class="input-group-text">展區編號</span>' +
                    '</div>' +
                    '<input type="text" class="form-control" id="area_num">' +
                    '</div>' +
                    '<div class="input-group mb-3">' +
                    '<div class="input-group-prepend">' +
                    '<span class="input-group-text">展區名稱</span>' +
                    '</div>' +
                    '<input type="text" class="form-control" id="area_name">' +
                    '</div>',
                showCloseButton: true,
                showCancelButton: true,
                focusConfirm: false,
                confirmButtonColor: '#2581BA',
                confirmButtonText: '<i class="fa fa-check"> 新增</i>',
                cancelButtonText: '<i class="fa fa-times"> 取消</i>',
                preConfirm: () => {
                    const num = Swal.getPopup().querySelector('#area_num').value
                    const name = Swal.getPopup().querySelector('#area_name').value
                    if (!num || !name) {
                        Swal.showValidationMessage(`請輸入編號、名稱`)
                    }
                    return {
                        num: num,
                        name: name,
                    }
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    var area_data = {
                        area_num: document.getElementById('area_num').value,
                        area_name: document.getElementById('area_name').value,
                    }
                    axios.post('../API/GetAllArea', area_data)
                        .then((response) => {
                            if (response.status == 200) {
                                if (response.data == 'CONFLICT') {
                                    Swal.fire({
                                        icon: 'error',
                                        title: '展區新增失敗',
                                        text: '展區' + `${result.value.name}` + '」重複'
                                    });
                                } else {
                                    Swal.fire({
                                            title: "展區新增成功",
                                            icon: "success",
                                            html: '<span>編號 - ' + area_data.area_num + '</span></br>' +
                                                '<span>名稱 - ' + area_data.area_name + '</span></br>'
                                        })
                                        .then((result) => {
                                            if (result.isConfirmed) {
                                                self.AreaTable.replaceData([]);
                                                axios.get('../API/GetAllArea')
                                                    .then((response) => {
                                                        self.AreaData = response.data;
                                                        self.AreaTable.addData(response.data);
                                                    })
                                                    .catch((error) => {
                                                        console.log('GetAllArea error -', error);
                                                    });
                                            }
                                        })
                                }
                            }
                        })
                        .catch((error) => {
                            console.log('GetAllArea error - ', error);
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: '展區新增失敗'
                            });
                        });
                }
            })
        },
        async CheckPermission() {
            let self = this;
            axios.get('../API/CheckPermission/' + self.getCookie('name'))
                .then((response) => {
                    var Permission = response.data
                    console.log('CheckPermission:', Permission);
                    if (Permission === true) {
                        self.Permission = 1;
                    } else {
                        self.Permission = 0;
                    }
                })
        },
        async deleteAreaClick(e, cell) {
            let self = this;
            if (self.Permission == 1) {
                var row = cell.getRow();
                var cell_id = row.getCell('id').getValue();
                var cell_area_num = row.getCell('area_num').getValue();
                var cell_area_name = row.getCell('area_name').getValue();
                console.log('展區 刪除 id=' + cell_id);

                const swalWithBootstrapButtons = Swal.mixin({
                    customClass: {
                        confirmButton: 'btn btn-success',
                        cancelButton: 'btn btn-danger'
                    },
                    buttonsStyling: false
                })

                Swal.fire({
                    title: '確定刪除此展區嗎？',
                    text: cell_area_num + ' / ' + cell_area_name,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#2581BA',
                    cancelButtonColor: '#d33',
                    confirmButtonText: '刪除',
                    cancelButtonText: '取消',
                    showClass: {
                        popup: 'animate__animated animate__fadeInDown'
                    },
                    hideClass: {
                        popup: 'animate__animated animate__fadeOutUp'
                    }
                }).then((result) => {
                    if (result.isConfirmed) {
                        axios.delete('../API/GetAreaById/' + cell_id)
                            .then(() =>
                                swalWithBootstrapButtons.fire({
                                    icon: 'success',
                                    title: 'Deleted',
                                    text: '展區刪除成功',
                                })
                                .then((result) => {
                                    if (result.isConfirmed) {
                                        self.AreaTable.replaceData([]);
                                        axios.get('../API/GetAllArea')
                                            .then((response) => {
                                                self.AreaData = response.data;
                                                self.AreaTable.addData(response.data);
                                            })
                                            .catch((error) => {
                                                console.log('GetAllArea error -', error);
                                            });
                                    }
                                })
                            );
                    } else if (result.dismiss === Swal.DismissReason.cancel) {
                        swalWithBootstrapButtons.fire(
                            'Cancelled',
                            '取消刪除',
                            'info'
                        );
                    }
                })
            } else {
                Swal.fire({
                    icon: 'info',
                    title: '無刪除權限',
                    html: '若須刪除請洽管理員'
                })
            }
        },
        async editAreaClick(e, cell) {
            let self = this;
            var row = cell.getRow();
            var cell_id = row.getCell('id').getValue();
            self.ClickCellid = cell_id;
            console.log('展區 編輯 id=' + cell_id);

            await axios.get('../API/GetAreaById/' + cell_id)
                .then((response) => {
                    // console.log('(Edit) GetAreaById:', response.data);
                    var Detail = response.data[0];
                    self.AreaDetail.area_num = Detail['area_num']
                    self.AreaDetail.area_name = Detail['area_name']
                })
                .catch((error) => {
                    console.log('editAreaClick error -', error);
                });
        },
        async UpdateArea() {
            let self = this;
            if ((self.AreaDetail.area_num != null && self.AreaDetail.area_num != '') 
                && (self.AreaDetail.area_name != null && self.AreaDetail.area_name != '')) {
                let update_area_data = {
                    area_num: self.AreaDetail.area_num,
                    area_name: self.AreaDetail.area_name,
                }
                // console.log('update_area_data', update_area_data);

                await axios.patch('../API/GetAreaById/' + self.ClickCellid, update_area_data)
                    .then(function (response) {
                        if (response.status == 200) {
                            Swal.fire({
                                    icon: 'success',
                                    title: '展區編輯成功',
                                    confirmButtonColor: '#2581BA',
                                })
                                .then((result) => {
                                    if (result.isConfirmed) {
                                        self.AreaTable.replaceData([]);
                                        axios.get('../API/GetAllArea')
                                            .then((response) => {
                                                self.AreaData = response.data;
                                                self.AreaTable.addData(response.data);
                                            })
                                            .catch((error) => {
                                                console.log('GetAllArea error -', error);
                                            });
                                    }
                                })
                        } else {
                            Swal.fire({
                                title: "展區編輯失敗",
                                icon: "error",
                            })
                        }
                    })
                    .catch((error) => {
                        console.log('UpdateArea error - ', error);
                    });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: '展區編輯失敗',
                    html: '請輸入完整資料'
                })
            }
        }
    }
});