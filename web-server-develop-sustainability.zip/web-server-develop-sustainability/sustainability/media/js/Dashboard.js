var info = new Vue({
    el: "#info",
    data: {
        isDisplay: true
    }
})

var app = new Vue({
    el: "#app",
    data: {
        AreaData1: [],
        AreaData2: [],
        VisitorOptions: [],
        AllCount: {
            week_day: [],
            data: []
        },
        AreaVisitor: {
            area: [],
            max: [],
            avg: []
        },
        VisitorData: {},
        AvgtimeVisitData: {},
        SelectVisitor: 'All',
        FilterData: {
            SelectStartDate: null,
            SelectEndDate: null,
            SelectDate: null,
            SelectType: 'all',
            SelectGoal: 'all'
        },
        ChartSearchData: '',
        myAllCountChart: ''
    },
    created: function () {
        this.init();
    },
    methods: {
        init: async function () {
            let self = this;
            await self.LoadAllCountOneWeekData();
            self.LoadAreaVisitorAllCountData();
            self.LoadVisitorData();
            // await self.LoadAvgtimeVisitData();
            await self.GetVisitor();
            // await self.GetArea();
            // await self.CreateAllCountChart();
            // await self.CreateAreaVisitorChart();
        },
        async LoadAllCountOneWeekData() {
            let self = this;
            await axios.get('../API/GetAllCountOneWeek')
                .then((res) => {
                    self.AllCount.week_day = res.data['week_day'];
                    self.AllCount.data = res.data['data'];
                    // console.log(self.AllCount.week_day);
                    console.log('LoadAllCountOneWeekData:', self.AllCount.data);
                })
                .catch((error) => {
                    console.log('LoadAllCountOneWeekData:', error);
                });
        },
        async LoadAllCountTwoWeekData() {
            let self = this;
            await axios.get('../API/GetAllCountTwoWeek')
                .then((res) => {
                    self.AllCount.week_day = res.data['week_day'];
                    self.AllCount.data = res.data['data'];
                    // console.log(self.AllCount.week_day);
                    // console.log(self.AllCount.data);
                })
                .catch((error) => {
                    console.log('LoadAllCountTwoWeekData:', error);
                });
        },
        async LoadAllCountFilterData() {
            let self = this;

            var filter_url = '../API/GetAllCountFilter?start_date=' + self.FilterData.SelectStartDate + '&end_date=' + self.FilterData.SelectEndDate
            console.log('(5) - LoadAllCountFilterData Count filter_url:', filter_url);

            await axios.get(filter_url)
                .then((res) => {
                    self.AllCount.week_day = res.data['week_day'];
                    self.AllCount.data = res.data['data'];
                    // console.log(self.AllCount.week_day);
                    // console.log(self.AllCount.data);
                })
                .catch((error) => {
                    console.log('LoadAllCountFilterData:', error);
                });
        },
        async LoadAreaVisitorAllCountData() {
            let self = this;
            var myLayoutCountChart = echarts.init(document.getElementById('LayoutCountChart'));
            myLayoutCountChart.showLoading({
                text: ' Loading',
                color: '#2581BA',
                textColor: '#2581BA',
                maskColor: 'rgba(37, 129, 186, 0.1)',
                fontSize: 20,
            });

            self.LoadAvgtimeVisitData();

            await axios.get('../API/GetAreaVisitorAllCountLastWeek')
                .then((res) => {
                    console.log('LoadAreaVisitorAllCountData:', res.data);
                    self.AreaVisitor.area = res.data[0];
                    self.AreaVisitor.max = res.data[1];
                    self.AreaVisitor.avg = res.data[2];
                    // console.log(self.AreaVisitor.area);
                    // console.log(self.AreaVisitor.max);
                    // console.log(self.AreaVisitor.avg);
                    console.log('Init Date:', res.data[3], '~', res.data[4]);
                    self.FilterData.SelectStartDate = res.data[3];
                    self.FilterData.SelectEndDate = res.data[4];
                })
                .catch((error) => {
                    console.log('LoadAreaVisitorAllCountData:', error);
                });

            if (self.AreaVisitor.avg.length == 0) {
                var list_avg = [];
                for (var i = 0; i < self.AreaVisitor.area.length; i++) {
                    list_avg.push(0);
                }
                self.AreaVisitor.avg = list_avg
            }
            if (self.AreaVisitor.max.length == 0) {
                var list_max = [];
                for (var i = 0; i < self.AreaVisitor.area.length; i++) {
                    list_max.push(0);
                }
                self.AreaVisitor.max = list_max
            }

            myLayoutCountChart.setOption({
                grid: {
                    left: '6%',
                    right: '6%',
                    top: '20%'
                },
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow',
                        shadowStyle: {
                            color: 'rgba(37, 129, 186, 0.1)'
                        }
                    },
                    formatter: function (datas) {
                        var res = "<b style='font-size:16px;'>" + datas[0].name + '</b><br/><br/>',
                            val;
                        for (var i = 0, length = datas.length; i < length; i++) {
                            if (datas[i].seriesName == "平均停留時間") {
                                res += datas[i].marker + ' ' + datas[i].seriesName + '：' + datas[i].value + '秒<br/>';
                            } else {
                                res += datas[i].marker + ' ' + datas[i].seriesName + '：' + datas[i].value + '人<br/>';
                            }
                        }
                        return res;
                    }
                },
                toolbox: {
                    right: '1%',
                    top: '-2%',
                    feature: {
                        dataZoom: {
                            show: true,
                            readOnly: false,
                            title: '區域檢視',
                        },
                        myrestore: {
                            show: true,
                            title: '重置',
                            icon: 'path://M 25 2 A 1.0001 1.0001 0 1 0 25 4 C 36.609534 4 46 13.390466 46 25 C 46 36.609534 36.609534 46 25 46 C 13.390466 46 4 36.609534 4 25 C 4 18.307314 7.130711 12.364806 12 8.5195312 L 12 15 A 1.0001 1.0001 0 1 0 14 15 L 14 6.5507812 L 14 5 L 4 5 A 1.0001 1.0001 0 1 0 4 7 L 10.699219 7 C 5.4020866 11.214814 2 17.712204 2 25 C 2 37.690466 12.309534 48 25 48 C 37.690466 48 48 37.690466 48 25 C 48 12.309534 37.690466 2 25 2 z',
                            onclick: async () => {
                                $('#inputStartDate').val('');
                                $('#inputEndDate').val('');
                                await self.LoadAreaVisitorAllCountData();
                                await self.LoadAvgtimeVisitData();
                                var myLayoutCountChart = echarts.init(document.getElementById('LayoutCountChart'));
                                myLayoutCountChart.clear();
                                await self.CreateAreaVisitorChart();
                            }
                        },
                        dataView: {
                            show: true,
                            title: '詳細',
                            lang: ['詳細資料', '關閉', '更新'],
                            optionToContent: function (opt) {
                                var axisData = opt.xAxis[0].data;
                                var series = opt.series;
                                var tdHeads = '<td style="padding:10px 20px; font-size:18px;">展區名稱</td>';
                                series.forEach(function (item) {
                                    if (item.name == '最大人數') {
                                        item.name += ' (人)'
                                    } else if (item.name == '平均停留時間') {
                                        item.name += ' (秒)'
                                    }

                                    tdHeads += '<td style="padding: 10px 20px; font-size:18px;">' + item.name + '</td>';
                                });
                                var table = '<table border="1" style="margin-left:20px;border-collapse:collapse;font-size:14px;text-align:center"><tbody><tr>' + tdHeads + '</tr>';
                                var tdBodys = '';
                                for (var i = 0, l = axisData.length; i < l; i++) {
                                    for (var j = 0; j < series.length; j++) {
                                        if (typeof (series[j].data[i]) == 'object') {
                                            tdBodys += '<td>' + series[j].data[i].value + '</td>';
                                        } else {
                                            tdBodys += '<td>' + series[j].data[i] + '</td>';
                                        }
                                    }
                                    table += '<tr><td style="padding: 0 10px">' + axisData[i] + '</td>' + tdBodys + '</tr>';
                                    tdBodys = '';
                                }
                                table += '</tbody></table>';
                                return table;
                            }
                        },
                        magicType: {
                            type: ["line", "bar"]
                        },
                        myfile: {
                            show: true,
                            title: '下載檔案',
                            icon: 'path://M69.78,0.72C69.3,0.29,68.62,0,67.95,0c-0.14,0-0.29,0-0.43,0.05l-61.42,0c-1.64,0-3.19,0.68-4.3,1.79 C0.68,2.95,0,4.45,0,6.14v110.65c0,1.69,0.68,3.19,1.79,4.3c1.11,1.11,2.61,1.79,4.3,1.79c31.03,0,59.35,0,90.22,0 c1.69,0,3.19-0.68,4.3-1.79c1.11-1.11,1.79-2.61,1.79-4.3V35.52c0.05-0.24,0.1-0.43,0.1-0.68c0-0.82-0.39-1.55-0.92-2.08 L70.12,0.92c-0.1-0.1-0.15-0.14-0.24-0.19H69.78L69.78,0.72z M48.51,83.75V48.86c0-1.49,1.2-2.69,2.73-2.69 c1.49,0,2.73,1.2,2.73,2.69v34.86l12.52-10.93c1.11-0.98,2.82-0.89,3.8,0.22c0.98,1.11,0.89,2.79-0.22,3.77L53.05,91.64 c-1.05,0.92-2.6,0.89-3.61-0.03L32.45,76.77c-1.11-0.98-1.24-2.66-0.22-3.77c0.98-1.11,2.69-1.2,3.8-0.22l12.52,10.93L48.51,83.75 L48.51,83.75z M65.19,5.51v23.83c0,2.27,0.92,4.35,2.42,5.85c1.5,1.5,3.58,2.42,5.85,2.42h23.39v79.19c0,0.15-0.05,0.34-0.19,0.43 c-0.1,0.1-0.24,0.19-0.43,0.19c-24.57,0-66.28,0-90.18,0c-0.15,0-0.34-0.05-0.43-0.19c-0.1-0.1-0.19-0.29-0.19-0.43V6.14 c0-0.19,0.05-0.34,0.19-0.43c0.1-0.1,0.24-0.19,0.43-0.19h59.1H65.19L65.19,5.51z M70.65,29.34V9.38l22.47,22.76H73.45 c-0.77,0-1.45-0.34-1.98-0.82C70.99,30.83,70.65,30.11,70.65,29.34L70.65,29.34z',
                            onclick: async (opt) => {
                                Swal.fire({
                                    title: '下載檔案',
                                    icon: 'info',
                                    stopKeydownPropagation: false,
                                    html: '<div class="input-group mb-3">' +
                                        '<div class="input-group-prepend">' +
                                        '<span class="input-group-text">下載檔案格式</span>' +
                                        '</div>' +
                                        '<select class="form-control" id="file_type">' +
                                        '<option value="圖片(.jpeg)">圖片(.jpeg)</option>' +
                                        '<option value="表格(.csv)">表格(.csv)</option>' +
                                        '<option value="表格(.xlsx)">表格(.xlsx)</option>' +
                                        '</select>' +
                                        '</div>',
                                    showCloseButton: true,
                                    showCancelButton: true,
                                    focusConfirm: false,
                                    confirmButtonColor: '#2581BA',
                                    confirmButtonText: '<i class="fa fa-download"> 下載</i>',
                                    cancelButtonText: '<i class="fa fa-times"> 取消</i>',
                                }).then((result) => {
                                    if (result.isConfirmed) {
                                        var select_type = document.getElementById('file_type').value;
                                        // console.log('select_type:', select_type);
                                        if (select_type == '圖片(.jpeg)') {
                                            function saveDivAsImage(divId) {
                                                const element = document.getElementById(divId);
                                                html2canvas(element).then(canvas => {
                                                    const link = document.createElement('a');
                                                    link.download = '各展區人數及平均停留時間統計.jpeg';
                                                    link.href = canvas.toDataURL('image/jpeg', 1.0);
                                                    link.click();
                                                });
                                            }
                                            saveDivAsImage('LayoutCountChart');
                                        } else if (select_type == '表格(.csv)') {
                                            function CurrentTime() {
                                                var today = new Date();
                                                var day = today.getDate();
                                                var month = today.getMonth() + 1;
                                                var year = today.getFullYear();
                                                var hour = today.getHours();
                                                if (day < 10) day = "0" + day;
                                                if (month < 10) month = "0" + month;
                                                if (hour < 10) hour = "0" + hour;
                                                var minute = today.getMinutes();
                                                if (minute < 10) minute = "0" + minute;
                                                var second = today.getSeconds();
                                                if (second < 10) second = "0" + second;
                                                return year + "-" + month + "-" + day + " " + hour + "-" + minute + "-" + second;
                                            }

                                            function saveAsFileCSV(current_time) {
                                                var _headers = ['展區名稱', '最大人數(人)', '平均停留時間(秒)'];
                                                var csvData = new Array();
                                                csvData.push(_headers);
                                                for (i = 0; i < self.AreaVisitor.area.length; i++) {
                                                    csvData.push(new Array(self.AreaVisitor.area[i], self.AreaVisitor.max[i], self.AvgtimeVisitData[i]));
                                                }
                                                // console.log('csvData:', csvData);
                                                var lineArray = [];
                                                csvData.forEach(function (infoArray, index) {
                                                    var line = infoArray.join(",");
                                                    lineArray.push(index == 0 ? "\uFEFF" + line : line);
                                                });
                                                var csvContent = lineArray.join("\n");
                                                var blob = new Blob([csvContent], {
                                                    type: "text/csv;charset=utf-8;"
                                                });
                                                var link = document.createElement("a");

                                                if (link.download !== undefined) {
                                                    link.setAttribute("href", window.URL.createObjectURL(blob));
                                                    link.setAttribute("download", "展區參訪人數_" + current_time + ".csv");
                                                    link.setAttribute("hidden", true);
                                                } else {
                                                    link.setAttribute("href", "#");
                                                }
                                                link.click();
                                            }
                                            saveAsFileCSV(CurrentTime());
                                        } else if (select_type == '表格(.xlsx)') {
                                            function CurrentTime() {
                                                var today = new Date();
                                                var day = today.getDate();
                                                var month = today.getMonth() + 1;
                                                var year = today.getFullYear();
                                                var hour = today.getHours();
                                                if (day < 10) day = "0" + day;
                                                if (month < 10) month = "0" + month;
                                                if (hour < 10) hour = "0" + hour;
                                                var minute = today.getMinutes();
                                                if (minute < 10) minute = "0" + minute;
                                                var second = today.getSeconds();
                                                if (second < 10) second = "0" + second;
                                                return year + "-" + month + "-" + day + " " + hour + "-" + minute + "-" + second;
                                            }
                                            function saveAsFileXLSX(current_time) {
                                                var xdata = opt.option.xAxis[0].data;
                                                var ydata1 = opt.option.series[0].data;
                                                var ydata2 = opt.option.series[1].data;
                                                var workbook = XLSX.utils.book_new();        
                                                const worksheet_data  =  [xdata, ydata1, ydata2];
                                                const header = [['展區名稱', '最大人數(人)', '平均停留時間(秒)']];
                                                const trans_worksheet_data = worksheet_data[0].map((_, colIndex) => worksheet_data.map(row => row[colIndex]));
                                                const data = header.concat(trans_worksheet_data); 
                                                var worksheet = XLSX.utils.aoa_to_sheet(data);
                                                workbook.SheetNames.push("展區參訪人數_" + current_time);
                                                workbook.Sheets["展區參訪人數_" + current_time] = worksheet;
                                                XLSX.writeFile(workbook, "展區參訪人數_" + current_time + ".xlsx");
                                            }
                                            saveAsFileXLSX(CurrentTime());
                                        }
                                    }
                                })
                            }
                        }
                    },
                    iconStyle: {
                        borderColor: '#2581BA',
                        fontSize: '22px',
                    },
                },
                legend: {
                    bottom: "0%",
                    itemHeight: 15,
                    itemWidth: 25,
                    itemGap: 25,
                    padding: [0, 10],
                    textStyle: {
                        fontSize: 14,
                        color: "#959494",
                    },
                    data: [{
                            name: "平均人數",
                        },
                        {
                            name: "最大人數",
                        },
                        {
                            name: "平均停留時間",
                        }
                    ],
                },
                xAxis: [{
                    type: 'category',
                    data: self.AreaVisitor.area,
                    axisTick: {
                        show: false,
                    },
                    splitLine: {
                        show: false,
                    },
                    axisLine: {
                        show: false,
                    },
                    axisLabel: {
                        color: '#959494',
                        fontSize: 12,
                        fontWeight: 600,
                        interval: 0,
                        padding: [8, 0, 0, 0]
                    },
                }],
                yAxis: [{
                        type: 'value',
                        name: '人數 (人)',
                        min: 0,
                        max: 60,
                        // splitNumber: 6,
                        interval: 10,
                        nameTextStyle: {
                            color: "#2581BA",
                            fontSize: 12,
                            padding: [0, 0, 6, -50],
                        },
                        axisLabel: {
                            show: true,
                            textStyle: {
                                color: '#2581BA'
                            },
                            padding: 10,
                            formatter: function (value, index) {
                                return Math.round(value);
                            }
                        },
                        axisLine: {
                            lineStyle: {
                                color: '#fff'
                            }
                        }
                    },
                    {
                        type: 'value',
                        name: '時間(秒)',
                        min: 0,
                        max: 360,
                        // splitNumber: 6,
                        interval: 60,
                        nameTextStyle: {
                            color: "#82943D",
                            fontSize: 12,
                            padding: [0, 0, 6, 50],
                        },
                        axisLabel: {
                            show: true,
                            textStyle: {
                                color: '#82943D'
                            },
                            padding: 10,
                            formatter: function (value, index) {
                                return Math.round(value);
                            }
                        },
                        // splitLine: {
                        //     lineStyle: {
                        //         color: '#fff'
                        //     }
                        // },
                        axisLine: {
                            lineStyle: {
                                color: '#fff'
                            }
                        }
                    }
                ],
                series: [
                    // {
                    //     name: '平均人數',
                    //     type: 'bar',
                    //     yAxisIndex: "0",
                    //     emphasis: {
                    //         focus: 'series'
                    //     },
                    //     barWidth: 30,
                    //     itemStyle: {
                    //         color: '#2581BA'
                    //     },
                    //     label: {
                    //         normal: {
                    //             show: true,
                    //             position: "inside",
                    //             formatter: function (data) {
                    //                 return '{a0|' + data.value + '}';
                    //             },
                    //             rich: {
                    //                 a0: {
                    //                     color: '#ffffff',
                    //                     fontSize: 12
                    //                 },
                    //             }
                    //         },
                    //     },
                    //     data: self.AreaVisitor.avg
                    // },
                    {
                        name: '最大人數',
                        type: "bar",
                        yAxisIndex: "0",
                        symbol: "square",
                        symbolSize: 12,
                        color: "#2581BA",
                        lineStyle: {
                            normal: {
                                width: 2
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: '#2581BA',
                                borderWidth: 1,
                                borderColor: '#f3f3f3',
                            }
                        },
                        data: self.AreaVisitor.max,
                        label: {
                            normal: {
                                show: true,
                                position: "top",
                                color: '#2581BA',
                                fontSize: 14,
                                formatter: "{c}"
                            }
                        }
                    },
                    {
                        name: '平均停留時間',
                        type: "bar",
                        yAxisIndex: "1",
                        symbol: "diamond",
                        symbolSize: 12,
                        color: "#82943D",
                        lineStyle: {
                            normal: {
                                width: 2
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: '#82943D',
                                borderWidth: 1,
                                borderColor: '#f3f3f3',
                            }
                        },
                        data: self.AvgtimeVisitData,
                        label: {
                            normal: {
                                show: true,
                                position: "top",
                                color: '#82943D',
                                fontSize: 14,
                                formatter: "{c}"
                            }
                        }
                    }
                ]
            });
            myLayoutCountChart.hideLoading();
            window.addEventListener('resize', function () {
                myLayoutCountChart.resize();
            })
        },
        async LoadAreaVisitorFilterCountData() {
            let self = this;

            self.FilterData.SelectDate = self.FilterData.SelectStartDate + '_' + self.FilterData.SelectEndDate
            console.log('LoadAreaVisitorFilterCountData_SelectDate:', self.FilterData.SelectDate);

            if (self.FilterData.SelectGoal != 'all' || self.FilterData.SelectType != 'all') {
                // console.log('self.ChartSearchData', self.ChartSearchData);
                var result = self.ChartSearchData.split('<br>');
                var filter_time = [];
                for (var i = 0; i < result.length; i++) {
                    console.log(result[i].split('&nbsp;&nbsp;&nbsp;'))
                    filter_time.push(result[i].split('&nbsp;&nbsp;&nbsp;')[1])
                }
                var filter_time_str = `&`
                for (var j = 0; j < filter_time.length; j++) {
                    filter_time_str += 'filter_time=' + filter_time[j]
                    if (j + 1 != filter_time.length) {
                        filter_time_str += '&'
                    }
                }
                console.log('(1) - filter_time_str:', filter_time_str);
            }
            // 訪客和類型都是all
            else {
                var filter_time_str = ``
            }

            var filter_url = `../API/GetAreaVisitorFilterCount?insert_time=${self.FilterData.SelectDate}` + filter_time_str
            console.log('(1) - LoadAreaVisitorFilterCountData Count filter_url:', filter_url);

            await axios.get(filter_url)
                .then((res) => {
                    if (res.status == 200) {
                        console.log('LoadAreaVisitorFilterCountData:', res.data);
                        self.AreaVisitor.area = res.data[0];
                        self.AreaVisitor.max = res.data[1];
                        self.AreaVisitor.avg = res.data[2];
                        // console.log(self.AreaVisitor.area);
                        // console.log(self.AreaVisitor.max);
                        // console.log(self.AreaVisitor.avg);
                    }
                })
                .catch((error) => {
                    console.log('LoadAreaVisitorFilterCountData:', error);
                });
        },
        async LoadAvgtimeVisitData() {
            let self = this;
            await axios.get('../API/GetAvgtimeVisitLastWeek')
                .then((res) => {
                    console.log('LoadAvgtimeVisitData:', res.data);
                    self.AvgtimeVisitData = res.data;
                    // console.log(self.AvgtimeVisitData);
                })
                .catch((error) => {
                    console.log('LoadAvgtimeVisitData:', error);
                });
        },
        async LoadAvgtimeVisitFilterCountData() {
            let self = this;

            self.FilterData.SelectDate = self.FilterData.SelectStartDate + '_' + self.FilterData.SelectEndDate
            console.log('LoadAvgtimeVisitFilterCountData_SelectDate:', self.FilterData.SelectDate);

            if (self.FilterData.SelectGoal != 'all' || self.FilterData.SelectType != 'all') {
                // console.log('self.ChartSearchData', self.ChartSearchData);
                var result = self.ChartSearchData.split('<br>');
                var filter_time = [];
                for (var i = 0; i < result.length; i++) {
                    console.log(result[i].split('&nbsp;&nbsp;&nbsp;'))
                    filter_time.push(result[i].split('&nbsp;&nbsp;&nbsp;')[1])
                }
                var filter_time_str = `&`
                for (var j = 0; j < filter_time.length; j++) {
                    filter_time_str += 'filter_time=' + filter_time[j]
                    if (j + 1 != filter_time.length) {
                        filter_time_str += '&'
                    }
                }
                console.log('(2) - filter_time_str:', filter_time_str);
            }
            // 訪客和類型都是all
            else {
                var filter_time_str = ``
            }

            var filter_url = `../API/GetAvgtimeVisitFilterCount?insert_time=${self.FilterData.SelectDate}` + filter_time_str
            console.log('(2) - LoadAvgtimeVisitFilterCountData Count filter_url:', filter_url);

            await axios.get(filter_url)
                .then((res) => {
                    if (res.status == 200) {
                        console.log('LoadAvgtimeVisitFilterCountData:', res.data);
                        self.AvgtimeVisitData = res.data;
                        // self.CreateAreaVisitorChart();
                    }
                })
                .catch((error) => {
                    console.log('LoadAvgtimeVisitFilterCountData:', error);
                });
        },
        async LoadVisitorData() {
            let self = this;

            var myAllCountChart = echarts.init(document.getElementById('AllCountChart'));
            myAllCountChart.showLoading({
                text: ' Loading',
                color: '#2581BA',
                textColor: '#2581BA',
                maskColor: 'rgba(37, 129, 186, 0.1)',
                fontSize: 20,
            });

            await axios.get('../API/GetAreaVisitor')
                .then((res) => {
                    self.VisitorData = res.data[0];
                })
                .catch((error) => {
                    console.log('LoadVisitorData:', error);
                });

            myAllCountChart.setOption({
                grid: {
                    left: '5%',
                    right: '0%'
                },
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow',
                        shadowStyle: {
                            color: 'rgba(37, 129, 186, 0.1)'
                        }
                    },
                    valueFormatter: (value) => value + '人'
                },
                xAxis: [{
                    type: 'category',
                    data: self.AllCount.week_day,
                    axisTick: {
                        show: false,
                    },
                    splitLine: {
                        show: false,
                    },
                    axisLine: {
                        show: false,
                    },
                    axisLabel: {
                        color: '#959494',
                        fontSize: 14,
                        fontWeight: 600,
                        interval: 'auto',
                        width: 50,
                        overflow: 'truncate',
                        padding: [8, 0, 0, 0],
                        formatter: function (value) {
                            return value.split('-')[1] + '/' + value.split('-')[2]
                        }
                    },
                }],
                yAxis: [{
                    type: 'value',
                    name: '(人)',
                    nameTextStyle: {
                        color: '#959494',
                        fontSize: 12,
                        padding: [0, 0, 6, -60],
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#959494'
                        },
                        padding: 10
                    },
                }],
                series: [{
                    name: '總人數',
                    type: 'line',
                    symbol: 'circle',
                    symbolSize: 8,
                    emphasis: {
                        focus: 'series'
                    },
                    lineStyle: {
                        normal: {
                            width: 3,
                            color: '#2581BA'
                        },
                    },
                    itemStyle: {
                        color: '#2581BA'
                    },
                    label: {
                        normal: {
                            show: true,
                            position: "top",
                            formatter: function (data) {
                                return '{a0|' + data.value + '}';
                            },
                            rich: {
                                a0: {
                                    color: '#2581BA',
                                    fontSize: 16,
                                },
                            }
                        },
                    },
                    data: self.AllCount.data
                }]
            });
            myAllCountChart.hideLoading();

            window.addEventListener('resize', function () {
                myAllCountChart.resize();
            })
        },
        async GetArea() {
            let self = this;
            console.log('GetArea');

            await axios.get('../API/GetAllArea')
                .then(function (response) {
                    // console.log('AreaList:', response.data);
                    var options_num = [];
                    var options_name = [];
                    for (var i = 0; i < response.data.length; i++) {
                        options_num.push(response.data[i]['area_num']);
                        options_name.push(response.data[i]['area_name']);
                    }
                    // console.log('options_num:', options_num);
                    // console.log('options_name:', options_name);

                    const num_middleIndex = Math.ceil(options_num.length / 2);
                    const num_firstHalf = options_num.splice(0, num_middleIndex);
                    const num_secondHalf = options_num.splice(-num_middleIndex);
                    const name_middleIndex = Math.ceil(options_name.length / 2);
                    const name_firstHalf = options_name.splice(0, name_middleIndex);
                    const name_secondHalf = options_name.splice(-name_middleIndex);

                    // console.log(num_firstHalf);
                    // console.log(num_secondHalf);
                    // console.log(name_firstHalf);
                    // console.log(name_secondHalf);

                    var Data1 = [];
                    for (var i = 0; i < num_firstHalf.length; i++) {
                        var tmp_dict = {
                            num: num_firstHalf[i],
                            name: name_firstHalf[i]
                        };
                        Data1.push(tmp_dict);
                    }
                    self.AreaData1 = Data1;
                    // console.log('AreaData1:', self.AreaData1);

                    var Data2 = [];
                    for (var i = 0; i < num_secondHalf.length; i++) {
                        var tmp_dict = {
                            num: num_secondHalf[i],
                            name: name_secondHalf[i]
                        };
                        Data2.push(tmp_dict);
                    }
                    self.AreaData2 = Data2;
                    // console.log('AreaData2:', self.AreaData2);
                })
                .catch((error) => {
                    console.log('GetArea error - ', error);
                });
        },
        async GetVisitor() {
            let self = this;
            console.log('GetVisitor');

            function search(params, data) {
                if ($.trim(params.term) === '') {
                    return data;
                }
                if (typeof data.text === 'undefined') {
                    return null;
                }
                if (data.text.indexOf(params.term) > -1) {
                    var modifiedData = $.extend({}, data, true);
                    modifiedData.text += ' (匹配)';
                    return modifiedData;
                }
                return null;
            }
            await axios.get('../API/GetAllVisitor')
                .then(response => {
                    // console.log('VisitorList:', response.data);

                    var options = [];
                    for (var i = 0; i < response.data.length; i++) {
                        var tmp_dict = {
                            text: response.data[i]['visitor_name'],
                            value: response.data[i]['visitor_name']
                        };
                        options.push(tmp_dict);
                    }
                    self.VisitorOptions = options
                })
                .catch((error) => {
                    console.log('GetVisitor error - ', error);
                });

            $('#VisitorFilter').select2({
                width: '100%',
                allowClear: true,
                closeOnSelect: true,
                dropdownAutoWidth: true,
                matcher: search
            });
        },
        UpdateVisitor() {
            console.log('Update Visitor');
        },
        CreateAllCountChart() {
            let self = this;
            var myAllCountChart = echarts.init(document.getElementById('AllCountChart'));
            myAllCountChart.setOption({
                grid: {
                    left: '5%',
                    right: '0%'
                },
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow',
                        shadowStyle: {
                            color: 'rgba(37, 129, 186, 0.1)'
                        }
                    },
                    valueFormatter: (value) => value + '人'
                },
                xAxis: [{
                    type: 'category',
                    data: self.AllCount.week_day,
                    axisTick: {
                        show: false,
                    },
                    splitLine: {
                        show: false,
                    },
                    axisLine: {
                        show: false,
                    },
                    axisLabel: {
                        color: '#959494',
                        fontSize: 14,
                        fontWeight: 600,
                        interval: 'auto',
                        width: 50,
                        overflow: 'truncate',
                        padding: [8, 0, 0, 0],
                        formatter: function (value) {
                            return value.split('-')[1] + '/' + value.split('-')[2]
                        }
                    },
                }],
                yAxis: [{
                    type: 'value',
                    name: '(人)',
                    nameTextStyle: {
                        color: '#959494',
                        fontSize: 12,
                        padding: [0, 0, 6, -60],
                    },
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#959494'
                        },
                        padding: 10
                    },
                }],
                series: [{
                    name: '總人數',
                    type: 'line',
                    symbol: 'circle',
                    symbolSize: 8,
                    emphasis: {
                        focus: 'series'
                    },
                    lineStyle: {
                        normal: {
                            width: 3,
                            color: '#2581BA'
                        },
                    },
                    itemStyle: {
                        color: '#2581BA'
                    },
                    label: {
                        normal: {
                            show: true,
                            position: "top",
                            formatter: function (data) {
                                return '{a0|' + data.value + '}';
                            },
                            rich: {
                                a0: {
                                    color: '#2581BA',
                                    fontSize: 16,
                                },
                            }
                        },
                    },
                    data: self.AllCount.data
                }]
            });
            window.addEventListener('resize', function () {
                myAllCountChart.resize();
            })
        },
        CreateAreaVisitorChart() {
            let self = this;
            var myLayoutCountChart = echarts.init(document.getElementById('LayoutCountChart'));
            if (self.AreaVisitor.avg.length == 0) {
                var list_avg = [];
                for (var i = 0; i < self.AreaVisitor.area.length; i++) {
                    list_avg.push(0);
                }
                self.AreaVisitor.avg = list_avg
            }
            if (self.AreaVisitor.max.length == 0) {
                var list_max = [];
                for (var i = 0; i < self.AreaVisitor.area.length; i++) {
                    list_max.push(0);
                }
                self.AreaVisitor.max = list_max
            }

            myLayoutCountChart.setOption({
                grid: {
                    left: '6%',
                    right: '6%',
                    top: '20%'
                },
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow',
                        shadowStyle: {
                            color: 'rgba(37, 129, 186, 0.1)'
                        }
                    },
                    formatter: function (datas) {
                        var res = "<b style='font-size:16px;'>" + datas[0].name + '</b><br/><br/>',
                            val;
                        for (var i = 0, length = datas.length; i < length; i++) {
                            if (datas[i].seriesName == "平均停留時間") {
                                res += datas[i].marker + ' ' + datas[i].seriesName + '：' + datas[i].value + '秒<br/>';
                            } else {
                                res += datas[i].marker + ' ' + datas[i].seriesName + '：' + datas[i].value + '人<br/>';
                            }
                        }
                        return res;
                    }
                },
                toolbox: {
                    right: '1%',
                    top: '0%',
                    feature: {
                        dataZoom: {
                            show: true,
                            readOnly: false,
                            title: '區域檢視',
                        },
                        myrestore: {
                            show: true,
                            title: '重置',
                            icon: 'path://M 25 2 A 1.0001 1.0001 0 1 0 25 4 C 36.609534 4 46 13.390466 46 25 C 46 36.609534 36.609534 46 25 46 C 13.390466 46 4 36.609534 4 25 C 4 18.307314 7.130711 12.364806 12 8.5195312 L 12 15 A 1.0001 1.0001 0 1 0 14 15 L 14 6.5507812 L 14 5 L 4 5 A 1.0001 1.0001 0 1 0 4 7 L 10.699219 7 C 5.4020866 11.214814 2 17.712204 2 25 C 2 37.690466 12.309534 48 25 48 C 37.690466 48 48 37.690466 48 25 C 48 12.309534 37.690466 2 25 2 z',
                            onclick: async () => {
                                $('#inputStartDate').val('');
                                $('#inputEndDate').val('');
                                await self.LoadAreaVisitorAllCountData();
                                await self.LoadAvgtimeVisitData();
                                var myLayoutCountChart = echarts.init(document.getElementById('LayoutCountChart'));
                                myLayoutCountChart.clear();
                                await self.CreateAreaVisitorChart();
                            }
                        },
                        dataView: {
                            show: true,
                            title: '詳細',
                            lang: ['詳細資料', '關閉', '更新'],
                            optionToContent: function (opt) {
                                var axisData = opt.xAxis[0].data;
                                var series = opt.series;
                                var tdHeads = '<td style="padding:10px 20px; font-size:18px;">展區名稱</td>';
                                series.forEach(function (item) {
                                    if (item.name == '最大人數') {
                                        item.name += ' (人)'
                                    } else if (item.name == '平均停留時間') {
                                        item.name += ' (秒)'
                                    }

                                    tdHeads += '<td style="padding: 10px 20px; font-size:18px;">' + item.name + '</td>';
                                });
                                var table = '<table border="1" style="margin-left:20px;border-collapse:collapse;font-size:14px;text-align:center"><tbody><tr>' + tdHeads + '</tr>';
                                var tdBodys = '';
                                for (var i = 0, l = axisData.length; i < l; i++) {
                                    for (var j = 0; j < series.length; j++) {
                                        if (typeof (series[j].data[i]) == 'object') {
                                            tdBodys += '<td>' + series[j].data[i].value + '</td>';
                                        } else {
                                            tdBodys += '<td>' + series[j].data[i] + '</td>';
                                        }
                                    }
                                    table += '<tr><td style="padding: 0 10px">' + axisData[i] + '</td>' + tdBodys + '</tr>';
                                    tdBodys = '';
                                }
                                table += '</tbody></table>';
                                return table;
                            }
                        },
                        magicType: {
                            type: ["line", "bar"]
                        },
                        myfile: {
                            show: true,
                            title: '下載檔案',
                            icon: 'path://M69.78,0.72C69.3,0.29,68.62,0,67.95,0c-0.14,0-0.29,0-0.43,0.05l-61.42,0c-1.64,0-3.19,0.68-4.3,1.79 C0.68,2.95,0,4.45,0,6.14v110.65c0,1.69,0.68,3.19,1.79,4.3c1.11,1.11,2.61,1.79,4.3,1.79c31.03,0,59.35,0,90.22,0 c1.69,0,3.19-0.68,4.3-1.79c1.11-1.11,1.79-2.61,1.79-4.3V35.52c0.05-0.24,0.1-0.43,0.1-0.68c0-0.82-0.39-1.55-0.92-2.08 L70.12,0.92c-0.1-0.1-0.15-0.14-0.24-0.19H69.78L69.78,0.72z M48.51,83.75V48.86c0-1.49,1.2-2.69,2.73-2.69 c1.49,0,2.73,1.2,2.73,2.69v34.86l12.52-10.93c1.11-0.98,2.82-0.89,3.8,0.22c0.98,1.11,0.89,2.79-0.22,3.77L53.05,91.64 c-1.05,0.92-2.6,0.89-3.61-0.03L32.45,76.77c-1.11-0.98-1.24-2.66-0.22-3.77c0.98-1.11,2.69-1.2,3.8-0.22l12.52,10.93L48.51,83.75 L48.51,83.75z M65.19,5.51v23.83c0,2.27,0.92,4.35,2.42,5.85c1.5,1.5,3.58,2.42,5.85,2.42h23.39v79.19c0,0.15-0.05,0.34-0.19,0.43 c-0.1,0.1-0.24,0.19-0.43,0.19c-24.57,0-66.28,0-90.18,0c-0.15,0-0.34-0.05-0.43-0.19c-0.1-0.1-0.19-0.29-0.19-0.43V6.14 c0-0.19,0.05-0.34,0.19-0.43c0.1-0.1,0.24-0.19,0.43-0.19h59.1H65.19L65.19,5.51z M70.65,29.34V9.38l22.47,22.76H73.45 c-0.77,0-1.45-0.34-1.98-0.82C70.99,30.83,70.65,30.11,70.65,29.34L70.65,29.34z',
                            onclick: async (opt) => {
                                Swal.fire({
                                    title: '下載檔案',
                                    icon: 'info',
                                    stopKeydownPropagation: false,
                                    html: '<div class="input-group mb-3">' +
                                        '<div class="input-group-prepend">' +
                                        '<span class="input-group-text">下載檔案格式</span>' +
                                        '</div>' +
                                        '<select class="form-control" id="file_type">' +
                                        '<option value="圖片(.jpeg)">圖片(.jpeg)</option>' +
                                        '<option value="表格(.csv)">表格(.csv)</option>' +
                                        '<option value="表格(.xlsx)">表格(.xlsx)</option>' +
                                        '</select>' +
                                        '</div>',
                                    showCloseButton: true,
                                    showCancelButton: true,
                                    focusConfirm: false,
                                    confirmButtonColor: '#2581BA',
                                    confirmButtonText: '<i class="fa fa-download"> 下載</i>',
                                    cancelButtonText: '<i class="fa fa-times"> 取消</i>',
                                }).then((result) => {
                                    if (result.isConfirmed) {
                                        var select_type = document.getElementById('file_type').value;
                                        // console.log('select_type:', select_type);
                                        if (select_type == '圖片(.jpeg)') {
                                            function saveDivAsImage(divId) {
                                                const element = document.getElementById(divId);
                                                html2canvas(element).then(canvas => {
                                                    const link = document.createElement('a');
                                                    link.download = '各展區人數及平均停留時間統計.jpeg';
                                                    link.href = canvas.toDataURL('image/jpeg', 1.0);
                                                    link.click();
                                                });
                                            }
                                            saveDivAsImage('LayoutCountChart');
                                        } else if (select_type == '表格(.csv)') {
                                            function CurrentTime() {
                                                var today = new Date();
                                                var day = today.getDate();
                                                var month = today.getMonth() + 1;
                                                var year = today.getFullYear();
                                                var hour = today.getHours();
                                                if (day < 10) day = "0" + day;
                                                if (month < 10) month = "0" + month;
                                                if (hour < 10) hour = "0" + hour;
                                                var minute = today.getMinutes();
                                                if (minute < 10) minute = "0" + minute;
                                                var second = today.getSeconds();
                                                if (second < 10) second = "0" + second;
                                                return year + "-" + month + "-" + day + " " + hour + "-" + minute + "-" + second;
                                            }

                                            function saveAsFileCSV(current_time) {
                                                var _headers = ['展區名稱', '最大人數(人)', '平均停留時間(秒)'];
                                                var csvData = new Array();
                                                csvData.push(_headers);
                                                for (i = 0; i < self.AreaVisitor.area.length; i++) {
                                                    csvData.push(new Array(self.AreaVisitor.area[i], self.AreaVisitor.max[i], self.AvgtimeVisitData[i]));
                                                }
                                                // console.log('csvData:', csvData);
                                                var lineArray = [];
                                                csvData.forEach(function (infoArray, index) {
                                                    var line = infoArray.join(",");
                                                    lineArray.push(index == 0 ? "\uFEFF" + line : line);
                                                });
                                                var csvContent = lineArray.join("\n");
                                                var blob = new Blob([csvContent], {
                                                    type: "text/csv;charset=utf-8;"
                                                });
                                                var link = document.createElement("a");

                                                if (link.download !== undefined) {
                                                    link.setAttribute("href", window.URL.createObjectURL(blob));
                                                    link.setAttribute("download", "展區參訪人數_" + current_time + ".csv");
                                                    link.setAttribute("hidden", true);
                                                } else {
                                                    link.setAttribute("href", "#");
                                                }
                                                link.click();
                                            }
                                            saveAsFileCSV(CurrentTime());
                                        } else if (select_type == '表格(.xlsx)') {
                                            function CurrentTime() {
                                                var today = new Date();
                                                var day = today.getDate();
                                                var month = today.getMonth() + 1;
                                                var year = today.getFullYear();
                                                var hour = today.getHours();
                                                if (day < 10) day = "0" + day;
                                                if (month < 10) month = "0" + month;
                                                if (hour < 10) hour = "0" + hour;
                                                var minute = today.getMinutes();
                                                if (minute < 10) minute = "0" + minute;
                                                var second = today.getSeconds();
                                                if (second < 10) second = "0" + second;
                                                return year + "-" + month + "-" + day + " " + hour + "-" + minute + "-" + second;
                                            }
                                            function saveAsFileXLSX(current_time) {
                                                var xdata = opt.option.xAxis[0].data;
                                                var ydata1 = opt.option.series[0].data;
                                                var ydata2 = opt.option.series[1].data;
                                                var workbook = XLSX.utils.book_new();        
                                                const worksheet_data  =  [xdata, ydata1, ydata2];
                                                const header = [['展區名稱', '最大人數(人)', '平均停留時間(秒)']];
                                                const trans_worksheet_data = worksheet_data[0].map((_, colIndex) => worksheet_data.map(row => row[colIndex]));
                                                const data = header.concat(trans_worksheet_data); 
                                                var worksheet = XLSX.utils.aoa_to_sheet(data);
                                                workbook.SheetNames.push("展區參訪人數_" + current_time);
                                                workbook.Sheets["展區參訪人數_" + current_time] = worksheet;
                                                XLSX.writeFile(workbook, "展區參訪人數_" + current_time + ".xlsx");
                                            }
                                            saveAsFileXLSX(CurrentTime());
                                        }
                                    }
                                })
                            }
                        }
                    },
                    iconStyle: {
                        borderColor: '#2581BA',
                        fontSize: '22px',
                    },
                },
                legend: {
                    bottom: "0%",
                    itemHeight: 15,
                    itemWidth: 25,
                    itemGap: 25,
                    padding: [0, 10],
                    textStyle: {
                        fontSize: 14,
                        color: "#959494",
                    },
                    data: [{
                            name: "平均人數",
                        },
                        {
                            name: "最大人數",
                        },
                        {
                            name: "平均停留時間",
                        }
                    ],
                },
                xAxis: [{
                    type: 'category',
                    data: self.AreaVisitor.area,
                    axisTick: {
                        show: false,
                    },
                    splitLine: {
                        show: false,
                    },
                    axisLine: {
                        show: false,
                    },
                    axisLabel: {
                        color: '#959494',
                        fontSize: 12,
                        fontWeight: 600,
                        interval: 0,
                        padding: [8, 0, 0, 0]
                    },
                }],
                yAxis: [{
                        type: 'value',
                        name: '人數 (人)',
                        min: 0,
                        max: 60,
                        // splitNumber: 6,
                        interval: 10,
                        nameTextStyle: {
                            color: "#2581BA",
                            fontSize: 12,
                            padding: [0, 0, 6, -50],
                        },
                        axisLabel: {
                            show: true,
                            textStyle: {
                                color: '#2581BA'
                            },
                            padding: 10,
                            formatter: function (value, index) {
                                return Math.round(value);
                            }
                        },
                        axisLine: {
                            lineStyle: {
                                color: '#fff'
                            }
                        }
                    },
                    {
                        type: 'value',
                        name: '時間(秒)',
                        min: 0,
                        max: 360,
                        // splitNumber: 6,
                        interval: 60,
                        nameTextStyle: {
                            color: "#82943D",
                            fontSize: 12,
                            padding: [0, 0, 6, 50],
                        },
                        axisLabel: {
                            show: true,
                            textStyle: {
                                color: '#82943D'
                            },
                            padding: 10,
                            formatter: function (value, index) {
                                return Math.round(value);
                            }
                        },
                        // splitLine: {
                        //     lineStyle: {
                        //         color: '#fff'
                        //     }
                        // },
                        axisLine: {
                            lineStyle: {
                                color: '#fff'
                            }
                        }
                    }
                ],
                series: [
                    // {
                    //     name: '平均人數',
                    //     type: 'bar',
                    //     yAxisIndex: "0",
                    //     emphasis: {
                    //         focus: 'series'
                    //     },
                    //     barWidth: 30,
                    //     itemStyle: {
                    //         color: '#2581BA'
                    //     },
                    //     label: {
                    //         normal: {
                    //             show: true,
                    //             position: "inside",
                    //             formatter: function (data) {
                    //                 return '{a0|' + data.value + '}';
                    //             },
                    //             rich: {
                    //                 a0: {
                    //                     color: '#ffffff',
                    //                     fontSize: 12
                    //                 },
                    //             }
                    //         },
                    //     },
                    //     data: self.AreaVisitor.avg
                    // },
                    {
                        name: '最大人數',
                        type: "bar",
                        yAxisIndex: "0",
                        symbol: "square",
                        symbolSize: 12,
                        color: "#2581BA",
                        lineStyle: {
                            normal: {
                                width: 2
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: '#2581BA',
                                borderWidth: 1,
                                borderColor: '#f3f3f3',
                            }
                        },
                        data: self.AreaVisitor.max,
                        label: {
                            normal: {
                                show: true,
                                position: "top",
                                color: '#2581BA',
                                fontSize: 14,
                                formatter: "{c}"
                            }
                        }
                    },
                    {
                        name: '平均停留時間',
                        type: "bar",
                        yAxisIndex: "1",
                        symbol: "diamond",
                        symbolSize: 12,
                        color: "#82943D",
                        lineStyle: {
                            normal: {
                                width: 2
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: '#82943D',
                                borderWidth: 1,
                                borderColor: '#f3f3f3',
                            }
                        },
                        data: self.AvgtimeVisitData,
                        label: {
                            normal: {
                                show: true,
                                position: "top",
                                color: '#82943D',
                                fontSize: 14,
                                formatter: "{c}"
                            }
                        }
                    }
                ]
            });
            window.addEventListener('resize', function () {
                myLayoutCountChart.resize();
            })
        },
        async WeekChange(event) {
            let self = this;
            var change_week = event.target.value;
            // console.log('change_week:', change_week);

            if (change_week === 'oneweek') {
                var myAllCountChart = echarts.init(document.getElementById('AllCountChart'));
                myAllCountChart.clear();
                myAllCountChart.showLoading({
                    text: ' Loading',
                    color: '#2581BA',
                    textColor: '#2581BA',
                    maskColor: 'rgba(37, 129, 186, 0.1)',
                    fontSize: 20,
                });
                await self.LoadAllCountOneWeekData();
                myAllCountChart.hideLoading();
                // console.log(self.AllCount.week_day);
                // console.log(self.AllCount.data);
            } else {
                var myAllCountChart = echarts.init(document.getElementById('AllCountChart'));
                myAllCountChart.clear();
                myAllCountChart.showLoading({
                    text: ' Loading',
                    color: '#2581BA',
                    textColor: '#2581BA',
                    maskColor: 'rgba(37, 129, 186, 0.1)',
                    fontSize: 20,
                });
                await self.LoadAllCountTwoWeekData();
                myAllCountChart.hideLoading();
                // console.log(self.AllCount.week_day);
                // console.log(self.AllCount.data);
            }

            var myAllCountChart = echarts.init(document.getElementById('AllCountChart'));
            myAllCountChart.clear()
            self.CreateAllCountChart();
        },
        async ChartSearch() {
            let self = this;
            console.log('SelectStartDate:', self.FilterData.SelectStartDate);
            console.log('SelectEndDate:', self.FilterData.SelectEndDate);
            console.log('SelectType:', self.FilterData.SelectType);
            console.log('SelectGoal:', self.FilterData.SelectGoal);

            var myAllCountChart = echarts.init(document.getElementById('AllCountChart'));
            myAllCountChart.clear();
            myAllCountChart.showLoading({
                text: ' Loading',
                color: '#2581BA',
                textColor: '#2581BA',
                maskColor: 'rgba(37, 129, 186, 0.1)',
                fontSize: 20,
            });
            await self.LoadAllCountFilterData();
            self.CreateAllCountChart();
            myAllCountChart.hideLoading();

            if (self.FilterData.SelectStartDate === null || self.FilterData.SelectStartDate === '' ||
                self.FilterData.SelectEndDate === null || self.FilterData.SelectEndDate === '') {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: '請輸入完整的時間區段'
                });
            } else {
                self.FilterData.SelectDate = self.FilterData.SelectStartDate + '_' + self.FilterData.SelectEndDate;

                if (self.FilterData.SelectDate === null || self.FilterData.SelectDate === '') {
                    if (self.FilterData.SelectType != 'all' || self.FilterData.SelectGoal != 'all') {
                        console.log('[1] SelectDate = null + SelectType != all + SelectGoal != all');
                        self.FilterData.SelectDate = '';
                        var filter_url = `../API/GetVisitorFilter?visit_type=${self.FilterData.SelectType}&visit_goal=${self.FilterData.SelectGoal}&visit_date=${self.FilterData.SelectDate}`
                        console.log('Search filter_url -1:', filter_url);
                        await axios.get(filter_url)
                            .then((res) => {
                                // console.log('GetVisitorFilter:', res.data);
                                var ChartSearchData = ''
                                for (var i = 0; i < res.data.length; i++) {
                                    var tmp = (res.data[i].visit_date).replaceAll('-', '/') + '&nbsp;&nbsp;&nbsp;' + res.data[i].visit_time + '&nbsp;&nbsp;&nbsp;' + res.data[i].visitor_name + '&nbsp;(' + res.data[i].visit_type + '/' + res.data[i].visit_goal + ')'
                                    if (i != res.data.length - 1) {
                                        tmp += '<br>'
                                    }
                                    ChartSearchData += tmp
                                }
                                self.ChartSearchData = ChartSearchData;
                                self.LoadAreaVisitorFilterCountData();
                                self.LoadAvgtimeVisitFilterCountData();
                            })
                            .catch((error) => {
                                console.log('ChartSearch -1:', error);
                            });
                    } else {
                        console.log('[2] SelectDate = null + SelectType = all + SelectGoal = all');

                        var myLayoutCountChart = echarts.init(document.getElementById('LayoutCountChart'));
                        myLayoutCountChart.clear();
                        myLayoutCountChart.showLoading({
                            text: ' Loading',
                            color: '#2581BA',
                            textColor: '#2581BA',
                            maskColor: 'rgba(37, 129, 186, 0.1)',
                            fontSize: 20,
                        });
                        await self.LoadAreaVisitorAllCountData();
                        await self.LoadAvgtimeVisitData();
                        self.CreateAreaVisitorChart();
                        myLayoutCountChart.hideLoading();
                        self.ChartSearchData = '';
                    }
                } else {
                    console.log('[3] SelectDate != null + SelectType != all + SelectGoal != all');
                    var filter_url = `../API/GetVisitorFilter?visit_type=${self.FilterData.SelectType}&visit_goal=${self.FilterData.SelectGoal}&visit_date=${self.FilterData.SelectDate}`
                    console.log('Search filter_url -3:', filter_url);
                    axios.get(filter_url)
                        .then((res) => {
                            // console.log('GetVisitorFilter:', res.data);
                            var ChartSearchData = ''
                            for (var i = 0; i < res.data.length; i++) {
                                var tmp = (res.data[i].visit_date).replaceAll('-', '/') + '&nbsp;&nbsp;&nbsp;' + res.data[i].visit_time + '&nbsp;&nbsp;&nbsp;' + res.data[i].visitor_name + '&nbsp;(' + res.data[i].visit_type + '/' + res.data[i].visit_goal + ')'
                                if (i != res.data.length - 1) {
                                    tmp += '<br>'
                                }
                                ChartSearchData += tmp
                            }
                            self.ChartSearchData = ChartSearchData;
                        })
                        .catch((error) => {
                            console.log('ChartSearch -3:', error);
                        });

                    var myLayoutCountChart = echarts.init(document.getElementById('LayoutCountChart'));
                    myLayoutCountChart.clear();
                    myLayoutCountChart.showLoading({
                        text: ' Loading',
                        color: '#2581BA',
                        textColor: '#2581BA',
                        maskColor: 'rgba(37, 129, 186, 0.1)',
                        fontSize: 20,
                    });
                    await self.LoadAreaVisitorFilterCountData();
                    await self.LoadAvgtimeVisitFilterCountData();
                    self.CreateAreaVisitorChart();
                    myLayoutCountChart.hideLoading();
                }
            }
        }
    }
});