import datetime
from django.db import models

class Heatmap_mainlist(models.Model):
    id = models.AutoField(primary_key=True)
    all_count = models.CharField(max_length=45, blank=True)
    acc_count = models.CharField(max_length=45, blank=True)
    data = models.TextField(blank=True)
    insert_time = models.DateTimeField(auto_now_add=datetime.datetime.now().replace(microsecond=0))    

    class Meta(object):
        db_table = "heatmap_mainlist"


class AreaVisitor_mainlist(models.Model):
    id = models.AutoField(primary_key=True)
    area = models.TextField(blank=True)
    count = models.TextField(blank=True)
    insert_time = models.DateTimeField(auto_now_add=datetime.datetime.now().replace(microsecond=0))    

    class Meta(object):
        db_table = "areavisitor_mainlist"


class Area_mainlist(models.Model):
    id = models.AutoField(primary_key=True)
    area_num = models.CharField(max_length=45, blank=True)
    area_name = models.TextField(blank=True)
    insert_time = models.DateTimeField(auto_now_add=datetime.datetime.now().replace(microsecond=0))    

    class Meta(object):
        db_table = "area_mainlist"


class Visitor_mainlist(models.Model):
    id = models.AutoField(primary_key=True)
    visitor_name = models.TextField(blank=True)
    visit_type = models.TextField(blank=True)
    visit_goal = models.TextField(blank=True)
    visit_date = models.TextField(blank=True)
    visit_time = models.TextField(blank=True)
    insert_time = models.DateTimeField(auto_now_add=datetime.datetime.now().replace(microsecond=0))    

    class Meta(object):
        db_table = "visitor_mainlist"


class Avgtime_mainlist(models.Model):
    id = models.AutoField(primary_key=True)
    noid = models.TextField(blank=True)
    time_in = models.TextField(blank=True)
    time_out = models.TextField(blank=True)
    duration = models.TextField(blank=True)
    insert_time = models.DateTimeField(auto_now_add=datetime.datetime.now().replace(microsecond=0))    

    class Meta(object):
        db_table = "avgtime_mainlist"


class Administer_mainlist(models.Model):
    id = models.AutoField(primary_key=True)
    dept = models.CharField(max_length=45, blank=True)
    userid = models.CharField(max_length=45, blank=True)
    name = models.CharField(max_length=45, blank=True)
    insert_time = models.DateTimeField(auto_now_add=datetime.datetime.now().replace(microsecond=0))    

    class Meta(object):
        db_table = "administer_mainlist"