from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt


@ csrf_exempt
def Admin(request):
    return render(request, 'Admin.html')


@ csrf_exempt
def Area(request):
    return render(request, 'Area.html')


@ csrf_exempt
def Visitor(request):
    return render(request, 'Visitor.html')


@ csrf_exempt
def Live(request):
    return render(request, 'Live.html')