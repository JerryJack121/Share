import requests
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from django.contrib import auth

@ csrf_exempt
def Login(request):
    if request.method == 'POST':
        if (request.POST.get('action') == 'user_login'):
            login_username = request.POST.get('login_username')
            login_password = request.POST.get('login_password')

            # if User.objects.filter().exists():

            # print(login_username, '/', login_password)
            user = auth.authenticate(username=login_username, password=login_password)
            # login_url = 'http://autcpmoweb01.corpnet.auo.com/api/UACAccount/UACLogin'
            # login_api = requests.post(login_url,json={"username":login_username,"password":login_password})
            # login_response = login_api.json()
            # print('login_response:', login_response)

            # print(login_response['authkey'])

            # check_url = 'http://autcpmoweb01.corpnet.auo.com/api/UACAccount/CheckAuthToken'
            # check_api = requests.post(check_url,json={"authorityKey":login_response['authkey']})
            # check_response = check_api.json()
            # print('check_response:', check_response)

            # userid = check_response['userid']
            # deptno = check_response['deptno']

            # ========== 模擬登入 ==========
            # if (userid == '2008041'):
            #     userid = '0608114'
            #     deptno = 'MAMBB1'
            #     print('模擬登入:', userid, '/', deptno)
            # else:
            #     print(userid, deptno)
            # ========== 模擬登入 ==========

            # 管理員白名單
            # administer = []
            if user is not None and user.is_active:
                res = JsonResponse({
                    'rtnMessage': 'Pass',
                    'rtnCode': 'Pass',
                    'name': login_username,
                    'userid': login_username,
                })
            else:
                res = JsonResponse({
                    'rtnMessage': 'NoAuth'
                })                
                # resp
            try:
                response = ''
                response = res
                # response = JsonResponse({'rtnMessage': login_response['rtnMessage'],
                #                         'rtnCode': check_response['rtnCode'],
                #                         'deptname': check_response['deptname'],
                #                         'deptno': deptno,
                #                         'name': check_response['name'],
                #                         'userid': userid,
                #                         'alias': check_response['alias'],
                #                         'tel': check_response['tel'],
                #                         'location': check_response['location'],
                #                         'authorityKey': login_response['authkey']})

                # ========== 測試用 ==========
                # response = JsonResponse({'rtnMessage': 'UAC-000: 通過(tcuac01)',
                #                         'rtnCode': 'Pass',
                #                         'deptname': '智慧製造技術二課',
                #                         'deptno': 'MAMCA2',
                #                         'name': '邱靖詒',
                #                         'userid': '2008041',
                #                         'alias': 'jennycychiu',
                #                         'tel': '86-567614',
                #                         'location': 'L8A'})
                # ========== 測試用 ==========

                return response

            except Exception as e:
                print(e)
                pass

    return render(request, 'Login.html')
