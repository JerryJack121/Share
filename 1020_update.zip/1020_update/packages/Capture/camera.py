import cv2
import threading
import time
import os


class PylonCamera:
    def __init__(self, width, height, exposureTime, gamma) -> None:
        from pypylon import pylon

        ### 初始化相機
        self.__set_cam(width, height, exposureTime, gamma)
        self.__set_converter()
        self.camThread = threading.Thread(target=self.__capture_thread)

        ### 初始化變數
        self.frame = None
        self.camSwitch = True  # 相機開關

    def __set_cam(self, width, height, exposureTime, gamma):
        self.camera = pylon.InstantCamera(pylon.TlFactory.GetInstance().CreateFirstDevice())
        self.camera.Open()
        self.camera.Height.SetValue(height)  # 2048
        self.camera.Width.SetValue(width)  # 2448

        # Grabing Continusely (video) with minimal delay
        self.camera.StartGrabbing(pylon.GrabStrategy_LatestImageOnly)

        # 曝光時間設定
        self.camera.ExposureTime.SetValue(exposureTime)
        self.camera.Gamma.SetValue(gamma)

    def __set_converter(self):
        self.converter = pylon.ImageFormatConverter()
        # converting to opencv bgr format
        self.converter.OutputPixelFormat = pylon.PixelType_BGR8packed
        self.converter.OutputBitAlignment = pylon.OutputBitAlignment_MsbAligned

    def __capture_thread(self):
        while self.camera.IsGrabbing():
            grabResult = self.camera.RetrieveResult(1000, pylon.TimeoutHandling_ThrowException)
            if grabResult.GrabSucceeded():
                self.frame = self.__convert_to_img(grabResult)
            grabResult.Release()

            if not self.camSwitch:
                # Releasing the resource
                self.camera.StopGrabbing()

            time.sleep(0.1)

    def __convert_to_img(self, grabResult):
        img = self.converter.Convert(grabResult)
        img = img.GetArray()
        return img

    def start_capture(self):
        self.camThread.start()

    def stop_capture(self):
        self.camSwitch = False

    def get_frame(self):
        return self.frame

    def get_current_frame(self):
        return self.frame


class Cam:
    def __init__(self, camPath=0):
        self.camPath = camPath
        self.capture = cv2.VideoCapture(self.camPath)
        width = self.capture.get(cv2.CAP_PROP_FRAME_WIDTH)
        height = self.capture.get(cv2.CAP_PROP_FRAME_HEIGHT)
        fps = self.capture.get(cv2.CAP_PROP_FRAME_COUNT)

        self.frame = None
        self.camThread = threading.Thread(target=self.__cam_read)
        self.camThread.start()

    def __cam_read(self):
        ret = self.capture.isOpened()
        if not ret:
            print("Load video error!")
            os._exit(0)

        isNoFrame = False
        noFrameCnt = 0
        while True:
            ret, self.frame = self.capture.read()
            if not ret:
                noFrameCnt += 1

                ### 記錄影像串流異常
                if not isNoFrame:
                    print("攝影機異常!")
                    isNoFrame = True

                ### 重啟攝影機
                if noFrameCnt > 100:
                    self.capture.release()
                    self.capture = cv2.VideoCapture(self.camPath)
                    print("攝影機嘗試重連!")
                    noFrameCnt = 0

                ### 輸出無信號影像
                else:
                    self.frame = None

    def get_frame(self):
        return self.frame

    def get_current_frame(self):
        return self.frame
