import os
import sys
import torch
from torch.utils.data import DataLoader
import math
import cv2
import numpy as np


os.environ["CUDA_VISIBLE_DEVICES"] = "3"
sys.path.append("./")

from packages.facelib.AgeGender.models.train import myDataset, tf, MultitaskDataset
from packages.facelib.AgeGender.models.model import ShuffleneFull
from packages.facelib.AgeGender.models.model import accuracy_gender, l1loss_age


def valid_model(model, testDataLoader):
    model.eval()
    N = len(testDataLoader.dataset)
    step = math.ceil(N / testDataLoader.batch_size)
    acc_gender = 0.0
    loss_age = 0.0

    with torch.no_grad():
        for i, (x, y) in enumerate(testDataLoader):
            x, y = x.cuda(), y.cuda()
            pred = model(x)

            acc_gender += accuracy_gender(pred, y)
            loss_age += l1loss_age(pred, y)

    return torch.tensor([acc_gender / N, loss_age / step])


if __name__ == "__main__":
    testDataset = myDataset(
        r"D:\Users\YjChou\Smart Retail\age_gender_data\dataset\age_gender\exp\0906_0912_0914_0915\test",
        tfms=tf["test"],
    )

    ### UTKFace 資料集
    # data = np.load(r"packages\facelib\AgeGender\weights\data.npy", allow_pickle=True)
    # testData = data[data[:, -1] == 0]
    # testDataset = MultitaskDataset(
    #     data=testData,
    #     tfms=tf["test"],
    #     root=r"D:\Users\YjChou\Smart Retail\age_gender_data\dataset\age_gender\UTKFace\UTKFace",
    # )

    testDataLoader = DataLoader(testDataset, batch_size=256 * 4, shuffle=False, num_workers=0)

    weight = r"D:\Users\YjChou\Smart Retail\age_gender_data\model\0918_v1.1.pth"
    model = ShuffleneFull().cuda()
    model.load_state_dict(torch.load(weight))
    acc_gender, loss_age = valid_model(model, testDataLoader)
    print("acc_gender: {:.3f}, loss_age: {:.3f}".format(acc_gender, loss_age))
