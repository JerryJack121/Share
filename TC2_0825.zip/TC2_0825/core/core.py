import cv2
import time
import numpy as np
from packages.facelib import FaceDetector, AgeGenderEstimator, special_draw
from packages.Capture import webCam, VideoLoader
from utils.Tracker import FaceTracker
from utils.Result import Summary, Record
from utils.Config import Config
from utils import Draw
from utils.Analyze import Analyzer


def run(mode, source):
    ##############################################
    ###            初始化
    ##############################################
    config = Config()
    COLUMNS = ["進入時間", "離開時間", "性別", "年齡", "刷餐時間", "餐點", "工號"]

    ### Capture
    if mode == "webcam":
        capture = webCam(source)
    elif mode == "video":
        capture = VideoLoader(source, fps=30)

    ### 顧客輪廓辨識初始化
    detector = Detector(config.fence.data, config.fence.minBox)
    record = Record(config.data.outputFolder, COLUMNS)

    ### 辨識結果與刷餐紀錄匹配
    analyzer = Analyzer(config.data.outputFolder, COLUMNS)
    analyzer.start(
        url=config.dataMall.url,
        dataMallCsvFolderPath=config.dataMall.csvFolderPath,
        dataMallRawDataFolderPath=config.dataMall.rawDataFolderPath,
    )

    ##############################################
    ###            主流程
    ##############################################
    while True:
        t1 = time.time()
        frame = capture.get_frame()
        if frame is None:
            break

        faceClsList, customerDict, inIdList, outIdList = detector.detect(frame)
        record.update(customerDict, outIdList)  # 將辨識結果寫入 csv

        ##############################################
        ###            Terminal
        ##############################################
        ### 結帳區顧客資訊
        for inId in inIdList:
            print(f"顧客編號: {inId}, 結帳中...")
        for outId in outIdList:
            customerCls = customerDict[outId]
            timeIn = customerCls.timeIn.strftime("%Y/%m/%d %H:%M:%S")
            timeOut = customerCls.timeOut.strftime("%Y/%m/%d %H:%M:%S")
            print(f"顧客編號:  {outId}, 性別: {customerCls.gender}, 年齡: {customerCls.age}\n進入時間: {timeIn}, 離開時間 {timeOut}\n")

        ##############################################
        ###            Visualize
        ##############################################
        ### 畫結帳區
        resImg = Draw.draw_fence(frame, config.fence.data)
        ### 畫臉部框
        resImg = Draw.draw_face(resImg, faceClsList, customerDict, stable=True)

        ### 比較穩定輸出結果功能
        if False:
            resImg1 = Draw.draw_face(resImg, faceClsList, stable=False)
            resImg2 = Draw.draw_face(resImg, faceClsList, stable=True)
            resImg = np.hstack((resImg1, resImg2))

        w, h = resImg.shape[1], resImg.shape[0]
        resImgShow = cv2.resize(resImg, (w // 2, h // 2))
        cv2.imshow("result", resImgShow)
        cv2.waitKey(1)

        t2 = time.time()
        # print("fps: {:.1f}".format(1 / (t2 - t1)))


class Detector:
    def __init__(self, fenceData, minBox=0):
        maxDisappeared = 10  # ID 追蹤可允許的消失幀數
        self.faceDetectorCls = FaceDetector()
        self.ageGenderDetectorCls = AgeGenderEstimator()
        self.faceTrackerCls = FaceTracker(maxDisappeared)
        self.resultCls = Summary(fenceData, maxDisappeared=0)
        self.minBox = minBox

    def detect(self, img):
        faces, boxList, scoreList, _ = self.faceDetectorCls.detect_align(img)  # 偵測臉

        ### 預測年齡性別
        if len(faces.shape) > 1:
            genderList, ageList = self.ageGenderDetectorCls.detect(faces)

            ### torch to python
            faces = faces.cpu().numpy().tolist()
            boxList = boxList.cpu().numpy().tolist()
            scoreList = scoreList.cpu().numpy()[:, 0].tolist()

            ### 臉部追蹤
            idList = self.faceTrackerCls.update(boxList)

            ### 整合臉部與輪廓資訊
            faceClsList = self.resultCls.get_face_info(idList, boxList, scoreList, genderList, ageList)

            ### 篩選出結帳區內最大的目標
            faceInRegionIdList = self.resultCls.get_face_in_region(faceClsList, self.minBox, maxOnly=True)

            ### 整合客戶資訊
            customerDict, inIdList, outIdList = self.resultCls.get_customer_info(faceInRegionIdList)

        else:
            ### torch to python
            boxList = boxList.cpu().numpy().tolist()
            idList = self.faceTrackerCls.update(boxList)
            faceClsList, inIdList, outIdList = list(), list(), list()
            customerDict = dict()

        return faceClsList, customerDict, inIdList, outIdList
