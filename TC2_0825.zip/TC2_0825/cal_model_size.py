import torch
from thop import profile


### RetinaFace
# from packages.facelib.Retinaface.utils.config import cfg_mnet, cfg_re50
# from packages.facelib.Retinaface.models.retinaface import RetinaFace

# cfg = cfg_mnet
# model = RetinaFace(cfg=cfg, phase="test")
# input = torch.randn(1, 3, 640, 640)


## Shufflenet
from packages.facelib.AgeGender.models.model import ShuffleneTiny, ShuffleneFull

model = ShuffleneFull()
input = torch.randn(1, 3, 112, 112)

flops, params = profile(model, inputs=(input,))
print("{:<30}  {:<8} G".format("flops: ", flops / 1e9))
print("{:<30}  {:<8} M".format("Number of parameters: ", params / 1e6))
