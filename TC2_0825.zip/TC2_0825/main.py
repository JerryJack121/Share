from core import core


mode = "webcam"

if mode == "webcam":
    source = 0
    source = "rtsp://admin:Auo+84149738@192.168.0.101:7070/stream"
elif mode == "video":
    source = "./data/videos/WIN_20230816_09_56_36_Pro.mp4"

core.run(mode, source)
