import requests
import pandas as pd
import datetime
import os

RAW_COLUMNS = [
    "FAB",
    "STAGE",
    "工號",
    "EMP_TYPE",
    "JOB_ID",
    "部門",
    "姓名",
    "刷餐廠區",
    "用餐時間",
    "商店",
    "餐點",
    "卡路里",
    "卡路里等級",
    "餐點類別",
]
COLUMNS = ["用餐時間", "餐點", "商店", "工號"]


class DataMall:
    def __init__(self, url, csvFolderPath, rawDataFolderPath=None):
        self.url = url
        self.csvFolderPath = csvFolderPath
        self.rawDataFolderPath = rawDataFolderPath

    def get_data(self):
        data = requests.get(self.url).json()
        rawData = data["1"]
        isNew, data = self.__save_csv(rawData)
        return isNew, data

    def __save_csv(self, rawDataDict):
        rawDataFrame = pd.DataFrame(rawDataDict)
        ### FIXME: yjchou 2023/08/22 在資料還沒更新前取到的舊資料, 日期要再減一天
        date = datetime.date.today() - datetime.timedelta(days=1)
        filePath = os.path.join(self.csvFolderPath, f"{date}.csv")
        rawFilePath = os.path.join(self.rawDataFolderPath, f"{date}.csv")

        ### 篩選出希望綠豆湯的資料
        df = rawDataFrame.loc[rawDataFrame["商店"] == "甜上心"]  ### "希望綠豆湯"在資料中為"甜上心"

        ### 按時間排序
        df = df.sort_values(by=["用餐時間"])

        ### 篩選欄位
        df = df[COLUMNS]

        ### 判斷是否已建檔
        if os.path.isfile(filePath):
            ### 先依照格式輸出暫存再載入
            df.to_csv("temp.csv", encoding="utf_8_sig", index=False, columns=COLUMNS)
            df = pd.read_csv("temp.csv")
            os.remove("temp.csv")

            ### 讀取現有檔案
            existDf = pd.read_csv(filePath)

            ### 判斷兩個 csv 是否完全相同
            if df.equals(existDf):
                print("Same data already exist!")
                return False, None

            ### 有相同檔名但內容不同的檔案
            else:
                print("Data is different but file exist")
                addText = "(1)"
        else:
            addText = ""

        ### Save csv
        os.makedirs(self.csvFolderPath, exist_ok=True)
        filePath = os.path.join(self.csvFolderPath, f"{date}{addText}.csv")
        rawFilePath = os.path.join(self.rawDataFolderPath, f"{date}{addText}.csv")
        df.to_csv(filePath, encoding="utf_8_sig", index=False, columns=COLUMNS)
        print(f"Save {filePath} success!")
        if self.rawDataFolderPath is not None:
            os.makedirs(self.rawDataFolderPath, exist_ok=True)
            rawDataFrame.to_csv(rawFilePath, encoding="utf_8_sig", index=False, columns=RAW_COLUMNS)
            print(f"Save {rawFilePath} success!")
        return True, df


if __name__ == "__main__":
    dataMallApi = DataMall(
        url="http://10.88.19.94:8005/api/datamall/eyJrZXkiOiAiNzg3NjVhNzUxNmVjOWU1MjYyNDMwZmZkMjRhN2VhYjMiLCAiaWQiOiAiMjAyMzA3MDUwODIwMzU3MDQ2MyJ9",
        csvFolderPath=r"data\csv\data_mall\data",
        rawDataFolderPath=r"data\csv\data_mall\raw_data",
    )
    isNew, data = dataMallApi.get_data()
