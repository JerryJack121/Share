from configparser import ConfigParser
from packages import FileManager


class Config:
    def __init__(self) -> None:
        config = ConfigParser()

        class Fence:
            def __init__(self, cfgFilePath):
                data = FileManager.load_json(cfgFilePath)
                self.data = data["data"]
                self.minBox = int(data["minBox"])

        class DataMall:
            def __init__(self, cfgFilePath):
                config.read(cfgFilePath, encoding="utf-8")
                self.url = config.get("api", "url")
                self.csvFolderPath = config.get("output", "csvFolderPath")
                self.rawDataFolderPath = config.get("output", "rawDataFolderPath")
                config.clear()

        class Data:
            def __init__(self, cfgFilePath):
                config.read(cfgFilePath, encoding="utf-8")
                self.outputFolder = config.get("output", "outputFolder")
                config.clear()

        self.fence = Fence(r"data\config\fence.json")
        self.dataMall = DataMall(r"data\config\data_mall.cfg")
        self.data = Data(r"data\config\data.cfg")
