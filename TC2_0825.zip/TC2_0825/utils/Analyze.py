import threading
import schedule
import datetime
import os
import pandas as pd
import time
import sys

sys.path.append("./")
from server.Api import DataMall


class Analyzer:
    """辨識結果與刷餐紀錄匹配"""

    def __init__(self, outputFolderPath, header):
        self.outputFolderPath = outputFolderPath
        self.header = header

    def start(self, url, dataMallCsvFolderPath, dataMallRawDataFolderPath):
        ### 刷餐記錄串接 API
        self.dataMallApi = DataMall(
            url=url,
            csvFolderPath=dataMallCsvFolderPath,
            rawDataFolderPath=dataMallRawDataFolderPath,
        )

        ### 先嘗試取得資料一次
        self.get()

        ### 設定排程取得新資料
        schedule.every().day.at("09:00").do(self.get)
        checkThread = threading.Thread(target=self.__check_sechedule)
        checkThread.start()
        print("開始定時撈 DataMall 資料")

    def manual(self, filePath):
        df = pd.read_csv(filePath, encoding="utf_8_sig")
        self.__match(df)

    def get(self):
        ### 確認有無新資料
        isNew, df = self.dataMallApi.get_data()
        if isNew:
            ### 與識結果匹配
            self.__match(df)

    def __check_sechedule(self):
        while True:
            schedule.run_pending()
            time.sleep(60)

    def __match(self, df):
        """與識結果匹配

        Args:
            df (_type_): _description_
        """
        ### 確認有資料
        if df.shape[0] > 0:
            currentMatchDate, aiResultDf = None, None  # 當前正在匹配的日期
            for _, row in df.iterrows():
                payTimeFormat, meal, id = row["用餐時間"], row["餐點"], row["工號"]
                payTime = str2time(payTimeFormat)
                payDate = payTime.date()

                ### 若是新的刷餐日期, 寫入匹配完的結果, 再重新載入新日期對應的辨識結果
                if payDate != currentMatchDate:
                    ### 輸出 csv
                    if aiResultDf is not None:
                        aiResultDf.to_csv(aiResultFilePath, encoding="utf_8_sig", index=False, columns=COLUMNS)

                    aiResultFileName = "{}.csv".format(datetime.datetime.strftime(payDate, "%Y-%m-%d"))
                    aiResultFilePath = os.path.join(self.outputFolderPath, aiResultFileName)
                    ### 確認 AI 辨識結果存在並載入資料
                    if os.path.isfile(aiResultFilePath):
                        aiResultDf = pd.read_csv(aiResultFilePath, encoding="utf_8_sig")

                    else:
                        aiResultDf = None

                # 逐筆匹配, 因刷餐紀錄與辨識結果皆按時間排序, 所以匹配失敗的不再重複匹配
                if aiResultDf is not None:
                    idx, matchIdx = 0, None
                    while idx <= aiResultDf.shape[0] - 1:
                        aiRow = aiResultDf.iloc[idx, :]
                        inTime, outTime = aiRow["進入時間"], aiRow["離開時間"]
                        inTime, outTime = str2time(inTime), str2time(outTime)
                        if payTime > inTime:
                            if in_time_interval(payTime, inTime, outTime):
                                matchIdx = idx
                                break
                            else:
                                idx += 1
                        ### 匹配失敗
                        else:
                            break

                    ### 匹配結果寫入 dataframe
                    if matchIdx is not None:
                        aiResultDf.loc[matchIdx, "刷餐時間"] = payTime
                        aiResultDf.loc[matchIdx, "餐點"] = meal
                        aiResultDf.loc[matchIdx, "工號"] = id
                        print(aiResultDf)


def in_time_interval(time, inTime, outTime):
    """判斷是否在時間區段內

    Args:
        time (_type_): _description_
        inTime (_type_): _description_
        outTime (_type_): _description_

    Returns:
        _type_: _description_
    """
    if time >= inTime and time <= outTime:
        return True
    else:
        return False


def str2time(str):
    str = str.split(".")[0]  # 移除秒數後的小數點
    time = datetime.datetime.strptime(str, "%Y-%m-%d %H:%M:%S")
    return time


if __name__ == "__main__":
    from utils.Config import Config

    COLUMNS = ["進入時間", "離開時間", "性別", "年齡", "刷餐時間", "餐點", "工號"]

    config = Config()
    analyzer = Analyzer(config.data.outputFolder, COLUMNS)
    analyzer.start(
        url=config.dataMall.url,
        dataMallCsvFolderPath=config.dataMall.csvFolderPath,
        dataMallRawDataFolderPath=config.dataMall.rawDataFolderPath,
    )

    # analyzer.manual(r"data\csv\data_mall\data\2023-08-16.csv")
