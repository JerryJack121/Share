class StreamData:
    streamImg = None
