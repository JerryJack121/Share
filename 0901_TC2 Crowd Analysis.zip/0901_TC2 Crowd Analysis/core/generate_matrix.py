import cv2
import numpy as np
import sys
import os

sys.path.append("./")
from packages.Calibrate import DistortionCorrection, AffineTransform


##############################################
###             魚眼畸變校正
##############################################
def save_distortion_matrix(imgPath, matrixSavePath, matrixName, resultImgPath=None, visualize=True):
    """取得畸變校正(經緯度變換)矩陣 (相同尺寸的攝影機可共用轉換矩陣)

    Args:
        imgPath (str): 原圖檔案路徑
        matrixSavePath (str): 矩陣儲存資料夾路徑
        matrixName (str): 矩陣名稱
        resultImgPath (str, optional): 結果圖輸出檔案路徑. Defaults to None.
        visualize (bool, optional): 結果圖可視化. Defaults to True.
    """
    img = cv2.imread(imgPath)

    ### 經緯度校正
    finalMapx, finalMapy, resImg = DistortionCorrection.get_matrix(img, mode=3, visualize=visualize)

    ### save matrix
    os.makedirs(matrixSavePath, exist_ok=True)
    np.save(os.path.join(matrixSavePath, f"{matrixName}_mapx.npy"), finalMapx)
    np.save(os.path.join(matrixSavePath, f"{matrixName}_mapy.npy"), finalMapy)
    print(f"Save matrix to '{os.path.join(matrixSavePath)}'")

    ### save result img
    if resultImgPath is not None:
        cv2.imwrite(resultImgPath, resImg)


##############################################
###             仿射變換
##############################################
def save_one_affine_matrix(srcPts, targetPts, matrixSavePath, matrixName):
    """取得仿射變換矩陣

    Args:
        srcPts (list):  3個原圖參考座標 [(x1,y1), (x2,y2), (x3,y3)]
        targetPts (list): 對應到仿射變換後的3個座標 [(x1',y1'), (x2',y2'), (x3',y3')]
        matrixSavePath (str): 矩陣儲存資料夾路徑
        matrixName (str): 矩陣名稱
    """
    affineMatrix = AffineTransform.get_matrix(srcPts, targetPts)

    ### save matrix
    os.makedirs(matrixSavePath, exist_ok=True)
    matrixFileName = f"{matrixName}.npy"
    np.save(os.path.join(matrixSavePath, matrixFileName), affineMatrix)
    print(f"Save {matrixFileName} to '{os.path.join(matrixSavePath)}'")


def save_all_affin_matrixs(srcList, targetList, matrixSavePath):
    """取得多個仿射變換矩陣 (src 與 target 的順序必須一致)

    Args:
        srcList (list): 原圖參考座標
        targetList (list): 對應到仿射變換後座標 (圖片尺寸為 layout 指定區域的大小)
        matrixSavePath (str): 矩陣儲存資料夾路徑
    """
    for i in range(len(srcList)):
        srcPts = np.float32((srcList[i]["Point"]))
        targetPts = np.float32(targetList[i]["Point"])
        camId = srcList[i]["camId"]

        save_one_affine_matrix(
            srcPts,
            targetPts,
            matrixSavePath=matrixSavePath,
            matrixName=f"cam{camId}_affine_matrix",
        )
