import os
from configparser import ConfigParser


class Magic:
    def __init__(self, cfgFilePath):
        self.magicFilePath = cfgFilePath
        statinfo = os.stat(self.magicFilePath)  # 上次修改時間
        self.lastModifyTime = statinfo.st_mtime

    def is_modify(self):
        statinfo = os.stat(self.magicFilePath)  # 上次修改時間
        modifyTime = statinfo.st_mtime
        if modifyTime != self.lastModifyTime:
            try:
                self.lastModifyTime = modifyTime
                cnt = self.__read_config()
            except:
                ### 避免TYPO
                cnt = None
        else:
            cnt = None
        return cnt

    def __read_config(self):
        config = ConfigParser()
        config.read(self.magicFilePath)
        cnt = config.get("Magic", "Cnt")
        return int(cnt)
