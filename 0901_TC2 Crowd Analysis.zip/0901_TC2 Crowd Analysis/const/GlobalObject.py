class Project:
    Sidadun = 0
    TC2Showroom = 1
    ATC = 2
    TC2 = 2  # TC2 員工餐廳


class StreamData:
    streamImg = None


class Global:
    dailyResetFlag = False
