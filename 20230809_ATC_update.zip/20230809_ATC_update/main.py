from core.core import run
from core.generate_matrix import save_distortion_matrix, save_all_affin_matrixs
from const.GlobalObject import Project


mode = "detect"  # mode: detect/get_matrix

### REVIEW:
### 人流辨識主程式
if mode == "detect":
    run(project=Project.ATC)

### 每個專案只需產生一次轉移矩陣, 儲存後可重複使用
elif mode == "get_matrix":
    ##########################################
    ##     畸變校正 (各專案共用)
    ##########################################
    save_distortion_matrix(
        imgPath=r"data\calibrate\fisheye\atc\3.jpg",
        matrixSavePath=r"data\calibrate\matrix\distortion_tmp",
        matrixName="distortion_corr_matix",
        resultImgPath="./distortion_correction_tmp.jpg",
        visualize=False,
    )

    # ###########################################
    # ###       仿射變換 (For SiDaDun)
    # ###########################################
    # ### 畸變校正後的圖片尺寸 (2160*2160)
    # srcList = [
    #     {"camId": "1", "Point": [(803, 1615), (801, 502), (1387, 1619)]},
    #     {"camId": "2", "Point": [(245, 404), (1773, 535), (1762, 1340)]},
    #     {"camId": "3_1", "Point": [(105, 814), (223, 535), (1704, 763)]},
    #     {"camId": "3_2", "Point": [(234, 1055), (1916, 1068), (1867, 1710)]},
    # ]

    # ### Layout的圖片尺寸 (1044*822)
    # targetList = [
    #     {"camId": "1", "Point": [(0, 435), (0, 0), (196, 435)]},
    #     {"camId": "2", "Point": [(0, 0), (752, 0), (752, 339)]},
    #     {"camId": "3_1", "Point": [(0, 175), (0, 0), (762, 175)]},
    #     {"camId": "3_2", "Point": [(0, 0), (1007, 0), (960, 251)]},
    # ]
    # save_all_affin_matrixs(srcList, targetList, matrixSavePath=r"data\calibrate\matrix\affine_tmp")

    # ###########################################
    # ###      仿射變換 (For Showroom)
    # ###########################################
    # ### 畸變校正後的圖片尺寸 (2160*2160)
    # srcList = [
    #     {"camId": "1", "Point": [(335, 350), (1650, 350), (1650, 1460)]},
    # ]
    # ### Layout的圖片尺寸 (1044*822)
    # targetList = [
    #     {"camId": "1", "Point": [(624, 18), (624, 804), (0, 804)]},
    # ]
    # save_all_affin_matrixs(srcList, targetList, matrixSavePath=r"data\calibrate\matrix\affine_tmp")

    # ###########################################
    # ###      仿射變換 (For ATC)
    # ###########################################
    # ### 畸變校正後的圖片尺寸 (2160*2160)
    srcList = [
        {"camId": "1", "Point": [(949, 709), (1223, 709), (1147, 1761)]},
        {"camId": "2", "Point": [(365, 595), (1320, 595), (1320, 935)]},
        {"camId": "3_1", "Point": [(512, 1229), (1715, 1293), (1715, 393)]},
    ]
    ### Layout的圖片尺寸 (1045*822)
    targetList = [
        {"camId": "1", "Point": [(164 - 164, 706 - 628), (164 - 164, 628 - 628), (687 - 164, 628 - 628)]},
        {"camId": "2", "Point": [(164 - 164, 628 - 39), (164 - 164, 39 - 39), (341 - 164, 39 - 39)]},
        {"camId": "3_1", "Point": [(780 - 341, 628 - 39), (780 - 341, 39 - 39), (341 - 341, 39 - 39)]},
    ]
    save_all_affin_matrixs(srcList, targetList, matrixSavePath=r"data\calibrate\matrix\affine_tmp")
