from dataclasses import dataclass
import numpy as np


@dataclass
class Face:
    id: int
    box: np.array
    score: float
    gender: str
    age: str
    genderMode: str
    ageMode: str


class Customer:
    def __init__(self, id) -> None:
        self.id = id
        self.timeIn = None
        self.timeOut = None
        self.age = None
        self.gender = None
