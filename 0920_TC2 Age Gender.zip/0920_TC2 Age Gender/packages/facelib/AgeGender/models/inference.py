import os
import sys
import torch
from torch.utils.data import DataLoader
import math
import cv2
import numpy as np
import torchvision.transforms as transforms
from PIL import Image

os.environ["CUDA_VISIBLE_DEVICES"] = "3"
sys.path.append("./")

from packages.facelib.AgeGender.models.model import ShuffleneFull


os.environ["CUDA_VISIBLE_DEVICES"] = "3"
sys.path.append("./")

mean = [0.485, 0.456, 0.406]
std = [0.229, 0.224, 0.225]
trans = transforms.Compose(
    [
        transforms.Resize((112, 112)),
        transforms.ToTensor(),
        transforms.Normalize(mean, std),
    ],
)


def inference(imgFolder, model):
    imgList = os.listdir(imgFolder)

    okGender, sumLossAge = 0, 0
    for imageFileName in imgList:
        imgFilePath = os.path.join(imgFolder, imageFileName)
        img = Image.open(imgFilePath)
        input = trans(img)
        input = input.unsqueeze(0).cuda()
        pred = model(input)

        gender = torch.argmax(pred[0, :2])
        age = pred[0, -1]
        print(f"{imageFileName}, age: {int(age)}, gender: {gender}")

        label = imageFileName.split("__")[0]
        gtAge, gtGender = label.split("_")
        gtAge, gtGender = int(gtAge), int(gtGender)

        if gtGender == gender:
            okGender += 1

        sumLossAge += abs(gtAge - age)

        ### PIL to cv2
        img = cv2.cvtColor(np.asarray(img), cv2.COLOR_RGB2BGR)
        cv2.imshow("imageFileName", img)
        cv2.waitKey(0)
        cv2.destroyAllWindows()

    acc_gender = okGender / len(imgList)
    loss_age = sumLossAge / len(imgList)
    print("acc_gender: {:.3f}, loss_age: {:.3f}".format(acc_gender, loss_age))


if __name__ == "__main__":
    imgFolder = r"D:\Users\YjChou\Smart Retail\age_gender_data\dataset\age_gender\exp\0906_0912_0914_0915\test"
    weight = r"D:\Users\YjChou\Smart Retail\age_gender_data\model\0920_v1.2.pth"
    model = ShuffleneFull()
    model.load_state_dict(torch.load(weight))
    model.to("cuda").eval()
    inference(imgFolder, model)
