import os
import cv2


class ImageLodaer:
    def __init__(self, imgFolder, replay=False):
        self.imgFolder = imgFolder
        self.replay = replay
        self.imgFileList = os.listdir(self.imgFolder)
        self.frameIter = iter(self.imgFileList)
        self.frame, self.index = None, 0

    def get_frame(self):
        if self.index == len(self.imgFileList):
            if self.replay:
                ### 重複圖片迴圈
                self.frameIter = iter(self.imgFileList)
                self.index = 0
            else:
                return None, None
        imgFileName = next(self.frameIter)
        imgName, extension = os.path.splitext(imgFileName)
        self.frame = cv2.imread(os.path.join(self.imgFolder, imgFileName))
        self.index += 1
        return self.frame, imgName

    def get_current_frame(self):
        return self.frame
