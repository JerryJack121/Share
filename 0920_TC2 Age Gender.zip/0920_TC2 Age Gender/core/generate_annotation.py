import os
import shutil


GENDER_LIST = ["Male", "Female"]
AGE_LIST = ["5", "15", "25", "35", "45", "55", "65"]


def main(inputFolder, outputFolder):
    for gender in GENDER_LIST:
        for age in AGE_LIST:
            folderPath = os.path.join(inputFolder, gender, age)
            for imgFilename in os.listdir(folderPath):
                imgFilePath = os.path.join(folderPath, imgFilename)
                genderNum = 0 if gender == "Male" else 1
                destImgFilePath = os.path.join(outputFolder, f"{age}_{genderNum}__{imgFilename}")
                shutil.copy(imgFilePath, destImgFilePath)


if __name__ == "__main__":
    inputFolder = r"D:\Users\YjChou\Smart Retail\age_gender_data\dataset\age_gender\0915_sample\classfication"
    outputImgFolder = r"D:\Users\YjChou\Smart Retail\age_gender_data\dataset\age_gender\0915_sample\label_image"
    main(inputFolder, outputImgFolder)
