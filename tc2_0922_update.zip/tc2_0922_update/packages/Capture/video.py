import cv2
import threading
import time
import os


class VideoLoader:
    def __init__(self, videoPath, fps=None):
        self.videoPath = videoPath
        self.capture = cv2.VideoCapture(self.videoPath)
        self.width = self.capture.get(cv2.CAP_PROP_FRAME_WIDTH)
        self.height = self.capture.get(cv2.CAP_PROP_FRAME_HEIGHT)
        if fps is None:
            self.fps = self.capture.get(cv2.CAP_PROP_FPS)
        else:
            self.fps = fps

        self.frame = None

    def start(self):
        self.camThread = threading.Thread(target=self.__cam_read, daemon=True)
        self.camThread.start()

    def __cam_read(self):
        ret = self.capture.isOpened()
        if not ret:
            print("Load video error!")
            os._exit(0)

        while ret:
            t1 = time.time()
            ret, self.frame = self.capture.read()
            t2 = time.time()
            if ret:
                waitTime = (1 / self.fps) - (t2 - t1)
                if waitTime > 0:
                    time.sleep(waitTime)
        print("Video finish!")

    def get_frame(self):
        return self.frame

    def get_current_frame(self):
        return self.frame


if __name__ == "__main__":
    source = "./data/videos/2023_06_13_01_56_0.mp4"
    dataLoader = VideoLoader(source, fps=20)
    while True:
        frame = dataLoader.get_frame()
        if frame is None:
            time.sleep(0.1)
            continue
        cv2.imshow("img", frame)
        cv2.waitKey(1)
