### 魚眼相機畸變校正 https://www.jiangdabai.com/3753
"""
@author: YJChou
@modular: YJChou
@time: 2023/02
"""

import numpy as np
from tqdm import tqdm, trange
import cv2
import os
import time


class DistortionCorrection:
    """畸變校正 (經度校正、緯度校正)"""

    @staticmethod
    def __get_longitude_calibration_matrix(img):
        """取得經度校正矩陣

        Args:
            img (np.array): image

        Returns:
            tuple[0]: np.array:
            tuple[1]: np.array:
        """
        r = img.shape[0] // 2
        mapx = np.zeros([2 * r, 2 * r], dtype=np.float32)
        mapy = np.zeros([2 * r, 2 * r], dtype=np.float32)
        for i in range(mapx.shape[0]):
            for j in range(mapx.shape[1]):
                mapx[i, j] = (j - r) / r * (r**2 - (i - r) ** 2) ** 0.5 + r
                mapy[i, j] = i
        return mapx, mapy

    @staticmethod
    def __get_latitude_calibration_matrix(img):
        """緯度校正

        Args:
            img (_type_): _description_
        """
        r = img.shape[0] // 2
        mapx = np.zeros([2 * r, 2 * r], dtype=np.float32)
        mapy = np.zeros([2 * r, 2 * r], dtype=np.float32)
        for i in range(mapx.shape[0]):
            for j in range(mapx.shape[1]):
                mapx[i, j] = j
                mapy[i, j] = (i - r) / r * (r**2 - (j - r) ** 2) ** 0.5 + r
        return mapx, mapy

    @staticmethod
    def __pts_longitude_calibration(pts, r):
        rstPts = list()
        for pt in pts:
            x, y = pt
            ### 經度校正
            xRes = (r * (x - r)) / ((r**2 - (y - r) ** 2)) ** 0.5 + r
            yRes = y
            rstPts.append(tuple((int(xRes), int(yRes))))
        return rstPts

    @staticmethod
    def __pts_latitude_calibration(pts, r):
        rstPts = list()
        for pt in pts:
            x, y = pt
            ### 緯度校正
            xRes = x
            yRes = (r * (y - r)) / ((r**2 - (x - r) ** 2)) ** 0.5 + r
            rstPts.append(tuple((int(xRes), int(yRes))))
        return rstPts

    @staticmethod
    def get_matrix(img, mode, matrixSavePath=None, matrixName=None, visualize=False):
        """經緯度校正

        Args:
            img (_type_): _description_
            matrixSavePath (_type_, optional): _description_. Defaults to None.
            mode (int, optional): _description_. Defaults to 1.
            visualize (bool, optional): _description_. Defaults to False.

        Returns:
            _type_: _description_
        """
        if mode == 1:
            methods = [DistortionCorrection.__get_longitude_calibration_matrix]
        elif mode == 2:
            methods = [DistortionCorrection.__get_latitude_calibration_matrix]
        elif mode == 3:
            methods = [
                DistortionCorrection.__get_longitude_calibration_matrix,
                DistortionCorrection.__get_latitude_calibration_matrix,
            ]
        else:
            raise ("Error mode")

        os.makedirs(matrixSavePath, exist_ok=True)

        resImg = img.copy()
        finalMapx, finalMapy = list(), list()
        for method in methods:
            imgFisheye = resImg
            mapx, mapy = method(imgFisheye)
            finalMapx.append(mapx)
            finalMapy.append(mapy)
            resImg = remap_img(resImg, mapx, mapy)

        if visualize:
            cv2.namedWindow("orgImg", cv2.WINDOW_KEEPRATIO)
            cv2.namedWindow("resImg", cv2.WINDOW_KEEPRATIO)
            cv2.imshow("orgImg", img)
            cv2.imshow("resImg", resImg)
            cv2.waitKey(0)

        return np.array(finalMapx), np.array(finalMapy), resImg

    @staticmethod
    def imgCalibration(img, mapxList=None, mapyList=None):
        """經緯度校正

        Args:
            img (_type_): _description_

        Returns:
            _type_: _description_
        """

        resultImg = img.copy()
        for i in range(mapxList.shape[0]):
            resultImg = remap_img(resultImg, mapxList[i], mapyList[i])
        return resultImg

    @staticmethod
    def ptsCalibration(pts, imgWidth, mode):
        """經緯度校正

        Args:
            pts (_type_): _description_
            r (_type_): _description_

        Returns:
            _type_: _description_
        """
        if mode == 1:
            methods = [DistortionCorrection.__pts_longitude_calibration]
        elif mode == 2:
            methods = [DistortionCorrection.__pts_latitude_calibration]
        elif mode == 3:
            methods = [
                DistortionCorrection.__pts_longitude_calibration,
                DistortionCorrection.__pts_latitude_calibration,
            ]
        else:
            raise ("Error mode")

        r = imgWidth // 2
        rstPts = list()
        for method in methods:
            rstPts = method(pts, r)
            pts = rstPts

        return rstPts


class ExpandHorizontally:
    @staticmethod
    def get_remap_matrix(img, matrixSavePath=None, matrixName=None, visualize=False):
        """橫向展開法

        Args:
            img (_type_): 魚眼圖像
            matrixSavePath (_type_, optional): 生成矩陣的資料夾路徑. Defaults to None.
            matrixName (_type_, optional): 矩陣名稱, 會生成 {matrixName}_mapx.npy 和 {matrixName}_mapy.npy. Defaults to None.
            visualize (bool, optional): 可視化. Defaults to False.
        """
        r = img.shape[0] // 2
        w = int(2 * np.pi * r)
        h = r

        mapX = np.zeros([h, w], dtype=np.float32)
        mapY = np.zeros([h, w], dtype=np.float32)
        for i in tqdm(range(mapX.shape[0]), ncols=100):
            for j in range(mapX.shape[1]):
                angle = j / w * np.pi * 2
                radius = h - i
                mapX[i, j] = r + np.sin(angle) * radius
                mapY[i, j] = r + np.cos(angle) * radius

        if matrixSavePath is not None:
            np.save(os.path.join(matrixSavePath, f"{matrixName}_mapx.npy"), mapX)
            np.save(os.path.join(matrixSavePath, f"{matrixName}_mapy.npy"), mapY)
            print(f"Save matrix to '{os.path.join(matrixSavePath)}'")

        if visualize:
            resImg = img.copy()
            resImg = cv2.remap(resImg, mapX, mapY, interpolation=cv2.INTER_NEAREST, borderMode=cv2.BORDER_CONSTANT)
            resImg = cv2.resize(resImg, (resImg.shape[1] // 2, resImg.shape[0] // 2))
            cv2.imwrite("expand_horizontally.jpg", resImg)
            cv2.imshow("expand_horizontally", resImg)
            cv2.waitKey(0)

    ### TODO: yjchou 2023/03/31 橫向展開法公式推導
    @staticmethod
    def point_correction(pts):
        rstPts = list()
        for pt in pts:
            x, y = pt
            xRes = x
            yRes = y
            rstPts.append(tuple((int(xRes), int(yRes))))
        return rstPts


class AffineTransform:
    """仿設變換"""

    @staticmethod
    def get_matrix(srcPts, targetPts):
        ### Apply Perspective Transform Algorithm
        matrix = cv2.getAffineTransform(srcPts, targetPts)
        return matrix

    @staticmethod
    def img_trasform(img, matrix, dSize):
        resImg = img.copy()
        resImg = cv2.warpAffine(resImg, matrix, dSize)
        return resImg

    @staticmethod
    def point_transform(pointList, matrix):
        resPointList = list()
        temp = np.array([[0, 0, 1]])
        matrix = np.concatenate((matrix, temp), axis=0)
        for point in pointList:
            x, y = point
            point = list((x, y, 1))
            resPoint = np.matrix(matrix) * np.matrix(point).T
            resPoint = (np.squeeze(resPoint.T)).tolist()[0]
            x, y, _ = resPoint
            resPointList.append((int(x), int(y)))
        return resPointList


def remap_img(img, mapx, mapy):
    """_summary_

    Args:
        img (_type_): _description_
        mapx (_type_): _description_
        mapy (_type_): _description_

    Returns:
        _type_: _description_
    """
    imgRemap = cv2.remap(img, mapx, mapy, interpolation=cv2.INTER_NEAREST, borderMode=cv2.BORDER_CONSTANT)
    return imgRemap


if __name__ == "__main__":
    img = cv2.imread(r"data\calibrate\fisheye\cam2.jpg")
    img = cv2.rotate(img, cv2.ROTATE_90_CLOCKWISE)
    img = cv2.rotate(img, cv2.ROTATE_90_CLOCKWISE)
    img = cv2.rotate(img, cv2.ROTATE_90_CLOCKWISE)
    ExpandHorizontally.get_remap_matrix(img, visualize=True)
