import os
import schedule


class Manager:
    def __init__(self, programPath, restartTimeFormat, logger) -> None:
        self.restartTimeFormat = restartTimeFormat
        self.programPath = programPath
        self.logger = logger
        if self.restartTimeFormat is not None:
            schedule.every().day.at(self.restartTimeFormat).do(self.shutdown)

    def check_daily_shutdown(self):
        if self.restartTimeFormat is not None:
            schedule.run_pending()

    def shutdown(self):
        cmd = "taskkill /IM run_test.exe /T /F"
        self.logger.warning("Daily Shutdown")
        os.system(cmd)
