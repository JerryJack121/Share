import cv2
import sys
import json

sys.path.append("./")
from packages.CentroidTracker import CentroidTracker


def draw_area(img, bbox):
    resImg = img.copy()
    x1, y1, x2, y2 = int(bbox[0][0]), int(bbox[0][1]), int(bbox[1][0]), int(bbox[1][1])
    cv2.rectangle(resImg, (x1, y1), (x2, y2), color=(0, 0, 255), thickness=2)
    return resImg


def draw_pts(img, pts):
    rstImg = img.copy()
    for pt in pts:
        cv2.circle(rstImg, pt, 5, (0, 0, 255), -1)
    return rstImg


class PeopleCount:
    def __init__(self, entry, exit, logger, cntDay=0, maxSize=999, visualize=False):
        self.visualize = visualize
        self.cntNow = 0  # 當前館內總人數
        self.cntDay = cntDay  # 當天總參訪人次
        self.lastEntryMaxId, self.lastExitMaxId = 0, 0
        self.entryTracker = CentroidTracker(maxDisappeared=2)
        self.exitTracker = CentroidTracker(maxDisappeared=2)
        self.entryPtDictList, self.historyEntryPtDictList = dict(), dict()
        self.exitPtDictList, self.historyExitPtDictList = dict(), dict()
        self.entryIdList, self.exitIdList = list(), list()
        self.entryinIdList, self.exitinIdList = list(), list()
        self.maxSize = maxSize  # 通過的ID暫存數量
        self.cntLineWidth = 0  # 計數線寬度 (未開發完成)
        self.entryCamId, self.exitCamId = entry["camID"], exit["camID"]
        self.entryArea, self.exitArea = entry["area"], exit["area"]
        self.entryLines, self.exitLines = entry["lines"], exit["lines"]
        self.logger = logger

    def reset(self):
        """系統重置"""
        self.cntNow = 0  # 當前館內總人數
        self.cntDay = 0  # 當天總參訪人次
        self.lastEntryMaxId, self.lastExitMaxId = 0, 0
        self.entryTracker = CentroidTracker(maxDisappeared=2)
        self.exitTracker = CentroidTracker(maxDisappeared=2)

    def is_point_in_area(self, point, area):
        x, y = point[0], point[1]
        if x < area[0][0] or x > area[1][0] or y < area[0][1] or y > area[1][1]:
            return False
        else:
            return True

    def __entryCnt(self, entryDataDict):
        inNum, outNum, maxId, dayInNum = 0, 0, 0, 0
        pointList = entryDataDict["point"]
        if self.visualize:
            self.entryImg = entryDataDict["corrImg"].copy()

        self.pointInEntryArea = list()
        ### 在入口區域的點座標
        for point in pointList:
            if self.is_point_in_area(point, self.entryArea):
                self.pointInEntryArea.append(point)

        ### 點座標追蹤
        self.historyEntryPtDictList = self.entryPtDictList
        self.entryPtDictList = dict()
        objects = self.entryTracker.update(self.pointInEntryArea)
        for objectID, centroid in objects.items():
            if objectID > maxId:
                maxId = objectID
            self.entryPtDictList[objectID] = dict()
            self.entryPtDictList[objectID]["objectID"] = objectID
            self.entryPtDictList[objectID]["point"] = tuple((centroid[0], centroid[1]))

            ### Visualize
            if self.visualize:
                cv2.putText(
                    self.entryImg,
                    str(objectID),
                    tuple((centroid[0], centroid[1])),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    1,
                    (0, 0, 255),
                    1,
                    cv2.LINE_AA,
                )

        ### 切換進出口單/雙向進出
        if True:
            self.logger.debug("使用入口雙向進出演算法")
            ### 入口雙向進出
            for personId, ptDict in self.entryPtDictList.items():
                point = ptDict["point"]
                ### 上一幀ID存在
                if personId in self.historyEntryPtDictList.keys():
                    lastPoint = self.historyEntryPtDictList[personId]["point"]
                    howCrossLine = self.__cross_line(self.entryLines, point, lastPoint)
                    if howCrossLine != None:
                        # print(f"iD: {personId}, {howCrossLine}")
                        if howCrossLine == "Unknow":
                            ### 忽略剛好在計數線上的那一幀
                            self.entryPtDictList[personId]["point"] = self.historyEntryPtDictList[personId]["point"]
                        elif howCrossLine:
                            inNum += 1
                            ### 相同ID只加一次當日總人次
                            if personId not in self.entryinIdList:
                                self.entryinIdList.append(personId)
                                dayInNum += 1
                        else:
                            outNum += 1

            if len(self.entryinIdList) > self.maxSize:
                self.entryinIdList.pop(0)

            ### Visualize
            if self.visualize:
                ### 畫計數線
                for line in self.entryLines:
                    linePoint1, linePoint2, rule = line
                    cv2.line(
                        self.entryImg,
                        (int(linePoint1[0]), int(linePoint1[1])),
                        (int(linePoint2[0]), int(linePoint2[1])),
                        (255, 0, 0),
                        2,
                    )
        else:
            ## DEVELOP: 西大墩單向進入
            self.logger.debug("使用西大墩入口單向進入演算法")
            ### 計算通過計數線數量
            x1, x2 = self.entryArea[0][0], self.entryArea[1][0]
            cntLineX = (x1 + x2) // 2 - 70
            rightCntLineX = cntLineX + 130
            topLineY = self.entryArea[0][1] + 220

            for personId, ptDict in self.entryPtDictList.items():
                point = ptDict["point"]
                ### 上一幀目標存在
                if personId in self.historyEntryPtDictList.keys():
                    lastPoint = self.historyEntryPtDictList[personId]["point"]
                    ### 通過計數線 (同時判斷右至左, 下至上)
                    if True:
                        if lastPoint[0] >= cntLineX and lastPoint[1] >= topLineY:
                            ### 相同ID不重複計算
                            if personId in self.entryIdList:
                                continue
                            if point[0] < cntLineX:
                                self.entryIdList.append(personId)
                                inNum += 1
                            elif point[1] < topLineY and point[0] < rightCntLineX:
                                self.entryIdList.append(personId)
                                inNum += 1

                            if len(self.entryIdList) > self.maxSize:
                                self.entryIdList.pop(0)
                    else:
                        ### 通過計數線 (右至左)
                        if lastPoint[0] > cntLineX + self.cntLineWidth and point[0] <= cntLineX - self.cntLineWidth:
                            # ### 相同ID不重複計算
                            # if personId in self.entryIdList:
                            #     continue
                            # if len(self.entryIdList) > self.maxSize:
                            #     self.entryIdList.pop(0)
                            # self.entryIdList.append(personId)
                            inNum += 1

            dayInNum = inNum

            ## Visualize
            if self.visualize:
                cv2.line(
                    self.entryImg,
                    (int(cntLineX + self.cntLineWidth), int(topLineY)),
                    (int(cntLineX + self.cntLineWidth), int(self.entryArea[1][1])),
                    (255, 0, 0),
                    2,
                )
                cv2.line(
                    self.entryImg,
                    (int(cntLineX), int(topLineY)),
                    (int(rightCntLineX), int(topLineY)),
                    (255, 0, 0),
                    2,
                )

        return inNum, outNum, dayInNum

    def __exitCnt(self, exitDataDict):
        inNum, outNum, maxId, dayInNum = 0, 0, 0, 0
        pointList = exitDataDict["point"]
        if self.visualize:
            self.exitImg = exitDataDict["corrImg"].copy()

        self.pointInExitArea = list()
        ### 在出口區域的點座標
        for point in pointList:
            if self.is_point_in_area(point, self.exitArea):
                self.pointInExitArea.append(point)

        ### 點座標追蹤
        self.historyExitPtDictList = self.exitPtDictList
        self.exitPtDictList = dict()
        objects = self.exitTracker.update(self.pointInExitArea)
        for objectID, centroid in objects.items():
            if objectID > maxId:
                maxId = objectID
            self.exitPtDictList[objectID] = dict()
            self.exitPtDictList[objectID]["objectID"] = objectID
            self.exitPtDictList[objectID]["point"] = tuple((centroid[0], centroid[1]))

            ### Visualize
            if self.visualize:
                cv2.putText(
                    self.exitImg,
                    str(objectID),
                    tuple((centroid[0], centroid[1])),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    1,
                    (0, 0, 255),
                    1,
                    cv2.LINE_AA,
                )

        ### 切換進出口單/雙向進出
        if True:
            self.logger.debug("使用出口雙向進出演算法")
            ### 出口雙向進出
            for personId, ptDict in self.exitPtDictList.items():
                point = ptDict["point"]
                ### 上一幀ID存在
                if personId in self.historyExitPtDictList.keys():
                    lastPoint = self.historyExitPtDictList[personId]["point"]
                    howCrossLine = self.__cross_line(self.exitLines, point, lastPoint)
                    if howCrossLine != None:
                        # print(f"iD: {personId}, {howCrossLine}")

                        if howCrossLine == "Unknow":
                            ### 忽略剛好在計數線上的那一幀
                            self.exitPtDictList[personId]["point"] = self.historyExitPtDictList[personId]["point"]
                        elif howCrossLine:
                            outNum += 1
                        else:
                            inNum += 1
                            ### 相同ID只加一次當日總人次
                            if personId not in self.exitinIdList:
                                self.exitinIdList.append(personId)
                                dayInNum += 1

            if len(self.exitinIdList) > self.maxSize:
                self.exitinIdList.pop(0)

            ### Visualize
            if self.visualize:
                ### 畫計數線
                for line in self.exitLines:
                    linePoint1, linePoint2, rule = line
                    cv2.line(
                        self.exitImg,
                        (int(linePoint1[0]), int(linePoint1[1])),
                        (int(linePoint2[0]), int(linePoint2[1])),
                        (255, 0, 0),
                        2,
                    )
        else:
            ## DEVELOP: 西大墩單向離開
            self.logger.debug("使用西大墩出口單向離開演算法")
            ### 計算通過計數線數量
            x1, x2 = self.exitArea[0][0], self.exitArea[1][0]
            cntLineX = (x1 + x2) // 2 + 130
            topCntLineY = self.exitArea[0][1] + 180
            bottomCntLineY = self.exitArea[1][1] - 150

            for personId, ptDict in self.exitPtDictList.items():
                point = ptDict["point"]
                ### 上一幀目標存在
                if personId in self.historyExitPtDictList.keys():
                    lastPoint = self.historyExitPtDictList[personId]["point"]
                    if True:
                        ### 通過計數線 (矩形區左至右)
                        if point[0] > cntLineX and point[1] > topCntLineY and point[1] < bottomCntLineY:
                            ### 相同ID不重複計算
                            if personId in self.exitIdList:
                                continue
                            if (
                                lastPoint[0] <= cntLineX
                                or lastPoint[1] <= topCntLineY
                                or lastPoint[1] >= bottomCntLineY
                            ):
                                self.exitIdList.append(personId)
                                outNum += 1
                            if len(self.exitIdList) > self.maxSize:
                                self.exitIdList.pop(0)
                    else:
                        ### 通過計數線 (左至右)
                        if lastPoint[0] < cntLineX - self.cntLineWidth and point[0] >= cntLineX + self.cntLineWidth:
                            # ### 相同ID不重複計算
                            # if personId in self.exitIdList:
                            #     continue
                            # if len(self.exitIdList) > self.maxSize:
                            #     self.exitIdList.pop(0)
                            # self.exitIdList.append(personId)
                            outNum += 1

            ### Visualize
            if self.visualize:
                cv2.line(
                    self.exitImg,
                    (int(cntLineX - self.cntLineWidth), int(topCntLineY)),
                    (int(cntLineX - self.cntLineWidth), int(bottomCntLineY)),
                    (255, 0, 0),
                    2,
                )
                cv2.line(
                    self.exitImg,
                    (int(cntLineX), int(topCntLineY)),
                    (int(self.exitArea[1][0]), int(topCntLineY)),
                    (255, 0, 0),
                    2,
                )
                cv2.line(
                    self.exitImg,
                    (int(cntLineX), int(bottomCntLineY)),
                    (int(self.exitArea[1][0]), int(bottomCntLineY)),
                    (255, 0, 0),
                    2,
                )

        return inNum, outNum, dayInNum

    def count_total_people(self, dataDictList, fenceCntDict):
        ### 西大墩演算法
        for dataDict in dataDictList:
            ### 入口
            if dataDict["camId"] == self.entryCamId:
                entryInNum, entryOutNum, entrydayInNum = self.__entryCnt(dataDict)
            ### 出口
            if dataDict["camId"] == self.exitCamId:
                exitInNum, exitOutNum, exitdayInNum = self.__exitCnt(dataDict)

        ### 切換正常算法/西大墩出口遮擋問題-軟體解
        if True:
            self.logger.debug("使用出入口過線計數演算法")
            ### 根據出入口計數線計算
            self.cntNow = self.cntNow + entryInNum + exitInNum - entryOutNum - exitOutNum

        ### DEVELOP: yjchou 2023/05/02 西大墩出口遮擋問題-軟體解(只支援西大墩)
        else:
            self.logger.debug("使用西大墩出口遮擋問題-軟體解演算法")
            fence8People = fenceCntDict["8"]
            if fence8People <= 5:
                ### 根據出入口計數線計算
                self.cntNow = self.cntNow + entryInNum + exitInNum - entryOutNum - exitOutNum

            ### 第8區太多人要出去, 直接用館內人數計算
            else:
                exitFlag = False
                ### 出口機制觸發館內人數校正 fenceCntDict 只在這邊用到
                x1, x2 = self.exitArea[0][0], self.exitArea[1][0]
                cntLineX = (x1 + x2) // 2 + 130
                topCntLineY = self.exitArea[0][1] + 180
                bottomCntLineY = self.exitArea[1][1] - 150

                for dataDict in dataDictList:
                    if dataDict["camId"] == self.exitCamId:
                        exitList = dataDict["point"]

                ### 有人在出口觸, 觸發條件
                for point in exitList:
                    if point[0] > cntLineX and point[1] > topCntLineY and point[1] < bottomCntLineY:
                        exitFlag = True
                        break

                if exitFlag:
                    tmpCntNow = 0
                    for fencePeople in fenceCntDict.values():
                        tmpCntNow += fencePeople
                    ### 入口有人進入或館內人變少才校正
                    if entryInNum > 0 or tmpCntNow < self.cntNow:
                        self.cntNow = tmpCntNow
                else:
                    self.cntNow = self.cntNow + entryInNum

        ### 邊界條件, 避免出現負值
        if self.cntNow < 0:
            self.cntNow = 0
        self.cntDay = self.cntDay + entrydayInNum + exitdayInNum

        if self.visualize:
            self.entryImg = draw_area(self.entryImg, self.entryArea)
            self.entryImg = draw_pts(self.entryImg, self.pointInEntryArea)
            self.entryImg = cv2.resize(self.entryImg, (self.entryImg.shape[1] // 2, self.entryImg.shape[0] // 2))
            self.exitImg = draw_area(self.exitImg, self.exitArea)
            self.exitImg = draw_pts(self.exitImg, self.pointInExitArea)
            self.exitImg = cv2.resize(self.exitImg, (self.exitImg.shape[1] // 2, self.exitImg.shape[0] // 2))
            cv2.imshow("entryImg", self.entryImg)
            cv2.imshow("exitImg", self.exitImg)
            cv2.waitKey(1)

            # ### DEVELOP:
            # if entryNum != 0:
            #     print("")
            # if exitNum != 0:
            #     print("")

        return self.cntNow, self.cntDay

    def __cross_line(self, lines, point, lastPoint):
        """判斷是否滿足計數線規則

        Args:
            lines (_type_): _description_
        """
        ### ID 沒有移動
        if point[0] == lastPoint[0] and point[1] == lastPoint[1]:
            return None

        ### 判斷路徑是否跨越計數線
        result = None
        for line in lines:
            linePoint1, linePoint2, rule = line

            # 兩線段沒有交點
            if (
                min(point[0], lastPoint[0]) > max(linePoint1[0], linePoint2[0])
                or max(point[0], lastPoint[0]) < min(linePoint1[0], linePoint2[0])
                or min(point[1], lastPoint[1]) > max(linePoint1[1], linePoint2[1])
                or max(point[1], lastPoint[1]) < min(linePoint1[1], linePoint2[1])
            ):
                tmpResult = None
                continue

            ### 計數線為水平線
            if linePoint1[1] == linePoint2[1]:
                # print(f"{lastPoint}->{point}")
                if point[1] == linePoint1[1]:
                    ### 剛好停在線上
                    return "Unknow"
                elif (point[1] - lastPoint[1]) * rule * -1 > 0:
                    tmpResult = True
                else:
                    tmpResult = False

            ### 計數線為垂直線
            elif linePoint1[0] == linePoint2[0]:
                # print(f"{lastPoint}->{point}")
                if point[0] == linePoint1[0]:
                    ### 剛好停在線上
                    return "Unknow"
                elif (point[0] - lastPoint[0]) * rule > 0:
                    tmpResult = True
                else:
                    tmpResult = False

            else:
                errorMsg = "計數線設定錯誤: 只支援水平線和垂直線的組合"
                self.logger.error(errorMsg)
                raise (errorMsg)

            if result is None:
                result = tmpResult
            elif result != tmpResult:
                ### 同時跨越兩條計數線且結果有加有減
                return None

        return result
