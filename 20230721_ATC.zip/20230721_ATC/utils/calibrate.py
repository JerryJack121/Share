import numpy as np
import sys
import cv2
import time

sys.path.append("./")
from packages.Calibrate import DistortionCorrection, AffineTransform


def get_layout_region(layoutRegionList, camId):
    for cam in layoutRegionList:
        if cam["camId"] == camId:
            region = cam["data"]
            return region
    return None


def img_distortion_corr(img, distortionCorrMatix):
    """單張圖片畸變轉換

    Args:
        img (_type_): _description_
        distortionCorrMatix (_type_): _description_

    Returns:
        _type_: _description_
    """
    mapxList, mapyList = distortionCorrMatix
    resImg = DistortionCorrection.imgCalibration(img, mapxList, mapyList)
    return resImg


def point_distortion_corr(pointList, imgSize):
    """點座標畸變轉換

    Args:
        pointList (_type_): _description_
        imgSize (_type_): _description_

    Returns:
        _type_: _description_
    """
    imgWidth = imgSize[0]
    resPointList = DistortionCorrection.ptsCalibration(pointList, imgWidth, mode=1)
    return resPointList


def img_affin_trans(img, region, affinMatrix):
    """單張圖片畸變轉換

    Args:
        img (_type_): _description_
        camId (_type_): _description_

    Returns:
        _type_: _description_
    """
    dSize = (int(region[1][0]) - int(region[0][0]), int(region[1][1]) - int(region[0][1]))
    resImg = AffineTransform.img_trasform(img, affinMatrix, dSize)
    return resImg


def point_affin_trans(pointList, region, affinMatrix):
    """點座標仿設轉換

    Args:
        pointList (_type_): _description_
        camId (_type_): _description_
        imgSize (_type_): _description_

    Returns:
        _type_: _description_
    """
    ### 座標轉換方法
    afinePointList = AffineTransform.point_transform(pointList, affinMatrix)
    ### 拼入 Layout
    resPointList = list()
    for point in afinePointList:
        x, y = point
        dSize = (int(region[1][0]) - int(region[0][0]), int(region[1][1]) - int(region[0][1]))
        ### 濾除超出邊界的點
        if x < 0 or y < 0 or x > dSize[0] or y > dSize[1]:
            continue
        x += region[0][0]
        y += region[0][1]
        resPointList.append((int(x), int(y)))
    # print(f"{len(pointList)}->{len(resPointList)}")
    return resPointList
