PROJECT_NAME = "Project Name"
LANG = "cht"