import os
import cv2
import sys
import datetime
import json

sys.path.append("./")
from packages.CentroidTracker import CentroidTracker
from packages.Bytetrack.byte_tracker import BYTETracker
import numpy as np
from packages.visualize import plot_tracking
import configparser
from packages.ImageProcess import Plot


def draw_id(img, objectID, foots):
    cv2.putText(
        img,
        str(objectID),
        tuple((int(foots[0]), int(foots[1]))),
        cv2.FONT_HERSHEY_SIMPLEX,
        1,
        (0, 0, 255),
        2,
        cv2.LINE_AA,
    )


def draw_bbox(img, bboxinEntryArea):
    for bbox in bboxinEntryArea:
        x1, y1, x2, y2 = (int(bbox[0]), int(bbox[1]), int(bbox[2]), int(bbox[3]))
        cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)


class BYTETrackerArgs:
    def __init__(self):
        self.frame_rate = 15
        self.track_thresh = 0.5
        self.track_buffer = 30
        self.match_thresh = 0.5
        self.aspect_ratio_thresh = 2
        self.min_box_area = 30000
        self.mot20 = False


class StayTracker:
    def __init__(self, fenceDict, initIdList, visualize=True):
        """各展區 ID 追蹤

        Args:
            fenceDict (_type_): _description_
            initIdList (_type_): _description_
            visualize (bool, optional): _description_. Defaults to True.
        """
        self.fenceDict = fenceDict
        self.initIdList = initIdList
        self.visualize = visualize
        self.trackerDict = dict()
        self.visualizeImgDict = dict()
        self.stayTimeCal = StayTimeCal(stayTimeThres=10, maxLen=99)

        # 讀取使用哪個tracker
        self.config = configparser.ConfigParser()
        self.config.read(r"data\config\system.cfg", encoding="utf-8")
        self.trackerValue = self.config.get("Tracker", "tracker")

        self.entryPtDictList, self.historyEntryPtDictList = dict(), dict()
        if self.trackerValue == "0":
            self.tracker_args = BYTETrackerArgs()
            for fenceNum, fenceData in self.fenceDict.items():
                self.trackerDict[fenceNum] = BYTETracker(
                    self.tracker_args.frame_rate,
                    self.tracker_args.track_thresh,
                    self.tracker_args.track_buffer,
                    self.tracker_args.match_thresh,
                )
        elif self.trackerValue == "1":
            for fenceNum, fenceData in self.fenceDict.items():
                self.trackerDict[fenceNum] = CentroidTracker(maxDisappeared=10)

    def reset(self):
        """系統重置"""
        self.trackerDict = dict()
        if self.trackerValue == "0":
            self.tracker_args = BYTETrackerArgs()
            for fenceNum, fenceData in self.fenceDict.items():
                self.trackerDict[fenceNum] = BYTETracker(
                    self.tracker_args.frame_rate,
                    self.tracker_args.track_thresh,
                    self.tracker_args.track_buffer,
                    self.tracker_args.match_thresh,
                )
        elif self.trackerValue == "1":
            for fenceNum, fenceData in self.fenceDict.items():
                self.trackerDict[fenceNum] = CentroidTracker(maxDisappeared=10)

    def is_point_in_area(self, point, area):
        x, y = point[0], point[1]
        if x < area[0][0] or x > area[1][0] or y < area[0][1] or y > area[1][1]:
            return False
        return True

    def people_track(self, dataDictList):
        idDict = dict()
        for fenceNum, fenceData in self.fenceDict.items():
            idDict[fenceNum] = list()
            pointInEntryArea = list()
            self.bboxInEntryArea = list()
            camId, fenceCord = fenceData["camID"], fenceData["data"]
            ### 畸變校正後座標
            for dataDict in dataDictList:
                if dataDict["camId"] == camId:
                    corrImg = dataDict["corrImg"]
                    midpointList = dataDict["corrMidPoint"]
                    footPointList = dataDict["point"]
                    bboxList = dataDict["bbox"]
                    if camId not in self.visualizeImgDict.keys():
                        self.visualizeImgDict[camId] = corrImg
                    break

            for i, point in enumerate(midpointList):
                foot, bbox = footPointList[i], bboxList[i]
                if self.is_point_in_area(point, fenceCord):
                    w, h, score = bbox
                    pointInEntryArea.append(foot)

                    halfW, halfH = w // 2, h // 2
                    halfW, halfH = (halfW * 2160 / 304, halfH * 2160 / 304)
                    x1, x2, y1, y2 = (
                        point[0] - halfW,
                        point[0] + halfW,
                        point[1] - halfH,
                        point[1] + halfH,
                    )
                    bbox = [x1, y1, x2, y2, score, foot]
                    self.bboxInEntryArea.append(bbox)
            ### 點座標追蹤
            self.historyEntryPtDictList = self.entryPtDictList
            self.entryPtDictList = dict()

            if len(self.bboxInEntryArea) != 0:
                if self.trackerValue == "0":
                    objects = self.trackerDict[fenceNum].update(self.bboxInEntryArea)
                elif self.trackerValue == "1":
                    objects = self.trackerDict[fenceNum].update(pointInEntryArea)
                for objectID, foots in objects.items():
                    self.entryPtDictList[objectID] = dict()
                    self.entryPtDictList[objectID]["objectID"] = objectID
                    self.entryPtDictList[objectID]["point"] = foots
                    ## Visualize
                    self.visualize = True
                    if self.visualize:
                        for camId, visualizeImg in self.visualizeImgDict.items():
                            Plot.draw_id(visualizeImg, objectID, foots)
                            if self.trackerValue == "0":
                                Plot.draw_bbox(visualizeImg, self.bboxInEntryArea)

            ### 計算各 ID 停留時間
            entryIdDict, exitIdDict, avgStayTimeDict = self.stayTimeCal.update(idDict)

            ### visualize
            if self.visualize:
                for camId, visualizeImg in self.visualizeImgDict.items():
                    visualizeImg = cv2.resize(visualizeImg, (visualizeImg.shape[1] // 2, visualizeImg.shape[0] // 2))
                    cv2.imshow(camId, visualizeImg)
                    cv2.waitKey(1)
                self.visualizeImgDict = dict()

            return idDict, entryIdDict, exitIdDict, avgStayTimeDict

        # if x < fenceCord[0][0] or x > fenceCord[1][0] or y < fenceCord[0][1] or y > fenceCord[1][1]:
        #     continue
        # pointInFence.append(point)


class StayTimeCal:
    def __init__(self, stayTimeThres=30, maxLen=99, outputFolder=r"data\txt\id_track") -> None:
        """計算各 ID 進出時間與各展區平均停留時間

        Args:
            stayTimeThres (int, optional): 停留時間秒數閾值, 低於閾值則不發送到前端. Defaults to 30.
            maxLen (int, optional): 各圍籬記錄ID的最大長度. Defaults to 99.
            outputFolder (str, optional): 輸出資料夾. Defaults to "data\txt".
        """
        self.maxLen = maxLen
        self.outputFolder = outputFolder
        self.stayTimeThres = stayTimeThres
        os.makedirs(self.outputFolder, exist_ok=True)
        ### 初始化8個展區
        self.existIdDict, self.resultDict = dict(), dict()
        for fenceNum in list((str(i) for i in range(1, 9))):
            self.existIdDict[fenceNum] = dict()  # 紀錄各展區當前存在ID進入時間
            self.resultDict[fenceNum] = dict()  # 紀錄各展區所有ID進出時間

    def update(self, idDict):
        ### 初始化8個展區
        entryIdDict, exitIdDict, avgStayTimeDict = dict(), dict(), dict()
        for fenceNum in list((str(i) for i in range(1, 9))):
            entryIdDict[fenceNum] = dict()  # 紀錄各展區進入的ID
            exitIdDict[fenceNum] = dict()  # 紀錄各展區離開的ID
            avgStayTimeDict[fenceNum] = 0  # maxLen時間區間內的平均停留時間

        for fenceNum, idList in idDict.items():
            ### 沒有記錄過的ID, 記錄進入時間
            for id in idList:
                if id not in self.resultDict[fenceNum].keys():
                    # startTime = time.time()
                    startTime = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    self.existIdDict[fenceNum][id] = dict({"startTime": startTime})
                    entryIdDict[fenceNum][id] = dict({"startTime": startTime, "endTime": None, "stayTime": None})
                    self.resultDict[fenceNum][id] = dict({"startTime": startTime, "endTime": None, "stayTime": None})

            ### 消失的ID, 記錄離開時間
            leftIdList = list()
            for id in self.existIdDict[fenceNum].keys():
                if id not in idList:
                    startTime = self.resultDict[fenceNum][id]["startTime"]
                    # endTime = time.time()
                    endTime = datetime.datetime.now()
                    stayTime = (
                        endTime - datetime.datetime.strptime(startTime, "%Y-%m-%d %H:%M:%S")
                    ).total_seconds()  # 轉換成秒數
                    endTime = endTime.strftime("%Y-%m-%d %H:%M:%S")
                    leftIdList.append(id)
                    self.resultDict[fenceNum][id] = dict(
                        {"startTime": startTime, "endTime": endTime, "stayTime": stayTime}
                    )

                    ### 高於閾值的才列入
                    if stayTime >= self.stayTimeThres:
                        exitIdDict[fenceNum][id] = dict(
                            {"startTime": startTime, "endTime": endTime, "stayTime": stayTime}
                        )

            # 從當前ID列表中移除消失的ID
            for id in leftIdList:
                self.existIdDict[fenceNum].pop(id)

            ### 刪除超過最大長度的舊資料
            if len(self.resultDict[fenceNum]) > self.maxLen:
                delNum = len(self.resultDict[fenceNum]) - self.maxLen
                while delNum != 0:
                    resultIdDict = list(self.resultDict[fenceNum].keys())
                    for delId in resultIdDict:
                        ### 避免刪到目前存在的ID
                        if delId not in self.existIdDict[fenceNum].keys():
                            self.resultDict[fenceNum].pop(delId)
                            delNum -= 1
                            break
                        ### 所有ID都還存在則不刪除任何資料
                        elif delId == resultIdDict[-1]:
                            delNum = 0

            ### DEVELOP: 輸出txt & 計算平均停留時間, 非必要開啟
            if False:
                stayTimeSum = 0
                file = open(os.path.join(self.outputFolder, "fence_" + fenceNum + ".txt"), "wt")
                for id, idInfo in self.resultDict[fenceNum].items():
                    startTime, endTime, stayTime = idInfo["startTime"], idInfo["endTime"], idInfo["stayTime"]

                    ### ID 尚未離開, 以目前時間計算
                    if stayTime is None:
                        stayTime = (
                            datetime.datetime.now() - datetime.datetime.strptime(startTime, "%Y-%m-%d %H:%M:%S")
                        ).total_seconds()

                        endTime = "None"

                    stayTimeSum += stayTime
                    file.write(
                        "{} startTime: {}, endTime:{}, stayTime: {:.2f}s\n".format(id, startTime, endTime, stayTime)
                    )
                if len(self.resultDict[fenceNum].keys()) != 0:
                    avgStayTimeDict[fenceNum] = stayTimeSum / len(self.resultDict[fenceNum].keys())
                else:
                    avgStayTimeDict[fenceNum] = 0
                file.write("Average Stay {:.2f}s".format(avgStayTimeDict[fenceNum]))
                file.close()

            else:
                stayTimeSum = 0
                file = open(os.path.join(self.outputFolder, "fence_" + fenceNum + ".txt"), "wt")
                for id, idInfo in self.resultDict[fenceNum].items():
                    startTime, endTime, stayTime = idInfo["startTime"], idInfo["endTime"], idInfo["stayTime"]

                    ### ID 尚未離開, 以目前時間計算
                    if stayTime is None:
                        stayTime = (
                            datetime.datetime.now() - datetime.datetime.strptime(startTime, "%Y-%m-%d %H:%M:%S")
                        ).total_seconds()

                        endTime = "None"

                    stayTimeSum += stayTime
                    file.write(
                        "{} startTime: {}, endTime:{}, stayTime: {:.2f}s\n".format(id, startTime, endTime, stayTime)
                    )
                if len(self.resultDict[fenceNum].keys()) != 0:
                    avgStayTimeDict[fenceNum] = stayTimeSum / len(self.resultDict[fenceNum].keys())
                else:
                    avgStayTimeDict[fenceNum] = 0

        return entryIdDict, exitIdDict, avgStayTimeDict
