import cv2
from configparser import ConfigParser
import json


class Mask:
    def __init__(self, maskList, visualize=False):
        self.visualize = visualize

        ### 轉換至4合1魚眼圖座標 (4320*4320)
        self.maskDataList = list()
        for mask in maskList:
            maskData = mask["data"]
            camId = mask["camID"]
            if camId == "1":
                x1 = maskData[0][0] + 2160
                x2 = maskData[1][0] + 2160
                y1 = maskData[0][1]
                y2 = maskData[1][1]
            elif camId == "2":
                x1 = maskData[0][0]
                x2 = maskData[1][0]
                y1 = maskData[0][1]
                y2 = maskData[1][1]
            if camId == "3":
                x1 = maskData[0][0]
                x2 = maskData[1][0]
                y1 = maskData[0][1] + 2160
                y2 = maskData[1][1] + 2160
            if camId == "4":
                x1 = maskData[0][0] + 2160
                x2 = maskData[1][0] + 2160
                y1 = maskData[0][1] + 2160
                y2 = maskData[1][1] + 2160
            maskData = tuple(((x1, y1), (x2, y2)))
            self.maskDataList.append(maskData)

    def noise_filter(self, img, pointList):
        ### 濾除遮罩內目標
        pointAfterMask = list()
        for point in pointList:
            ok = True
            for maskData in self.maskDataList:
                if not (
                    point[0] < maskData[0][0]
                    or point[0] > maskData[1][0]
                    or point[1] < maskData[0][1]
                    or point[1] > maskData[1][1]
                ):
                    ok = False
            if ok:
                pointAfterMask.append(point)
        pointList = pointAfterMask

        resImg = img.copy()
        ### 畫作標點
        for point in pointList:
            resImg = cv2.circle(resImg, point, 10, (0, 255, 0), -1)

        ### 遮罩可視化
        if self.visualize:
            for maskData in self.maskDataList:
                resImg = cv2.rectangle(
                    resImg,
                    (int(maskData[0][0]), int(maskData[0][1])),
                    (int(maskData[1][0]), int(maskData[1][1])),
                    (0, 0, 0),
                    -1,
                )

        return resImg, pointList
