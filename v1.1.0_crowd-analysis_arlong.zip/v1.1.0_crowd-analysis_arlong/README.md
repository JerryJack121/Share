# ATC Crowd Anzlysis

## Edit Record

- 每次改版，請延續此表格紀錄修改內容

| Version | Status |      Branch Name       | Push Date  | Editor | Editor Server | Comment                         |
| :-----: | :----: | :--------------------: | :--------: | :----: | :-----------: | :------------------------------ |
| v1.0.0  | Alpha  | v1.0.0_yjchou_20231025 | 2023/10/25 | YJChou |  tw100039394  |                                 |
| v1.1.0  |  Beta  | v1.1.0_Arlong_20231127 | 2023/11/27 | Arlong |  tw100039394  | 1. 更新 ID 追蹤方法為 ByteTrack |
