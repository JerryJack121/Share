import cv2
from flask import Flask, Response
import threading
import sys

sys.path.append("./")
from const.GlobalObject import StreamData

APP = Flask(__name__)


@APP.route("/stream")
def get_frame():
    """影像串流 api"""

    def stream_generator():
        while True:
            if StreamData.streamImg is not None:
                encodedImage = encoder(StreamData.streamImg)
                yield encodedImage

    return Response(stream_generator(), mimetype="multipart/x-mixed-replace; boundary=frame")


def encoder(img):
    """圖像編碼

    Args:
        img (np.array): 串流圖片

    Returns:
        str: 編碼後的圖片
    """
    (flag, encodedImage) = cv2.imencode(".jpg", img)  # 資料格式轉換為.jpg
    if flag:  # ensure the frame was successfully encoded
        encodedImage = b"--frame\r\n" b"Content-Type: image/jpeg\r\n\r\n" + bytearray(encodedImage) + b"\r\n"
    return encodedImage


class WebServer:
    """影片串流伺服器"""

    def __init__(self, host="0.0.0.0", port=5000) -> None:
        ### 啟動伺服器執行序
        self.serverThread = threading.Thread(target=self.__start_server, args=(host, port))
        self.serverThread.start()

    def __start_server(self, host, port):
        """啟動伺服器

        Args:
            host (str): 本機 ip
            port (int): port
        """
        APP.run(host, port, debug=False, use_reloader=False)
