import os


class ModifyChecker:
    def __init__(self, filePath):
        self.filePath = filePath
        statinfo = os.stat(self.filePath)  # 上次修改時間
        self.lastModifyTime = statinfo.st_mtime

    def is_modify(self):
        statinfo = os.stat(self.filePath)  # 上次修改時間
        modifyTime = statinfo.st_mtime
        if modifyTime != self.lastModifyTime:
            return True
        else:
            return False
