from configparser import ConfigParser
import argparse


def main(AISwitch):
    AISwitch = str(AISwitch)

    ### Read sitch config path
    config = ConfigParser()
    config.read(r"data\config\system.cfg", encoding="utf-8")
    settingFilePathDict = dict()
    for sysName, settingFilePath in config.items("SettingFilePath"):
        ### config 讀進來的Key值都是小寫
        settingFilePathDict[sysName] = settingFilePath
    config.clear()

    ### Load AI Switch
    config.read(settingFilePathDict["switch"], encoding="utf-8")

    # 更改設定
    if AISwitch != config["Switch"]["AISwitch"]:
        config["Switch"]["AISwitch"] = AISwitch

        ### 寫入設定
        with open(settingFilePathDict["switch"], "w", encoding="utf-8") as configfile:
            config.write(configfile)
            print(f"Set AISwitch to {AISwitch}")
    else:
        print(f"AISwitch is {AISwitch} already")


parser = argparse.ArgumentParser()
parser.add_argument("--closeAI", "-c", action="store_true", help="set AISwitch to False")
args = parser.parse_args()
main(not args.closeAI)
