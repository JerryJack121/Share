class Person(object):
    foot = tuple((None, None))  # footpoint
    mid = tuple((None, None))  # center of detection
    bbox = tuple((None, None, None))  # w,h,score
    # distortion = tuple((None, None))  # 校正後的中心點
    # transfermidpoint = tuple((None, None))  # 轉移後的中心點
