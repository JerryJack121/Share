import cv2
from facelib import WebcamAgeGenderEstimator
from facelib import FaceDetector, AgeGenderEstimator


# estimator = WebcamAgeGenderEstimator()
# estimator.run(camera_index='2023_06_13_01_56_0.avi')

face_detector = FaceDetector()
age_gender_detector = AgeGenderEstimator()

import time

cap = cv2.VideoCapture('WIN_20230727_09_26_17_Pro_short.mp4')

frameCnt = 0
t1 = time.time()
while True:
    ret, frame = cap.read()
    if not ret:
        break
    
    t2 = time.time()

    faces, boxes, scores, landmarks = face_detector.detect_align(frame)
    genders, ages = age_gender_detector.detect(faces)
    # print(genders, ages)

    t3 = time.time()
    frameCnt += 1

    print('num_frame: {}, fps: {:.1f}, avg_fps: {:.1f}'.format(frameCnt, (1/(t3-t2)), (frameCnt/(t3-t1))))