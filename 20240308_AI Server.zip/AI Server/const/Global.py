from enum import Enum
import queue


class PROJECT(Enum):
    TC2 = "TC2"  # 對應到設定檔的資料夾名稱
    AnneProject = "AnneProject"
    SiDaDun = "SiDaDun"
    ATC = "ATC"
    Showroom = "Showroom"


class GLOBAL_OBJECT:
    serverEventQue = queue.Queue()
    peopleCntQue = queue.Queue()
    layoutListDict = dict()
    fencePeopleDict = dict()
    fenceStayTimeQue = queue.Queue()
    statisticsDictQue = queue.Queue()


WEEK_DICT = {
    "mon": 0,
    "tue": 1,
    "wed": 2,
    "thu": 3,
    "fri": 4,
    "sat": 5,
    "sun": 6,
}
