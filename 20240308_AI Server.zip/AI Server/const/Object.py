from enum import Enum, auto


class ServerEvent(Enum):
    CHANGE_SCHEDULE = auto()
