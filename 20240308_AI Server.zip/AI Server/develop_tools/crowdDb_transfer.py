import pandas as pd
import datetime
import os


orgFilePath = r"D:\Users\YjChou\Smart Retail\Smart Retail Platform\AI Server\data\TC2\save_data\crowd\fileDB_from_val_pc\fileDB.csv"
outputFolderPath = r"D:\Users\YjChou\Smart Retail\Smart Retail Platform\AI Server\data\TC2\save_data\crowd"

# colum = ["場館", "當日客流量", "當日進店人數", "更新時間"]
df = pd.read_csv(orgFilePath)
for idx, row in df.iterrows():
    dateFormat, customerFlow, storVisitor, updateTime = row["日期"], row["當日客流量"], row["當日進店人數"], row["更新時間"]
    newDf = pd.DataFrame({"場館": 1, "當日客流量": customerFlow, "當日進店人數": storVisitor, "更新時間": updateTime}, index=["row1"])

    date = datetime.datetime.strptime(dateFormat, "%y-%m-%d")
    dateFormat = datetime.datetime.strftime(date, "%Y-%m-%d")
    filePath = os.path.join(outputFolderPath, dateFormat + ".csv")
    newDf.to_csv(filePath, index=False, encoding="utf-8-sig")
