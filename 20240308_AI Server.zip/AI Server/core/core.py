import os
import time
import cv2
import yaml
import sys
import datetime
import pandas as pd

from const.Global import PROJECT, WEEK_DICT
from const.Global import GLOBAL_OBJECT
from const.Object import ServerEvent
from utils.Config import Config
from utils.PeopleCnt import PeopleCnt
from utils.Layout import Layout
from utils.Fence import Fence
from utils.FileDB import FileDB
from server.Api import Api, ApiForAnne
from server.Server import Server, ServerForAnne
from packages.ImageProcess import Plot


def run(project):
    ##############################################
    ###            初始化
    ##############################################
    t1 = time.time()
    runDate = datetime.date.today()  # 記錄系統啟動日期

    ### TODO: yjchou 2023/12/08 建立 Logger

    ### 載入設定檔
    cfgFolder = os.path.join("./data", project.value)
    config = Config(cfgFolder)

    ### Server 初始化
    if project not in [PROJECT.AnneProject, PROJECT.Showroom]:
        server = Server(config.host, config.port, config.schedule, config.aiServiceDict)
    else:
        server = ServerForAnne(config.host, config.port, config.schedule, config.aiServiceDict)
    server.run()

    ### API 初始化
    if project not in [PROJECT.AnneProject, PROJECT.Showroom]:
        api = Api(config.fieldId, config.veneueIdList, config.fence.fenceIdList)
    else:
        ### For Jenny 開發的 Web Server API 串接
        api = ApiForAnne(config.fieldId, config.veneueIdList, config.fence.fenceIdList)

    api.init_api_for_webserver(
        config.webServer.serverIp, config.webServer.port, config.webServer.jwtToken, config.webServer.apiKey
    )
    api.init_api_for_webservice(config.aiServiceDict)
    api.run()
    initDataDict = api.get_init()

    ### 人數計數初始化
    peopleCnt = PeopleCnt(config.veneueIdList, initDataDict["veneueCntDay"])

    ### 熱力圖初始化
    layout = Layout()

    ### 初始化站點人數 & 停留時間
    fence = Fence(config.fence.fenceIdList)

    ### 熱力圖初始化
    if config.visualize.heatmap:
        layoutImg = layout.load_layout_img(config.layoutImgPath)

    ### 初始化人流暫存數據
    crowdFileDB = FileDB(folderPath=config.localSave.crowdFolderPath, minutes=5)

    ### 排程設定初始化
    success, scheduleDict = api.get_schedule()
    if success:
        ### 如果排程設定修改時儲存排程設定並傳送給 AI Service
        if check_schedule_change(
            config.schedule,
            scheduleDict,
        ):
            (
                config.schedule.aiSwitch,
                config.schedule.weeks,
                config.schedule.scheduleOnTime,
                config.schedule.scheduleOffTime,
            ) = (
                scheduleDict["aiSwitch"],
                scheduleDict["weeks"],
                scheduleDict["scheduleOnTime"],
                scheduleDict["scheduleOffTime"],
            )
            server.update_sechedule(config.schedule)

            ### 儲存排程設定儲存排程設定
            cfgFilePath = os.path.join(cfgFolder, "config/schedule.yml")
            save_schedule_to_yaml(config.schedule, cfgFilePath)

            ### 呼叫 AI Service 的 API
            api.post_schedule(config.schedule)

    ##############################################
    ###         主流程: 處理 Server 事件
    ##############################################
    while True:
        ##############################################
        ###         跨日重置人數
        ##############################################
        today = datetime.date.today()
        if today != runDate:
            peopleCnt.reset()
            crowdFileDB.write_db()
            runDate = today

        ##############################################
        ###           處理 Server 事件
        ##############################################
        if not GLOBAL_OBJECT.serverEventQue.empty():
            event, msg = GLOBAL_OBJECT.serverEventQue.get()
            if event == ServerEvent.CHANGE_SCHEDULE:
                ### 如果排程設定修改時儲存排程設定並傳送給 AI Service
                scheduleDict = msg
                if check_schedule_change(
                    config.schedule,
                    scheduleDict,
                ):
                    (
                        config.schedule.aiSwitch,
                        config.schedule.weeks,
                        config.schedule.scheduleOnTime,
                        config.schedule.scheduleOffTime,
                    ) = (
                        scheduleDict["aiSwitch"],
                        scheduleDict["weeks"],
                        scheduleDict["scheduleOnTime"],
                        scheduleDict["scheduleOffTime"],
                    )
                    server.update_sechedule(config.schedule)

                    ### 儲存排程設定儲存排程設定
                    cfgFilePath = os.path.join(cfgFolder, "config/schedule.yml")
                    save_schedule_to_yaml(config.schedule, cfgFilePath)

                    ### 呼叫 AI Service 的 API
                    api.post_schedule(config.schedule)

        ##############################################
        ###             上傳每日銷售統計
        ##############################################
        ### 只有零售平台支援銷售統計
        if project == PROJECT.TC2:
            if not GLOBAL_OBJECT.statisticsDictQue.empty():
                statisticsDict = GLOBAL_OBJECT.statisticsDictQue.get()
                saleTime = statisticsDict["saleTime"]

                crowdFilePath = os.path.join(config.localSave.crowdFolderPath, saleTime.replace("/", "-") + ".csv")
                if os.path.isfile(crowdFilePath):
                    df = pd.read_csv(crowdFilePath)
                    crowdDict = {"flowDay": int(df.loc[0]["當日客流量"]), "entringDay": int(df.loc[0]["當日進店人數"])}
                else:
                    crowdDict = {"flowDay": 0, "entringDay": 0}
                api.post_statistics(statisticsDict, crowdDict)

        ##############################################
        ###                辨識排程
        ##############################################
        if not config.schedule.aiSwitch:
            print("辨識功能關閉")
            time.sleep(10)
            continue

        ### 確認排程
        scheduleWeeks = list()
        for week in config.schedule.weeks.split(","):
            scheduleWeeks.append(WEEK_DICT[week])

        ### 判斷星期
        today = datetime.date.today()
        weekToday = today.weekday()
        if weekToday in scheduleWeeks:
            scheduleOnTime, scheduleOffTime = config.schedule.scheduleOnTime, config.schedule.scheduleOffTime
            if scheduleOnTime is not None and scheduleOffTime is not None:
                ### 判斷時間
                now = datetime.datetime.now()
                todayFormat = datetime.datetime.strftime(today, "%Y_%m_%d")
                onTime = datetime.datetime.strptime(todayFormat + "_" + scheduleOnTime, "%Y_%m_%d_%H:%M")
                offTime = datetime.datetime.strptime(todayFormat + "_" + scheduleOffTime, "%Y_%m_%d_%H:%M")
                if now < onTime or now > offTime:
                    print("非排程時間")
                    time.sleep(10)
                    continue
        else:
            print("非排程時間")
            time.sleep(10)
            continue

        ##############################################
        ###            AI 資訊整合
        ##############################################
        veneueDataDict = peopleCnt.get_peopleCnt()
        allLayoutList = layout.get_layout_point()
        fencePeopleDict = fence.get_fence_people()
        fenceStayTimeQue = fence.get_avg_stay()

        ##############################################
        ###             暫存每日人流數據
        ##############################################
        crowdFileDB.update(today, veneueDataDict)

        ##############################################
        ###            後端 API 串接
        ##############################################
        api.post_realtime_info(veneueDataDict, allLayoutList, fencePeopleDict, fenceStayTimeQue)

        ##############################################
        ###            Terminal 顯示
        ##############################################
        print("=" * 50)
        print(veneueDataDict)
        print("=" * 50)

        if config.visualize.heatmap:
            resLayoutImg = Plot.plot_points_on_img(layoutImg, allLayoutList, pointSize=5, color=(0, 0, 255))
            cv2.imshow("layoutImg", resLayoutImg)
            cv2.waitKey(1)

        time.sleep(1)


def check_schedule_change(configSchedule, ScheduleNow):
    if (
        configSchedule.aiSwitch != ScheduleNow["aiSwitch"]
        or configSchedule.weeks != ScheduleNow["weeks"]
        or configSchedule.scheduleOnTime != ScheduleNow["scheduleOnTime"]
        or configSchedule.scheduleOffTime != ScheduleNow["scheduleOffTime"]
    ):
        return True
    else:
        return False


def save_schedule_to_yaml(scheduleData, cfgFilePath):
    with open(cfgFilePath, "w") as file:
        data = {
            "aiSwitch": scheduleData.aiSwitch,
            "weeks": scheduleData.weeks,
            "scheduleOnTime": scheduleData.scheduleOnTime,
            "scheduleOffTime": scheduleData.scheduleOffTime,
        }
        yaml.dump(data, file, default_flow_style=False, allow_unicode=True)
