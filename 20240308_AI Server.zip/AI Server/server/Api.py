import socketio  # python-socketio==5.10.0, websocket-client, eventlet
import requests
import threading
import time
import datetime

from const.Global import GLOBAL_OBJECT


class Api:
    def __init__(self, fieldId, veneueIdList, fenceIdList):
        self.fieldId = fieldId
        self.veneueIdList = veneueIdList
        self.fenceIdList = fenceIdList

    def init_api_for_webserver(self, serverIp, port, jwtToken, apiKey):
        self.serverIp, self.serverPort, self.serverJwtToken = serverIp, port, jwtToken

        self.create_socket()

    def init_api_for_webservice(self, aiServiceDict):
        self.aiServiceDict = aiServiceDict

    def create_socket(self):
        ### 建立 Socket 客戶端
        self.socket = socketio.Client()
        self.socket.connect(
            f"http://{self.serverIp}:{self.serverPort}", headers={"Authorization": f"Bearer {self.serverJwtToken}"}
        )

        ### 註冊斷線事件
        # self.socket.on("disconnect", self.reconnect)

    # def close_socket(self):
    #     self.socket.disconnect()

    # def reconnect(self):
    #     print("Socket 斷線, 嘗試重連")
    #     maxRetries = 10
    #     for i in range(maxRetries):
    #         try:
    #             self.close_socket()
    #             self.create_socket()
    #             break
    #         except Exception as e:
    #             print(f"嘗試重連 {i+1}/{maxRetries} 失败：{str(e)}")
    #             if i < maxRetries - 1:
    #                 time.sleep(2 ** (i + 1))  # Exponential backoff
    #             else:
    #                 print("達到最大嘗試次數, 停止重連")

    ##############################################
    ###                執行序
    ##############################################
    def run(self):
        """開始執行 API 執行序"""
        ### 設備狀態監控
        self.checkStatusThread = threading.Thread(target=self.start_check_status)
        self.checkStatusThread.start()

    def start_check_status(self):
        while True:
            statusDict = self.check_all_ai_status()
            self.post_all_ai_status(statusDict)
            print(f"\nSend {statusDict} to Web Server")
            time.sleep(10)

    ##############################################
    ###           Socket for Web Server
    ##############################################
    def post_all_ai_status(self, statusDict):
        event = "broadcast_status"

        allStatus = True  # 整體狀態
        computerStatusList, camStatusList = list(), list()
        for aiId in statusDict.keys():
            aiStatus = statusDict[aiId]["aiStatus"]
            allStatus = allStatus and aiStatus
            computerStatusList.append({"id": aiId, "status": aiStatus})
            camStatusDict = statusDict[aiId]["camStatus"]
            for camId, camStatus in camStatusDict.items():
                camStatusList.append({"id": camId, "status": camStatus})

        data = {
            "status": allStatus,
            "fieldId": self.fieldId,
            "computerStatus": computerStatusList,
            "cameraStatus": camStatusList,
        }

        ### XXX: 測試用假資料
        # data = {
        #     "status": True,
        #     "fieldId": self.fieldId,
        #     "cameraStatus": [{"id": 1, "status": True}],
        #     "computerStatus": [{"id": 1, "status": True}],
        # }

        try:
            self.socket.emit(event, data)
        except:
            print("Socket 異常: 更新 AI 狀態失敗")

    def post_realtime_info(self, veneueDataDict, allLayoutList, fencePeopleDict, fenceStayTimeQue):

        ### 接近跨日不拋資料
        today = datetime.date.today()
        t1 = datetime.datetime.strptime(str(today) + "12:00", "%Y-%m-%d%H:%M")
        timeNow = datetime.datetime.now()
        if timeNow > t1:
            t2 = datetime.datetime.strptime(str(today + datetime.timedelta(days=1)) + "00:00", "%Y-%m-%d%H:%M")
        else:
            t2 = datetime.datetime.strptime(str(today) + "00:00", "%Y-%m-%d%H:%M")

        duration = t2 - timeNow
        if duration > datetime.timedelta(minutes=-3) and duration < datetime.timedelta(minutes=3):
            return

        event = "broadcast_realtime_info"

        ### 準備熱力圖資料
        heatmapData = list()
        for layoutPoint in allLayoutList:
            heatmapData.append(
                {
                    "x": layoutPoint[0],
                    "y": layoutPoint[1],
                }
            )

        ### 準備人數計數資料 (零售平台只支援單場館)
        veneueData = veneueDataDict["1"]
        flowNow, flowDay = veneueData["customerFlow"]["cntNow"], veneueData["customerFlow"]["cntDay"]
        entringNow, entringDay = veneueData["storeVisitor"]["cntNow"], veneueData["storeVisitor"]["cntDay"]

        ### 準備結帳區人數資料
        checkoutPeople = 0
        for fenceId, fencePeople in fencePeopleDict.items():
            checkoutPeople += fencePeople

        data = {
            "heatmap": heatmapData,
            "fieldId": self.fieldId,  # 案場 ID
            "flowNow": flowNow,  # 當前客流量
            "flowDay": flowDay,  # 當日客流量
            "entringNow": entringNow,  # 當前進店人數
            "entringDay": entringDay,  # 當日進店人數
            "checkout": checkoutPeople,  # 結帳區人數
        }

        ### XXX: 測試用假資料
        # data = {
        #     "heatmap": [
        #         {
        #             "x": 50,
        #             "y": 50,
        #         },
        #         {
        #             "x": 300,
        #             "y": 300,
        #         },
        #     ],
        #     "fieldId": 1,  # 案場 ID
        #     "flowNow": 5,  # 當前客流量
        #     "flowDay": 10,  # 當日客流量
        #     "entringNow": 0,  # 當前進店人數
        #     "entringDay": 0,  # 當日進店人數
        #     "checkout": 0,
        # }

        try:
            self.socket.emit(event, data)
        except:
            print("Socket 異常: 更新熱力圖失敗")

    ##############################################
    ###        Restful API for Web Server
    ##############################################
    def get_init(self):
        url = f"http://{self.serverIp}:{self.serverPort}/admin/field/{self.fieldId}/flow"

        customerFlowDict, storeVisitorDict = dict(), dict()
        for veneueId in self.veneueIdList:
            customerFlowDict[str(veneueId)] = 0
            storeVisitorDict[str(veneueId)] = 0

        try:
            response = requests.get(url, headers={"Authorization": f"Bearer {self.serverJwtToken}"})
            data = response.json()["data"]
            updateTime = data["updatedTime"]
            updateTime = datetime.datetime.strptime(updateTime, "%Y/%m/%d %M:%S")

            ### 判斷最後更新時間是不是當天
            today = datetime.date.today()
            if updateTime.date() == today:
                ### XXX: 零售平台不支援多場館
                customerFlowDict["1"] = data["flowDay"]
                storeVisitorDict["1"] = data["entringDay"]

        except Exception as e:
            print(e)

        initDataDict = {
            "veneueCntDay": {
                "customerFlow": customerFlowDict,
                "storeVisitor": storeVisitorDict,
            },
        }

        return initDataDict

    ### AI Server 重啟時向後端請求排程設定
    def get_schedule(self):
        url = f"http://{self.serverIp}:{self.serverPort}/admin/field/{self.fieldId}"

        try:
            response = requests.get(url, headers={"Authorization": f"Bearer {self.serverJwtToken}"})
            data = response.json()["data"]
            scheduleDict = {
                "aiSwitch": data["aiSwitch"],
                "weeks": "mon,tue,wed,thu,fri,sat,sun",  ### XXX: 零售平台不支援設定星期
                "scheduleOnTime": data["scheduleOnTime"],
                "scheduleOffTime": data["scheduleOffTime"],
            }
            return True, scheduleDict

        except Exception as e:
            print(e)
            return False, e

    ### 每日銷售統計
    def post_statistics(self, statisticsDict, crowdDict):
        url = f"http://{self.serverIp}:{self.serverPort}/admin/saleDetail"
        headers = {"Authorization": f"Bearer {self.serverJwtToken}"}
        body = {
            "fieldId": self.fieldId,
            "turnover": statisticsDict["turnover"],
            "flowDay": crowdDict["flowDay"],
            "entringDay": crowdDict["entringDay"],
            "saleTime": statisticsDict["saleTime"],
            "products": statisticsDict["products"],
        }
        print(f'上傳 {statisticsDict["saleTime"]} 的銷售統計')
        postThread = threading.Thread(target=send_post_request, args=(url, None, body, headers))
        postThread.start()

    ##############################################
    ###        Restful API for AI Service
    ##############################################
    def check_all_ai_status(self):
        """檢查所有 AI 服務狀態"""
        statusDict = dict()
        for aiService in self.aiServiceDict.values():
            aiId, ip, port, camIdList = aiService["aiId"], aiService["ip"], aiService["port"], aiService["camIdList"]
            url = f"http://{ip}:{port}/status"

            disconnectCamStatus = dict()
            for camId in camIdList:
                disconnectCamStatus[int(camId)] = False

            try:
                response = requests.get(url)
                if response.status_code == 200:
                    camStatusDict = response.json()
                    data = dict()
                    for camId, status in camStatusDict.items():
                        data[int(camId)] = status
                    statusDict[aiId] = {"aiStatus": True, "camStatus": data}
                ### AI 服務無回應
                else:
                    statusDict[aiId] = {"aiStatus": False, "camStatus": disconnectCamStatus}
            ### AI 服務拒絕連線或其他異常
            except Exception as e:
                statusDict[aiId] = {"aiStatus": False, "camStatus": disconnectCamStatus}
                # print(f"{url} error: {e}")
        return statusDict

    def post_schedule(self, scheduleData):
        for aiService in self.aiServiceDict.values():
            aiId, ip, port = aiService["aiId"], aiService["ip"], aiService["port"]
            url = f"http://{ip}:{port}/schedule"

            body = {
                "aiSwitch": scheduleData.aiSwitch,
                "weeks": scheduleData.weeks,
                "scheduleOnTime": scheduleData.scheduleOnTime,
                "scheduleOffTime": scheduleData.scheduleOffTime,
            }

            postThread = threading.Thread(target=send_post_request, args=(url, None, body))
            postThread.start()


### For Jenny 開發的 Web Server API 串接
class ApiForAnne:
    def __init__(self, fieldId, veneueIdList, fenceIdList):
        self.fieldId = fieldId
        self.veneueIdList = veneueIdList
        self.fenceIdList = fenceIdList

    def init_api_for_webserver(self, serverIp, port, jwtToken, apiKey):
        self.serverIp, self.serverPort, self.serverJwtToken, self.serverApiKey = serverIp, port, jwtToken, apiKey

    def init_api_for_webservice(self, aiServiceDict):
        self.aiServiceDict = aiServiceDict

    ##############################################
    ###                排程執行
    ##############################################
    def run(self):
        """開始執行 API 執行序"""
        self.checkStatusThread = threading.Thread(target=self.start_check_status)
        self.checkStatusThread.start()

    def start_check_status(self):
        while True:
            statusDict = self.check_all_ai_status()
            self.post_all_ai_status(statusDict)
            print(f"\nSend {statusDict} to Web Server")
            time.sleep(10)

    ##############################################
    ###        Restful API for Web Server
    ##############################################
    ### AI Server 重啟時向後端請求排程設定
    def get_schedule(self):
        url = f"http://{self.serverIp}:{self.serverPort}/API/GetSchedule"
        headers = {"Authorization": f"Api-Key {self.serverApiKey}"}

        aiSwitch = True

        try:
            response = requests.get(url, headers=headers)
            data = response.json()[0]
            weeks, scheduleTime = data["date"], data["time"]
            scheduleOnTime, scheduleOffTime = scheduleTime.split("-")
            scheduleDict = {
                "aiSwitch": aiSwitch,
                "weeks": weeks,
                "scheduleOnTime": scheduleOnTime,
                "scheduleOffTime": scheduleOffTime,
            }
            return True, scheduleDict
        except Exception as e:
            print(e)
            return False, e

    ### AI Server 重啟時向後端請求初始化資料
    def get_init(self):
        url = f"http://{self.serverIp}:{self.serverPort}/API/GenerateCount"
        headers = {"Authorization": f"Api-Key {self.serverApiKey}"}

        dateToday = datetime.datetime.today().strftime("%Y%m%d")

        customerFlowDict, storeVisitorDict = dict(), dict()
        for veneueId in self.veneueIdList:
            customerFlowDict[str(veneueId)] = 0
            storeVisitorDict[str(veneueId)] = 0

        self.fenceNoidDict = dict()
        for fenceId in self.fenceIdList:
            self.fenceNoidDict[str(fenceId)] = 0

        initDataDict = {
            "veneueCntDay": {
                "customerFlow": customerFlowDict,
                "storeVisitor": storeVisitorDict,
            },
        }

        try:
            response = requests.get(url, headers=headers)
            data = response.json()

            isdataToday = False
            fenceNoidList = data[3]
            for i, fenceId in enumerate(self.fenceIdList):
                fenceNoid = fenceNoidList[i]
                ### DB 沒有該展區資料
                if fenceNoid == "":
                    id = 0
                else:
                    updateDate = fenceNoid.split("_")[0]
                    ### 該展區當天有資料
                    if updateDate == dateToday:
                        id = fenceNoid.split("_")[1]  # noid 編碼規則: [日期]_[人記數]_[展區編號]
                        id = int(id) + 1  # 下一個 id 從 id+1 開始
                        isdataToday = True
                    else:
                        id = 0
                self.fenceNoidDict[str(fenceId)] = id

                if isdataToday:
                    (
                        initDataDict["veneueCntDay"]["storeVisitor"]["1"],
                        initDataDict["veneueCntDay"]["storeVisitor"]["2"],
                        initDataDict["veneueCntDay"]["storeVisitor"]["3"],
                    ) = (
                        int(data[0]),
                        int(data[1]),
                        int(data[2]),
                    )

        except Exception as e:
            print(e)

        return initDataDict

    def post_all_ai_status(self, statusDict):
        headers = {"Authorization": f"Api-Key {self.serverApiKey}"}
        for aiId in statusDict.keys():
            aiStatus = statusDict[aiId]["aiStatus"]
            url = f"http://{self.serverIp}:{self.serverPort}/API/GetServerByNoId/{aiId}"
            data = {"state": "正常" if aiStatus else "異常"}
            send_patch_request(url=url, json=data, headers=headers)
            camStatusDict = statusDict[aiId]["camStatus"]
            for camId, camStatus in camStatusDict.items():
                url = f"http://{self.serverIp}:{self.serverPort}/API/GetCameraByNoId/C{camId}"
                data = {"state": "正常" if camStatus else "異常"}
                send_patch_request(url=url, json=data, headers=headers)

    def post_realtime_info(self, veneueDataDict, allLayoutList, fencePeopleDict, fenceStayTimeQue):
        heatmapUrl = f"http://{self.serverIp}:{self.serverPort}/API/GetHeatmap"
        headers = {"Authorization": f"Api-Key {self.serverApiKey}"}

        ### 接近跨日不拋資料
        today = datetime.date.today()
        t1 = datetime.datetime.strptime(str(today) + "12:00", "%Y-%m-%d%H:%M")
        timeNow = datetime.datetime.now()
        if timeNow > t1:
            t2 = datetime.datetime.strptime(str(today + datetime.timedelta(days=1)) + "00:00", "%Y-%m-%d%H:%M")
        else:
            t2 = datetime.datetime.strptime(str(today) + "00:00", "%Y-%m-%d%H:%M")

        duration = t2 - timeNow
        if duration > datetime.timedelta(minutes=-3) and duration < datetime.timedelta(minutes=3):
            return

        ### XXX: 前端只支援進店人數
        mainVeneueData = veneueDataDict["1"]["storeVisitor"]
        subVeneue1Data = veneueDataDict["2"]["storeVisitor"]
        subVeneue2Data = veneueDataDict["3"]["storeVisitor"]

        heatmapData = list()
        for x, y in allLayoutList:
            heatmapData.append([x, y, 60])

        data = {
            "main_area_count": str(mainVeneueData["cntNow"]),  # 主場館當前人數
            "main_area_acc_count": str(mainVeneueData["cntDay"]),  # 主場館當日人次
            "sub_area_count1": str(subVeneue1Data["cntNow"]),  # 子場館_1 當前人數
            "sub_area_acc_count1": str(subVeneue1Data["cntDay"]),  # 子場館_1 當日人次
            "sub_area_count2": str(subVeneue2Data["cntNow"]),  # 子場館_2 當前人數
            "sub_area_acc_count2": str(subVeneue2Data["cntDay"]),  # 子場館_2 當日人次
            "data": str(heatmapData),
        }

        ### XXX: yjchou 2023/12/11 測試用假資料
        # data = {
        #     "main_area_count": "10",  # 主場館當前人數
        #     "main_area_acc_count": "0",  # 主場館當日人次
        #     "sub_area_count1": "0",  # 子場館_1 當前人數
        #     "sub_area_acc_count1": "0",  # 子場館_1 當日人次
        #     "sub_area_count2": "0",  # 子場館_2 當前人數
        #     "sub_area_acc_count2": "0",  # 子場館_2 當日人次
        #     "data": "[[100, 500, 60]]",
        # }

        postThread = threading.Thread(
            target=send_post_request,
            args=(heatmapUrl, None, data, headers),
        )
        postThread.start()

        ### 上傳站點訪客人數
        fencePeopleUrl = f"http://{self.serverIp}:{self.serverPort}/API/GetAreaVisitor"
        data = {
            "area": str([int(fenceId) for fenceId in fencePeopleDict.keys()]),
            "count": str(list(fencePeopleDict.values())),
        }
        postThread = threading.Thread(
            target=send_post_request,
            args=(fencePeopleUrl, None, data, headers),
        )
        postThread.start()

        ### 上傳站點停留時間
        fenceAvgTimeUrl = f"http://{self.serverIp}:{self.serverPort}/API/GetAllAvgtime"
        timeNow = datetime.datetime.today()
        dateFormat = timeNow.strftime("%Y%m%d")
        while not fenceStayTimeQue.empty():
            exitIdDict = fenceStayTimeQue.get()
            for fenceId in exitIdDict:
                for exitId, info in exitIdDict[fenceId].items():
                    exitId = int(exitId)
                    exitId += self.fenceNoidDict[fenceId]
                    ### noid 編碼規則: [%Y%m%d_id_fenceId]_[ID]_[展區編號]
                    noid = dateFormat + "_" + str(exitId) + "_" + str(fenceId)
                    data = {
                        "noid": noid,
                        "area_num": fenceId,
                        "time_in": info["startTime"],
                        "time_out": info["endTime"],
                        "duration": info["stayTime"],
                    }
                    postThread = threading.Thread(
                        target=send_post_request,
                        args=(fenceAvgTimeUrl, None, data, headers),
                    )
                    postThread.start()

    ##############################################
    ###        Restful API for AI Service
    ##############################################
    def check_all_ai_status(self):
        """檢查所有 AI 服務狀態"""
        statusDict = dict()
        for aiService in self.aiServiceDict.values():
            aiId, ip, port, camIdList = aiService["aiId"], aiService["ip"], aiService["port"], aiService["camIdList"]
            url = f"http://{ip}:{port}/status"

            disconnectCamStatus = dict()
            for camId in camIdList:
                disconnectCamStatus[str(camId)] = False

            try:
                response = requests.get(url)
                if response.status_code == 200:
                    data = response.json()
                    statusDict[aiId] = {"aiStatus": True, "camStatus": data}
                ### AI 服務無回應
                else:
                    statusDict[aiId] = {"aiStatus": False, "camStatus": disconnectCamStatus}
            ### AI 服務拒絕連線或其他異常
            except Exception as e:
                statusDict[aiId] = {"aiStatus": False, "camStatus": disconnectCamStatus}
                # print(f"{url} error: {e}")
        return statusDict

    def post_schedule(self, scheduleData):
        for aiService in self.aiServiceDict.values():
            ip, port = aiService["ip"], aiService["port"]
            url = f"http://{ip}:{port}/schedule"

            body = {
                "aiSwitch": scheduleData.aiSwitch,
                "weeks": scheduleData.weeks,
                "scheduleOnTime": scheduleData.scheduleOnTime,
                "scheduleOffTime": scheduleData.scheduleOffTime,
            }

            postThread = threading.Thread(target=send_post_request, args=(url, None, body))
            postThread.start()


##############################################
###           Function
##############################################
def send_post_request(url, data=None, json=None, headers=None, cookies=None):
    response = None
    try:
        response = requests.post(url, data=data, json=json, headers=headers, cookies=cookies)
        if response.status_code not in [200, 201]:
            raise RuntimeError(response.status_code)
    except Exception as e:
        print(f"{url} error: {e}")

    return response


def send_patch_request(url, data=None, json=None, headers=None, cookies=None):
    response = None
    try:
        response = requests.patch(url, data=data, json=json, headers=headers, cookies=cookies)
        if response.status_code not in [200, 201]:
            raise RuntimeError(response.status_code)
    except Exception as e:
        print(f"{url} error: {e}")

    return response
