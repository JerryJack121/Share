import logging
from flask import Flask, Response, jsonify, request
from flask_cors import CORS
import threading
import cv2

from const.Global import GLOBAL_OBJECT
from const.Object import ServerEvent
from packages.ImageProcess import Plot


class Server:
    def __init__(self, host, port, scheduleData, aiServiceDict):
        self.host, self.port = host, port
        self.scheduleData = scheduleData
        self.aiServiceDict = aiServiceDict

        ### 初始化 Flask 應用程式
        self.app = Flask(__name__)
        CORS(self.app)  # 允許跨域連線

        ### 隱藏 Flask 的呼叫紀錄
        log = logging.getLogger("werkzeug")
        log.setLevel(logging.WARNING)

        ### 註冊路由
        self.app.add_url_rule("/peopleCnt", view_func=self.peopleCnt, methods=["POST"])
        self.app.add_url_rule("/heatmap", view_func=self.heatmap, methods=["POST"])
        self.app.add_url_rule("/fence", view_func=self.fence, methods=["POST"])
        self.app.add_url_rule("/schedule", view_func=self.schedule, methods=["GET", "POST"])
        self.app.add_url_rule("/stream/<aiId>", endpoint="stream", view_func=self.stream, methods=["GET"])
        self.app.add_url_rule("/sale_statistics", view_func=self.sale_statistics, methods=["POST"])

    def run(self):
        ### 啟動伺服器執行序
        self.serverThread = threading.Thread(target=self.start_server, args=(self.host, self.port))
        self.serverThread.start()

    def start_server(self, host, port):
        """啟動伺服器

        Args:
            host (str): 本機 ip
            port (int): port
        """
        self.app.run(host, port, debug=False, use_reloader=False)

    ##############################################
    ###                 API
    ##############################################
    ### 人數計數 (含客流量 & 進店人數)
    def peopleCnt(self):
        dataDict = request.get_json()

        ### 將計數線結果放入 Queue, 等待計算案場人數
        GLOBAL_OBJECT.peopleCntQue.put(dataDict)
        print(f"\n收到來自 AI Service 的人數更新: {dataDict}")

        return Response(status=200)

    ### 熱力圖
    def heatmap(self):
        body = request.get_json()
        aiId, heatmapData = body["aiId"], body["heatmapData"]
        GLOBAL_OBJECT.layoutListDict[str(aiId)] = heatmapData
        return Response(status=200)

    ### 站點人數/停留時間
    def fence(self):
        body = request.get_json()
        aiId, fenceData = body["aiId"], body["fenceData"]
        fencePeopleDict, fenceStayTime = fenceData["people"], fenceData["stayTime"]
        ### 僅支援站點人數中的結帳人數
        GLOBAL_OBJECT.fencePeopleDict[str(aiId)] = fencePeopleDict
        return Response(status=200)

    def schedule(self):
        ### 來自 AI Service 重啟時的請求
        if request.method == "GET":
            data = {
                "aiSwitch": self.scheduleData.aiSwitch,
                "weeks": self.scheduleData.weeks,
                "scheduleOnTime": self.scheduleData.scheduleOnTime,
                "scheduleOffTime": self.scheduleData.scheduleOffTime,
            }
            return jsonify(data)

        ### User 在前端修改排程時, 來自後端的請求
        if request.method == "POST":
            body = request.get_json()
            try:
                aiSwitch, scheduleOnTime, scheduleOffTime = (
                    body["aiSwitch"],
                    body["scheduleOnTime"],
                    body["scheduleOffTime"],
                )

                scheduleData = {
                    "aiSwitch": aiSwitch,
                    "weeks": "mon,tue,wed,thu,fri,sat,sun",  ### XXX: 零售平台不支援設定星期,
                    "scheduleOnTime": scheduleOnTime,
                    "scheduleOffTime": scheduleOffTime,
                }

                GLOBAL_OBJECT.serverEventQue.put(
                    (
                        ServerEvent.CHANGE_SCHEDULE,
                        scheduleData,
                    )
                )
                print("\n收到來自 Web Server 的排程設定")
            except Exception as e:
                print(f"Error: {e}")

            return Response(status=200)

    def stream(self, aiId):
        ### 建立 AI Service 的影像串流
        aiService = self.aiServiceDict[str(aiId)]
        ip, port = aiService["ip"], aiService["port"]
        url = f"http://{ip}:{port}/stream"

        return Response(
            self.gen_frames(url),
            content_type="multipart/x-mixed-replace; boundary=frame",
        )

    def sale_statistics(self):
        statisticsDict = request.get_json()
        GLOBAL_OBJECT.statisticsDictQue.put(statisticsDict)
        print("\n收到來自 AI Service 的每日銷售資料")
        return Response(status=200)

    ##############################################
    ###                 Function
    ##############################################
    def update_sechedule(self, scheduleData):
        self.scheduleData = scheduleData

    def gen_frames(self, url):
        """生成串流圖片"""
        cap = cv2.VideoCapture(url)
        while True:
            ret, frame = cap.read()
            if not ret:
                disconnectedImg = Plot.plot_disconnected_img((1536, 1536), fontSize=100)
                frame = disconnectedImg

            encodedImage = encoder(frame)
            yield encodedImage


### For Jenny 開發的 Web Server API 串接
class ServerForAnne:
    def __init__(self, host, port, scheduleData, aiServiceDict):
        self.host, self.port = host, port
        self.scheduleData = scheduleData
        self.aiServiceDict = aiServiceDict

        ### 初始化 Flask 應用程式
        self.app = Flask(__name__)
        CORS(self.app)  # 允許跨域連線

        ### 隱藏 Flask 的呼叫紀錄
        log = logging.getLogger("werkzeug")
        log.setLevel(logging.WARNING)

        ### 註冊路由
        self.app.add_url_rule("/peopleCnt", view_func=self.peopleCnt, methods=["POST"])
        self.app.add_url_rule("/heatmap", view_func=self.heatmap, methods=["POST"])
        self.app.add_url_rule("/fence", view_func=self.fence, methods=["POST"])
        self.app.add_url_rule("/schedule", view_func=self.schedule, methods=["GET", "POST"])
        self.app.add_url_rule("/stream/<aiId>", endpoint="stream", view_func=self.stream, methods=["GET"])

    def run(self):
        ### 啟動伺服器執行序
        self.serverThread = threading.Thread(target=self.start_server, args=(self.host, self.port))
        self.serverThread.start()

    def start_server(self, host, port):
        """啟動伺服器

        Args:
            host (str): 本機 ip
            port (int): port
        """
        self.app.run(host, port, debug=False, use_reloader=False)

    ##############################################
    ###                 API
    ##############################################
    ### 人數計數 (含客流量 & 進店人數)
    def peopleCnt(self):
        dataDict = request.get_json()

        ### 將計數線結果放入 Queue, 等待計算案場人數
        GLOBAL_OBJECT.peopleCntQue.put(dataDict)
        print(f"\n收到來自 AI Service 的人數更新: {dataDict}")

        return Response(status=200)

    ### 熱力圖
    def heatmap(self):
        body = request.get_json()
        aiId, heatmapData = body["aiId"], body["heatmapData"]
        GLOBAL_OBJECT.layoutListDict[aiId] = heatmapData
        return Response(status=200)

    ### 站點人數/停留時間
    def fence(self):
        body = request.get_json()
        aiId, fenceData = body["aiId"], body["fenceData"]
        fencePeopleDict, fenceStayTime = fenceData["people"], fenceData["stayTime"]
        GLOBAL_OBJECT.fencePeopleDict[str(aiId)] = fencePeopleDict

        ### 當有ID離開, 將進出時間資訊放入Queue, 等待上傳
        for fenceNum in fenceStayTime.keys():
            fenceExitIdDict = fenceStayTime[fenceNum]
            ### 任何一個圍籬區有資料就放入Queue
            if len(fenceExitIdDict) != 0:
                GLOBAL_OBJECT.fenceStayTimeQue.put(fenceStayTime)
                break

        ### Develop: yjchou 2023/06/08 查看資料塞車狀況
        if False:
            print("IdPostQueue size: {}".format(GLOBAL_OBJECT.fenceStayTimeQue))

        return Response(status=200)

    def schedule(self):
        ### 來自 AI Service 重啟時的請求
        if request.method == "GET":
            data = {
                "aiSwitch": self.scheduleData.aiSwitch,
                "weeks": self.scheduleData.weeks,
                "scheduleOnTime": self.scheduleData.scheduleOnTime,
                "scheduleOffTime": self.scheduleData.scheduleOffTime,
            }
            return jsonify(data)

        ### User 在前端修改排程時, 來自後端的請求
        if request.method == "POST":
            body = request.get_json()
            try:
                weeks, scheduleTime = body["date"], body["time"]
                scheduleOnTime, scheduleOffTime = scheduleTime.split("-")
                scheduleDict = {
                    "aiSwitch": True,
                    "weeks": weeks,
                    "scheduleOnTime": scheduleOnTime,
                    "scheduleOffTime": scheduleOffTime,
                }

                GLOBAL_OBJECT.serverEventQue.put(
                    (
                        ServerEvent.CHANGE_SCHEDULE,
                        scheduleDict,
                    )
                )
                print("\n收到來自 Web Server 的排程設定")
            except Exception as e:
                print(f"Error: {e}")

            return Response(status=200)

    def stream(self, aiId):
        ### 建立 AI Service 的影像串流
        aiService = self.aiServiceDict[str(aiId)]
        ip, port = aiService["ip"], aiService["port"]
        url = f"http://{ip}:{port}/stream"

        return Response(
            self.gen_frames(url),
            content_type="multipart/x-mixed-replace; boundary=frame",
        )

    ##############################################
    ###                 Function
    ##############################################
    def update_sechedule(self, scheduleData):
        self.scheduleData = scheduleData

    def gen_frames(self, url):
        """生成串流圖片"""
        cap = cv2.VideoCapture(url)
        while True:
            ret, frame = cap.read()
            if not ret:
                disconnectedImg = Plot.plot_disconnected_img((1536, 1536), fontSize=100)
                frame = disconnectedImg

            encodedImage = encoder(frame)
            yield encodedImage


def encoder(img):
    """圖像編碼

    Args:
        img (np.array): 串流圖片

    Returns:
        str: 編碼後的圖片
    """
    ret, buffer = cv2.imencode(".jpg", img)
    byteImg = buffer.tobytes()
    encodedImage = b"--frame\r\n" b"Content-Type: image/jpeg\r\n\r\n" + byteImg + b"\r\n"  # Concatenates frame bytes
    return encodedImage
