import os
import schedule
import threading
import time


class Scheduler:
    checkThreadRunning = False

    @staticmethod
    def create_daily_job(timeFormat, job):
        """建立每天執行一次的任務

        Args:
            timeFormat (_type_): _description_
            job (_type_): _description_
        """
        schedule.every().day.at(timeFormat).do(job)
        Scheduler.__run_check_thread()

    @staticmethod
    def create_reapeat_job(minutes, job):
        """建立每過幾分鐘執行一次的任務

        Args:
            minutes (_type_): _description_
            job (_type_): _description_
        """
        schedule.every(minutes).minutes.do(job)
        Scheduler.__run_check_thread()

    @staticmethod
    def __run_check_thread():
        if not Scheduler.checkThreadRunning:
            checkThread = threading.Thread(target=Scheduler.__check_sechedule)
            checkThread.start()
            Scheduler.checkThreadRunning = True

    @staticmethod
    def __check_sechedule():
        while True:
            schedule.run_pending()
            time.sleep(1)


class RestartManager:
    def __init__(self):
        self.pid = os.getpid()

    def create_daily_sechedule(self, timeFormat):
        """建立每日排程

        Args:
            timeFormat (_type_): _description_
        """
        Scheduler.create_daily_job(timeFormat, self.shutdown)

    def shutdown(self):
        """強制終止程式"""
        ### Windows 系統
        if os.name == "nt":
            cmd = f"taskkill /pid {self.pid} /f"
        ### Linux 系統
        elif os.name == "posix":
            cmd = f"kill {self.pid}"

        try:
            os.system(cmd)
        except Exception as e:
            print(f"Cann't kill process {self.pid}: e")
