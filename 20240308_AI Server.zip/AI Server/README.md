# Smart Retail Platform (AI Serve)

## Edit Record

- 每次改版，請延續此表格紀錄修改內容

| Version | Status |      Branch Name       | Push Date  | Editor | Editor Server | Comment |
| :-----: | :----: | :--------------------: | :--------: | :----: | :-----------: | :------ |
| v0.0.0  | Alpha  | v0.0.0_yjchou_20231205 | 2023/12/07 | YJChou |  tw100039394  |         |
