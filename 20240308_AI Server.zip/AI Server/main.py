from const.Global import PROJECT
from core.core import run


def main(project):
    print(f"Running project '{project.name}'")
    run(project)


if __name__ == "__main__":
    main(PROJECT.Showroom)
