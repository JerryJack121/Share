import time
import threading
import sys

sys.path.append("./")
from const.Global import GLOBAL_OBJECT


class PeopleCnt:
    def __init__(self, veneueIdList, veneueCntDay):
        """_summary_

        Args:
            veneueIdList (_type_): 站點列表
            veneueCntDay (_type_): DB 中的累計人次初始值
        """
        self.veneueDataDict = dict()

        for veneueId in veneueIdList:
            self.veneueDataDict[str(veneueId)] = {
                "customerFlow": {"cntNow": 0, "cntDay": veneueCntDay["customerFlow"][str(veneueId)]},
                "storeVisitor": {"cntNow": 0, "cntDay": veneueCntDay["storeVisitor"][str(veneueId)]},
            }

        self.run()

    def run(self):
        ### 啟動伺服器執行序
        self.serverThread = threading.Thread(target=self.update_thread)
        self.serverThread.start()

    def update_thread(self):
        """更新各案場人數"""
        while True:
            queue = GLOBAL_OBJECT.peopleCntQue
            if queue.empty():
                time.sleep(0.5)
            else:
                peopleCntResultDict = queue.get()
                for key, resultDict in peopleCntResultDict.items():
                    for veneueId in resultDict.keys():
                        inNum, outNum, dayInNum = (
                            resultDict[veneueId]["inNum"],
                            resultDict[veneueId]["outNum"],
                            resultDict[veneueId]["dayInNum"],
                        )
                        self.veneueDataDict[veneueId][key]["cntNow"] += inNum
                        self.veneueDataDict[veneueId][key]["cntNow"] -= outNum
                        self.veneueDataDict[veneueId][key]["cntDay"] += dayInNum

                        ### 邊界條件
                        if self.veneueDataDict[veneueId][key]["cntNow"] < 0:
                            self.veneueDataDict[veneueId][key]["cntNow"] = 0

    def get_peopleCnt(self):
        """回傳各案場人數

        Returns:
            _type_: _description_
        """
        return self.veneueDataDict

    def reset(self):
        """重置各案場人數"""
        for veneueId in self.veneueDataDict.keys():
            for key in self.veneueDataDict[veneueId]:
                self.veneueDataDict[veneueId][key]["cntNow"] = 0
                self.veneueDataDict[veneueId][key]["cntDay"] = 0
