import sys

sys.path.append("./")
from const.Global import GLOBAL_OBJECT


class Fence:
    def __init__(self, fenceIdList):
        self.peopleDict = dict()
        for fenceId in fenceIdList:
            self.peopleDict[str(fenceId)] = 0

    def get_fence_people(self):
        for aiId in GLOBAL_OBJECT.fencePeopleDict.keys():
            for fenceId, fencePeople in GLOBAL_OBJECT.fencePeopleDict[aiId].items():
                self.peopleDict[str(fenceId)] = fencePeople
        return self.peopleDict

    def get_avg_stay(self):
        return GLOBAL_OBJECT.fenceStayTimeQue
