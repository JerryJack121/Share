from configparser import ConfigParser
import json
import yaml
import os


class Config:
    def __init__(self, cfgFolder):
        self.fieldId, self.host, self.port = None, None, None
        self.webServer = Server()
        self.aiServiceDict = dict()
        self.visualize = Visualize()
        self.schedule = Schedule()
        self.fence = Fence()
        self.localSave = LocalSave()

        cfgFilePath = os.path.join(cfgFolder, "initial/setup.yml")
        if os.path.isfile(cfgFilePath):
            self.load_setup(cfgFilePath)
        else:
            raise RuntimeError(f"{cfgFilePath} is not exist!")

        cfgFilePath = os.path.join(cfgFolder, "config/setting.yml")
        if os.path.isfile(cfgFilePath):
            self.load_setting(cfgFilePath)
        else:
            raise RuntimeError(f"{cfgFilePath} is not exist!")

        cfgFilePath = os.path.join(cfgFolder, "config/schedule.yml")
        if os.path.isfile(cfgFilePath):
            self.load_schedule(cfgFilePath)
        else:
            raise RuntimeError(f"{cfgFilePath} is not exist!")

    def load_setup(self, filePath):
        with open(filePath, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
            self.fieldId = data["fieldId"]
            self.host = data["host"]
            self.port = data["port"]
            self.webServer.serverIp = data["webServer"]["ip"]
            self.webServer.port = data["webServer"]["port"]
            self.webServer.jwtToken = data["webServer"]["jwtToken"]
            self.webServer.apiKey = data["webServer"]["apiKey"]
            for aiService in data["aiService"]:
                aiId = aiService["aiId"]
                self.aiServiceDict[str(aiId)] = aiService
        f.close()

    def load_setting(self, filePath):
        with open(filePath, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
            self.veneueIdList = data["peopleCnt"]["veneueIdList"]
            self.layoutImgPath = data["heatmap"]["layoutImgPath"]
            self.fence.fenceIdList = data["fence"]["fenceIdList"]
            self.visualize.heatmap = data["visualize"]["heatmap"]
            self.localSave.crowdFolderPath = data["localSave"]["crowdFolderPath"]

    def load_schedule(self, filePath):
        with open(filePath, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
            self.schedule.aiSwitch = data["aiSwitch"]
            self.schedule.weeks = data["weeks"]
            self.schedule.scheduleOnTime, self.schedule.scheduleOffTime = (
                data["scheduleOnTime"],
                data["scheduleOffTime"],
            )


class Server(object):
    serverIp = None
    port = None
    jwtToken = None
    apiKey = None


class Visualize(object):
    heatmap = None


class Schedule(object):
    aiSwitch = None
    weeks = None
    scheduleOnTime = None
    scheduleOffTime = None


class Fence:
    fenceIdList = None


class LocalSave:
    crowdFolderPath = None
