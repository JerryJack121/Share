import cv2
import os

from const.Global import GLOBAL_OBJECT


class Layout:
    def __init__(self):
        pass

    def load_layout_img(self, imgPath):
        if os.path.isfile(imgPath):
            layoutImg = cv2.imread(imgPath)
            return layoutImg
        else:
            exception = f"找不到 Layout 圖片: {imgPath}"
            raise RuntimeError(exception)

    def get_layout_point(self):
        allLayoutList = list()
        for layoutList in GLOBAL_OBJECT.layoutListDict.values():
            for layoutPoint in layoutList:
                allLayoutList.append(layoutPoint)
        return allLayoutList
