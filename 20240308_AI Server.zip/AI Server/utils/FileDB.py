import pandas as pd
import os
import sys
import datetime


sys.path.append("./")
from packages.ScheduleManger import Scheduler


class FileDB:
    def __init__(self, folderPath, minutes=5):
        self.folderPath = folderPath
        self.veneueDataDict = None

        ### 建立排程
        Scheduler.create_reapeat_job(minutes=minutes, job=self.write_db)

    def update(self, date, veneueDataDict):
        """更新人流資訊"""
        dateFormat = datetime.datetime.strftime(date, "%Y-%m-%d")
        self.filePath = os.path.join(self.folderPath, dateFormat + ".csv")
        self.veneueDataDict = veneueDataDict

    def write_db(self):
        """輸出 csv"""
        if self.veneueDataDict is not None:
            now = datetime.datetime.now()
            updateTime = datetime.datetime.strftime(now, "%y-%m-%d %H:%M:%S")

            columns = ["場館", "當日客流量", "當日進店人數", "更新時間"]
            df = pd.DataFrame(columns=columns)
            for veneueId in self.veneueDataDict.keys():
                newData = {
                    "場館": veneueId,
                    "當日客流量": self.veneueDataDict[veneueId]["customerFlow"]["cntDay"],
                    "當日進店人數": self.veneueDataDict[veneueId]["storeVisitor"]["cntDay"],
                    "更新時間": updateTime,
                }
                newData = pd.DataFrame(newData, index=[0])
                df = pd.concat([df, newData], axis=0)
            df.to_csv(self.filePath, index=False, encoding="utf-8_sig")

    ### TODO: 若沒有平台 DB 時可代替使用
    # def get_init_data(self):
    #     """載入當天的最後一筆資料"""
    #     return initDataDict
