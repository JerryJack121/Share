import sys
import numpy as np

sys.path.append("./")
from packages.Tracker import CentroidTracker


class FaceTracker:
    def __init__(self, maxDisappeared=10):
        self.trackerCls = CentroidTracker(maxDisappeared)

    def update(self, bboxList):
        """更新追蹤器

        Args:
            bboxList (_type_): _description_
        """
        pointTupleList = []
        for box in bboxList:
            cx, cy = get_centroid(box)
            pointTupleList.append((int(cx), int(cy)))
        objects = self.trackerCls.update(pointTupleList)

        idList = []
        ### 交叉比對 bbox 對應的 ID
        for point in pointTupleList:
            withId = False
            for id, centroid in objects.items():
                x1, y1 = point
                x2, y2 = centroid
                if x1 == x2 and y1 == y2:
                    idList.append(id)
                    withId = True
                    break
            if not withId:  ### 新出現的 ID
                idList.append("Unknown")

        return idList


def get_centroid(box):
    x1, y1, x2, y2 = box
    cx = (x1 + x2) / 2
    cy = (y1 + y2) / 2
    return cx, cy
