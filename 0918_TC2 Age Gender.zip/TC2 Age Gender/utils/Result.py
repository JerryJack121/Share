import sys
import datetime
import os
import numpy as np

from const.GlobalObject import Face, Customer
from packages.FileManager import CSV


class Summary:
    """模型辨識結果彙整"""

    def __init__(self, fenceData, minBox=0, maxBox=None, minBoxInArea=0, maxDisappeared=0):
        self.fenceData = fenceData
        self.minBoxInArea = minBoxInArea
        self.minBox, self.maxBox = minBox, maxBox
        self.maxDisappeared = maxDisappeared
        self.ageRangeList = ["0-10", "11-20", "21-30", "31-40", "41-50", "51-60", "61-99"]
        self.AgeStatisticsCls = Statistics()
        self.GenderStatisticsCls = Statistics()
        self.disappearedIdDict = dict()
        self.lastIdList = list()
        self.customerDict = dict()

    def get_face_info(self, idList, boxList, scoreList, genderList, ageList):
        """整合臉部資訊

        Args:
            idList (_type_): _description_
            boxList (_type_): _description_
            scoreList (_type_): _description_
            genderList (_type_): _description_
            ageList (_type_): _description_

        Returns:
            _type_: _description_
        """
        faceClsList = []
        for i in range(len(boxList)):
            id, box, score, age, gender = idList[i], boxList[i], scoreList[i], ageList[i], genderList[i]

            if id == "Unknown":
                continue

            ### 過濾太大太小的框
            boxSize = (box[2] - box[0]) * (box[3] - box[1])
            # print(f"{id}: {int(boxSize)}")
            if boxSize < self.minBox:
                continue
            if self.maxBox is not None:
                if boxSize > self.maxBox:
                    continue

            age = self.__get_age_range(age)  # 轉換成年齡區間

            self.AgeStatisticsCls.update(id, age)  # 更新年齡統計資料
            self.GenderStatisticsCls.update(id, gender)  # 更新性別統計資料

            ageMode = self.AgeStatisticsCls.get_statistics_value(id, Statistics.mode)[0]  # 取年齡眾數
            genderMode = self.GenderStatisticsCls.get_statistics_value(id, Statistics.mode)[0]  # 取性別眾數

            faceCls = Face(id, box, score, gender, age, genderMode, ageMode)
            faceClsList.append(faceCls)

        return faceClsList

    def get_face_in_region(self, faceClsList, maxOnly=False):
        """取得區域範圍中的指定的目標

        Args:
            faceClsList (_type_): _description_
        """
        faceInRegionIdList = list()
        maxFaceId, maxSize = None, None
        for faceCls in faceClsList:
            id, box = faceCls.id, faceCls.box
            boxSize = (box[2] - box[0]) * (box[3] - box[1])
            if boxSize >= self.minBoxInArea:
                centroid = ((box[0] + box[2]) // 2, (box[1] + box[3]) // 2)
                if self.__in_region(centroid):
                    faceInRegionIdList.append(id)
                    if maxFaceId is None:
                        maxFaceId, maxSize = id, boxSize
                    elif boxSize > maxSize:
                        maxFaceId, maxSize = id, boxSize

        if maxOnly:
            if maxFaceId is None:
                return list()
            else:
                return [maxFaceId]
        else:
            return faceInRegionIdList

    def get_customer_info(self, idList):
        """整合顧客資訊

        Args:
            idList (_type_): _description_
        """

        inIdList, outIdList = list(), list()

        ### 建立新客戶資料
        for id in idList:
            ### 判斷是否為新 ID
            if id not in self.lastIdList and id not in self.disappearedIdDict.keys():
                customerCls = Customer(id)
                now = datetime.datetime.now()
                customerCls.timeIn = now
                self.customerDict[id] = customerCls
                inIdList.append(id)

        ### 將上一幀存在但目前沒有的 id 記錄消失名單中
        for lastId in self.lastIdList:
            if lastId not in idList and lastId not in self.disappearedIdDict.keys():
                self.disappearedIdDict[lastId] = 1

        ### 處理消失名單
        removeIdList = list()
        for disappearedId, count in self.disappearedIdDict.items():
            ### 消失又重新出現的 id, 從消失名單移除
            if disappearedId in idList:
                removeIdList.append(disappearedId)

            ### 計算已消失的幀數
            elif count < self.maxDisappeared:
                self.disappearedIdDict[disappearedId] += 1

            ### 刪除不再出現的 id 資料並將辨識結果更新到客戶資料
            else:
                age = self.AgeStatisticsCls.get_statistics_value(disappearedId, Statistics.mode)[0]  # 取年齡眾數
                gender = self.GenderStatisticsCls.get_statistics_value(disappearedId, Statistics.mode)[0]  # 取性別眾數
                # print(f"ID: {disappearedId}, Age: {age}, Gender: {gender}")
                now = datetime.datetime.now()
                (
                    self.customerDict[disappearedId].age,
                    self.customerDict[disappearedId].gender,
                    self.customerDict[disappearedId].timeOut,
                ) = (age, gender, now)
                outIdList.append(disappearedId)

                removeIdList.append(disappearedId)
                self.AgeStatisticsCls.del_data(disappearedId)
                self.GenderStatisticsCls.del_data(disappearedId)

        ### 刪除不再出現的 id 資料
        for id in removeIdList:
            del self.disappearedIdDict[id]

        self.lastIdList = idList

        return self.customerDict, inIdList, outIdList

    def __get_age_range(self, age):
        """取得年齡區間

        Args:
            age (_type_): _description_

        Returns:
            _type_: _description_
        """
        for ageRange in self.ageRangeList:
            minAge = int(ageRange.split("-")[0])
            maxAge = int(ageRange.split("-")[-1])
            if age >= minAge and age <= maxAge:
                return ageRange
        return None

    def __in_region(self, centroid):
        leftTop, rightDown = self.fenceData[0], self.fenceData[1]
        x, y = centroid[0], centroid[1]
        if x < leftTop[0] or x > rightDown[0] or y < leftTop[1] or y > rightDown[1]:
            return False
        else:
            return True


class Statistics:
    """統計資料

    Returns:
        _type_: _description_
    """

    average = 0  # 平均數
    mode = 1  # 眾數

    def __init__(self):
        self.dataDict = dict()

    def update(self, id, data):
        if id not in self.dataDict.keys():
            self.dataDict[id] = list()
        self.dataDict[id].append(data)

    def del_data(self, id):
        del self.dataDict[id]

    def get_statistics_value(self, id, method):
        if method == Statistics.average:
            pass
        elif method == Statistics.mode:
            modeList = Statistics.get_mode(self.dataDict[id])
            return modeList

    @staticmethod
    def get_mode(dataList):
        """取眾數

        Args:
            dataList (list): 原始資料

        Returns:
            list: 眾數 (回傳不只一個代表出現次數一樣多)
        """
        countDict = dict()
        max = 0
        for data in dataList:
            if data not in countDict.keys():
                sum = 1
            else:
                sum = countDict[data] + 1
            countDict[data] = sum
            if sum > max:
                max = sum

        resList = list()
        for data, sum in countDict.items():
            if sum == max:
                resList.append(data)
        return resList


class Record:
    def __init__(self, folderPath, header):
        self.folderPath = folderPath
        self.header = header

        os.makedirs(self.folderPath, exist_ok=True)

    def update(self, customerDict, outIdList):
        for outId in outIdList:
            customerCls = customerDict[outId]
            timeIn = customerCls.timeIn

            fileName = timeIn.strftime("%Y-%m-%d")
            filePath = os.path.join(self.folderPath, f"{fileName}.csv")

            ### 建立檔案
            if not os.path.isfile(filePath):
                CSV.create_csv(filePath, self.header)

            ### 寫入辨識結果
            CSV.add_row(
                filePath,
                row=[
                    customerCls.timeIn,
                    customerCls.timeOut,
                    customerCls.gender,
                    customerCls.age,
                    np.nan,
                    np.nan,
                    np.nan,
                ],
            )
