import csv


class CSV:
    @staticmethod
    def create_csv(filePath, head):
        with open(filePath, "w", encoding="utf_8_sig", newline="") as f:
            csvWritter = csv.writer(f)
            csvWritter.writerow(head)
            f.close

    @staticmethod
    def add_row(filePath, row):
        with open(filePath, "a+", encoding="utf_8_sig", newline="") as f:
            csvWriter = csv.writer(f)
            csvWriter.writerow(row)
            f.close
