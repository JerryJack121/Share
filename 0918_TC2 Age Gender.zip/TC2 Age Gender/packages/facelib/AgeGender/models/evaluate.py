import os
import sys
import torch
from torch.utils.data import DataLoader
import math
import cv2

os.environ["CUDA_VISIBLE_DEVICES"] = "1"
sys.path.append("./")

from packages.facelib.AgeGender.models.train import myDataset, tf
from packages.facelib.AgeGender.models.model import ShuffleneFull
from packages.facelib.AgeGender.models.model import accuracy_gender, l1loss_age


def valid_model(model, testDataLoader):
    model.eval()
    N = len(testDataLoader.dataset)
    step = math.ceil(N / testDataLoader.batch_size)
    acc_gender = 0.0
    loss_age = 0.0

    imgFolder = r"D:\Users\YjChou\Smart Retail\age_gender_data\dataset\age_gender\exp\0906_0912\test"
    imgList = os.listdir(imgFolder)

    with torch.no_grad():
        for i, (x, y) in enumerate(testDataLoader):
            x, y = x.cuda(), y.cuda()
            pred = model(x)

            # img = cv2.imread(os.path.join(imgFolder, imgList[i]))
            # print(y)
            # print(pred)
            # print("")

            acc_gender += accuracy_gender(pred, y)
            loss_age += l1loss_age(pred, y)

    return torch.tensor([acc_gender / N, loss_age / step])


if __name__ == "__main__":
    testDataset = myDataset(
        r"D:\Users\YjChou\Smart Retail\age_gender_data\dataset\age_gender\exp\0906_0912\test",
        tfms=tf["test"],
    )
    testDataLoader = DataLoader(testDataset, batch_size=1, shuffle=False, num_workers=0)

    weight = r"D:\Users\YjChou\Smart Retail\age_gender_data\model\0918_exp2.pth"
    model = ShuffleneFull().cuda()
    model.load_state_dict(torch.load(weight))
    acc_gender, loss_age = valid_model(model, testDataLoader)
    print("acc_gender: {:.3f}, loss_age: {:.3f}".format(acc_gender, loss_age))
