"""
Sajjad Ayoubi: Age Gender Detection
I use UTKFace DataSet
from: https://susanqq.github.io/UTKFace/
download it and put it on FaceSet dir
and I create a annotation file data.npy
which there is in weights folder
"""

import os

os.environ["CUDA_VISIBLE_DEVICES"] = "1"

from PIL import Image
import numpy as np
import torch
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
import torchvision.transforms as transforms
import sys

sys.path.append("./")
from packages.facelib.AgeGender.models.model import ShuffleneFull, TrainModel


class myDataset(Dataset):
    """載入自訂格式的資料集"""

    def __init__(self, imgFolder, tfms):
        self.imgFolder = imgFolder
        self.imgList = os.listdir(self.imgFolder)
        self.tfms = tfms

    def __len__(self):
        return len(self.imgList)

    def __getitem__(self, i):
        imageFileName = self.imgList[i]
        imgFilePath = os.path.join(self.imgFolder, imageFileName)
        label = imageFileName.split("__")[0]
        age, gender = label.split("_")
        age, gender, race = int(age), int(gender), 0  # 人種不加入模型訓練

        return (
            self.tfms(Image.open(imgFilePath)),
            torch.tensor([gender, race, age]).float(),
        )

    def __repr__(self):
        return f"{type(self).__name__} of len {len(self)}"


class MultitaskDataset(Dataset):
    def __init__(self, data, tfms, root):
        self.root = root
        self.tfms = tfms
        self.ages = data[:, 3]
        self.races = data[:, 2]
        self.genders = data[:, 1]
        self.imgs = data[:, 0]

    def __len__(self):
        return len(self.imgs)

    def __getitem__(self, i):
        return (
            self.tfms(Image.open(os.path.join(self.root, self.imgs[i]))),
            torch.tensor([self.genders[i], self.races[i], self.ages[i]]).float(),
        )

    def __repr__(self):
        return f"{type(self).__name__} of len {len(self)}"


class combineDataset(Dataset):
    def __init__(self, utkData, utkroot, myImgFolder, tfms):
        self.utkData = utkData
        self.utkroot = utkroot
        self.myImgFolder = myImgFolder
        self.tfms = tfms

        self.__load_utk()
        self.__load_my_dataset()

    def __load_utk(self):
        self.utkDataset = MultitaskDataset(self.utkData, self.tfms, root=self.utkroot)

    def __load_my_dataset(self):
        self.myDataset = myDataset(self.myImgFolder, self.tfms)

    def __len__(self):
        self.lenUtkDataset = self.utkDataset.__len__()
        self.lenMyDataset = self.myDataset.__len__()
        return self.lenUtkDataset + self.lenMyDataset

    def __getitem__(self, i):
        if i < self.lenUtkDataset:
            return self.utkDataset.__getitem__(i)
        else:
            return self.myDataset.__getitem__(i - self.lenUtkDataset)

    def __repr__(self):
        return f"{type(self).__name__} of len {len(self)}"


def multitask_loss(input, target):
    input_gender = input[:, :2]
    input_age = input[:, -1]

    loss_gender = F.cross_entropy(input_gender, target[:, 0].long())
    loss_age = F.l1_loss(input_age, target[:, 2])

    return loss_gender / (0.16) + loss_age * 2


mean = [0.485, 0.456, 0.406]
std = [0.229, 0.224, 0.225]
sz = 112
bs = 256 * 4

tf = {
    "train": transforms.Compose(
        [
            transforms.RandomRotation(degrees=0.2),
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.RandomGrayscale(p=0.2),
            transforms.Resize((sz, sz)),
            transforms.ToTensor(),
            transforms.Normalize(mean, std),
        ]
    ),
    "test": transforms.Compose([transforms.Resize((sz, sz)), transforms.ToTensor(), transforms.Normalize(mean, std)]),
}

if __name__ == "__main__":
    # ### 訓練 UTKFace 資料集
    # data = np.load(r"packages\facelib\AgeGender\weights\data.npy", allow_pickle=True)
    # train_data = data[data[:, -1] == 1]
    # valid_data = data[data[:, -1] == 0]

    # valid_ds = MultitaskDataset(
    #     data=valid_data, tfms=tf["test"], root=r"D:\Users\YjChou\Smart Retail\age_gender_data\dataset\age_gender\UTKFace\UTKFace"
    # )
    # train_ds = MultitaskDataset(
    #     data=train_data, tfms=tf["train"], root=r"D:\Users\YjChou\Smart Retail\age_gender_data\dataset\age_gender\UTKFace\UTKFace"
    # )

    # ### 訓練自訂格式的資料集
    # train_ds = myDataset(
    #     r"D:\Users\YjChou\Smart Retail\age_gender_data\dataset\age_gender\exp\0906_0912\train",
    #     tfms=tf["train"],
    # )
    # valid_ds = myDataset(
    #     r"D:\Users\YjChou\Smart Retail\age_gender_data\dataset\age_gender\exp\0906_0912\val",
    #     tfms=tf["test"],
    # )

    ### 同時訓練 UTKFace 資料集與自訂格式的資料集
    data = np.load(r"packages\facelib\AgeGender\weights\data.npy", allow_pickle=True)
    train_data = data[data[:, -1] == 1]
    valid_data = data[data[:, -1] == 0]
    train_ds = combineDataset(
        utkData=train_data,
        utkroot=r"D:\Users\YjChou\Smart Retail\age_gender_data\dataset\age_gender\UTKFace\UTKFace",
        myImgFolder=r"D:\Users\YjChou\Smart Retail\age_gender_data\dataset\age_gender\exp\0906_0912\train",
        tfms=tf["train"],
    )
    valid_ds = combineDataset(
        utkData=valid_data,
        utkroot=r"D:\Users\YjChou\Smart Retail\age_gender_data\dataset\age_gender\UTKFace\UTKFace",
        myImgFolder=r"D:\Users\YjChou\Smart Retail\age_gender_data\dataset\age_gender\exp\0906_0912\val",
        tfms=tf["test"],
    )

    train_dl = DataLoader(train_ds, batch_size=bs, shuffle=True, num_workers=0)
    valid_dl = DataLoader(valid_ds, batch_size=bs, shuffle=True, num_workers=0)

    # pretrainWeight = None
    pretrainWeight = r"D:\Users\YjChou\Smart Retail\age_gender_data\model\ShufflenetFull.pth"
    model = ShuffleneFull().cuda()
    model.load_state_dict(torch.load(pretrainWeight))
    optimizer = optim.Adam(params=model.parameters(), lr=0.001, weight_decay=0.001)
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=1, gamma=0.9)
    TrainModel(
        model,
        train_dl,
        valid_dl,
        optimizer,
        multitask_loss,
        scheduler,
        r"D:\Users\YjChou\Smart Retail\age_gender_data\model\logs",
        num_epochs=20,
    )
    print("Finished training")
