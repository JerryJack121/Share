import cv2
import sys
import datetime
import os

sys.path.append("./")
from packages.facelib import FaceDetector
from packages.Capture import webCam, VideoLoader, ImageLodaer


def main(mode, source, outputFolder):
    faceDetectorCls = FaceDetector(device="cuda:1", confidence_threshold=0.5, face_size=(112, 112))

    ### Capture
    if mode == "webcam":
        capture = webCam(source)
    elif mode == "video":
        capture = VideoLoader(source, fps=5)
    elif mode == "image":
        capture = ImageLodaer(source, replay=False)

    if mode == "video":
        capture.start()

    while True:
        if mode == "image":
            frame, imgName = capture.get_frame()
        else:
            frame = capture.get_frame()

        if frame is None:
            continue

        faces, boxList, scoreList, _ = faceDetectorCls.detect_align(frame)  # 偵測臉

        ### torch to python
        faces = faces.cpu().numpy()
        boxList = boxList.cpu().numpy().tolist()
        scoreList = scoreList.cpu().numpy()[:, 0].tolist()

        for i, face in enumerate(faces):
            timeFormat = datetime.datetime.strftime(datetime.datetime.now(), "%Y%m%d%H%M%S")
            if mode == "image":
                filename = f"{imgName}_{i}.jpg"
            else:
                filename = f"{timeFormat}.jpg"
            outputPath = os.path.join(outputFolder, filename)
            cv2.imwrite(outputPath, face)
            cv2.imshow("face", face)
            cv2.waitKey(1)


if __name__ == "__main__":
    mode = "image"
    outputFolder = r"D:\Users\YjChou\Smart Retail\age_gender_data\dataset\age_gender\0912_sample"

    if mode == "camera":
        source = "rtsp://admin:Auo+84149738@192.168.0.100/stream"
    elif mode == "video":
        source = r"D:\Users\YjChou\gender age data\wy.mp4"
    elif mode == "image":
        source = r"D:\Users\YjChou\Smart Retail\age_gender_data\dataset\face\0912_sample"

    main(mode, source, outputFolder)
