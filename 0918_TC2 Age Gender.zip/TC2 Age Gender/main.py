from core import core


mode = "camera"

if mode == "camera":
    source = "rtsp://admin:Auo+84149738@192.168.0.100/stream"
elif mode == "video":
    source = r"D:\Users\YjChou\Smart Retail\age_gender_data\videos\20230906_sample\test02.mp4"
elif mode == "image":
    source = r"D:\Users\YjChou\Smart Retail\age_gender_data\images\for_amc\todo"

core.run(mode, source)
